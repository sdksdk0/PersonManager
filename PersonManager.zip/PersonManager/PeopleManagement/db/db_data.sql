
drop table emp;
drop table dept;
drop table job;
drop table sc;
drop table notify;
drop table salary;
drop table train;
drop table rm;
drop table leave;
drop table clock;
drop table welfare;
drop table recruit;
drop table qr;


insert into emp(eid,name,did,jid,pwd) values(seq_emp_eid.nextval,'a',3,1,'0cc175b9c0f1b6a831c399e269772661');
insert into emp(eid,name,did,jid,pwd) values(seq_emp_eid.nextval,'a',3,2,'0cc175b9c0f1b6a831c399e269772661');
insert into emp(eid,name,did,jid,pwd) values(seq_emp_eid.nextval,'a',2,3,'0cc175b9c0f1b6a831c399e269772661');


insert into dept values(seq_dept_did.nextval,'技术部');
insert into dept values(seq_dept_did.nextval,'人事部');
insert into dept values(seq_dept_did.nextval,'财务部');

insert into job values(1,'人事经理');
insert into job values(2,'人事部员工');
insert into  job values(3,'普通员工');
insert into job values(4,'实习生');
insert into job values(5,'临时工');

insert into salary values(seq_salary_said.nextval,2,15000);
insert into salary values(seq_salary_said.nextval,3,10000);
insert into salary values(seq_salary_said.nextval,4,5000);

insert into sc values(seq_sc_scid.nextval,2,80,to_Data('2016-5-4','yyyy-MM-dd');
insert into sc values(seq_sc_scid.nextval,3,70,to_Data('2016-5-4','yyyy-MM-dd');


insert into notify values (seq_notify_nid.nextval,'系统开始运行了，欢迎使用');
insert into notify values (seq_notify_nid.nextval,'今天要开会了');
insert into notify values (seq_notify_nid.nextval,'欢迎科技部领导莅临本公司');

insert into recruit values(seq_recruit_recid.nextval,'张三','女','21324',2,'录取' );
insert into recruit values(seq_recruit_recid.nextval,'小明','男','6546',3,'淘汰' );
insert into recruit values(seq_recruit_recid.nextval,'上杉','女','5489',4,'录取' );
insert into recruit values(seq_recruit_recid.nextval,'路远','男','43527',5,'' );
insert into recruit values(seq_recruit_recid.nextval,'上杉','女','5489',6,'录取' );
insert into recruit values(seq_recruit_recid.nextval,'路远','男','43527',2,'淘汰' );

insert into welfare values(seq_welfare_wid.nextval,2,'住房公积金',1000);
insert into welfare values(seq_welfare_wid.nextval,3,'医疗保险',1000);
insert into welfare values(seq_welfare_wid.nextval,4,'失业保险',1000);

insert into rm values(seq_rm_rmid.nextval,2,'奖励','加班',100,to_date('2013-05-12','yyyy-MM-dd'));
insert into rm values(seq_rm_rmid.nextval,3,'处罚','迟到',100,to_date('2013-05-12','yyyy-MM-dd'));
insert into rm values(seq_rm_rmid.nextval,4,'处罚','早退',10,to_date('2014-05-12','yyyy-MM-dd'));

insert into train values(seq_train_tid.Nextval,2,'源辰信息科技公司','Java语言培训','信息楼5楼',to_date('2010-2-1','yyyy-mm-dd'),to_date('2010-5-1','yyyy-mm-dd'));
insert into train values(seq_train_tid.Nextval,3,'源辰信息科技公司','Java语言培训','信息楼5楼',to_date('2010-3-1','yyyy-mm-dd'),to_date('2010-5-1','yyyy-mm-dd'));
insert into train values(seq_train_tid.Nextval,3,'源辰信息科技公司','Java语言培训','信息楼5楼',to_date('2010-2-1','yyyy-mm-dd'),to_date('2010-6-1','yyyy-mm-dd'));


insert into qr values(1,2);

insert into leave values (seq_leave_lid.nextval,?,?,?,?,'否');


insert into adjust values (seq_adjust_ajid.nextval,22,sysdate);
insert into adjust values (seq_adjust_ajid.nextval,23,sysdate);
insert into adjust values (seq_adjust_ajid.nextval,2,sysdate);
insert into adjust values (seq_adjust_ajid.nextval,3,sysdate);


select *from emp;
select *from  dept;
select *from  job;
select *from  sc;
select *from  notify;
select *from  salary;
select *from  train;
select *from  rm;
select *from  leave;
select *from  clock;
select *from  welfare;
select *from  recruit;
select *from adjust;
