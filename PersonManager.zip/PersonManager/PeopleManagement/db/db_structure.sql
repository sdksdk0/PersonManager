
--1、员工表
create table emp(                            
       eid int primary key,                         --员工号 
       name varchar2(20)  not null,                          --员工名
       did int  references dept(did),                           --所属部门的id   
       jid int   references job(jid),
       pwd  varchar2(100)  default '0cc175b9c0f1b6a831c399e269772661',    
       status  varchar2(10)  default '在职' ,          --状态   (在职，离职，退休）                 --密码  
       sex char(10) check(sex in('男','女')),      --性别           
       tel number(15),                           --电话
       address varchar2(100),                      --地址
       birthday date,                              --生日
       photo Blob ,                                 --照片   
	   email varchar2(50)                          --邮箱
)


--2、部门表
create table dept(                              
	     did int primary key ,                     -- 部门号
	     name varchar(50)                          --部门名
)


--3、职务表
create table job(                                    
       jid int primary key not null unique,       --职务号                              
       name varchar2(50)                          -- 职务名称
)

--4、业绩评分表
create table sc(
	   scid  int primary key,          
       eid int,                                   --员工号
       score number(3,2),                         --业绩分
       stime date                                 --登记时间
)




--5、公告表
create table notify(
       nid int primary key,                    --公告号
       content varchar2(2000)                  --公告内容
       time date
)



--6、基本工资表
create table salary(
	   said int primary key,
       eid int ,                 --员工号
       jid int ,				--职务号
       smoney number(10,2)       --基本金额
)



--7、培训表
create table train(                       
	   tid int primary key,                
       eid   int,                 		--培训对象（员工id）
       company varchar(100),            --培训公司
       type varcahr(50),				--培训类型（入职培训、技能培训、创新培训等）
       address varchar2(100),           --地点
       tstart  date,                    --培训开始时间
       tend date                        --结束时间
)

--8、奖惩表
create table rm(        
       rmid int primary key,					--
       eid int not null,                    --奖罚对象                  
       type varchar2( 20),                  --奖罚类型（奖励或惩罚）
       rmoney number,                       --奖罚金额     
       gaintime date                        --获得奖罚时间
)


--9、请假表
create table leave(
	   lid int primary key,
       eid int,                        
       lstart date,                     --请假时间
       lend  date,               		 --请假天数
       type varchar(10)                 --是否被批准
)

--10、打卡表
create table clock(    
	   clid int primary key,
       eid int,                 --员工号
       clocktime date           --打卡时间
)
               
--11、福利待遇表
create table welfare(
	   wid int priamry key,
       eid int,         --员工号
       type varchar2(50),   --类型
       wmoney number(10,2)    --金额数
)

--12、招聘表
create table recruit(
       recid int primary key,    --主键
       rname varchar2(50) not null,       --姓名
       sex char(20) check(  sex in('男','女')),  
       tel number(15),
       jid int    references  job(jid),    --应聘职位号（人事经理2，人事部员工3，普通员工4,实习生5、临时工6，。。。）
       status varchar2(50) default '录取'    --状态（录取，还是淘汰）
)

---13、超级标签表
create table qr(
        qrid int primary key,
        eid int references emp(eid) not null
)
--14、 职务调动表
create table adjust (
     ajid int primary key,
     eid int references emp(eid), 
     ajtime date
)


create sequence seq_emp_eid;
create sequence seq_dept_did;
create sequence seq_job_jid;
create sequence seq_sc_scid;
create sequence seq_notify_nid;
create sequence seq_salary_said;
create sequence seq_train_tid;
create sequence seq_rm_rmid;
create sequence seq_leave_lid;
create sequence seq_clock_clid;
create sequence seq_welfare_wid;
create sequence seq_recruit_recid;
create sequence seq_adjust_ajid;
      

alter table emp add constraint fk_dept_did foreign key(did) references dept(did);
alter table emp add constraint fk_job_jid foreign key(jid) references job(jid);

alter table sc add constraint fk_emp_eid foreign key(eid) references emp(eid);
alter table sc add constraint fk_emp_eid foreign key(eid) references emp(eid);

alter table salary add constraint fk_emp_eid foreign key(eid) references emp(eid);
alter table job add constraint fk_job_jid foreign key(jid) references job(jid);

alter table train add constraint fk_emp_eid foreign key(eid) references emp(eid);

alter table rm add constraint fk_emp_eid foreign key(eid) references emp(eid);
alter table leave add constraint fk_emp_eid foreign key(eid) references emp(eid);
alter table clock add constraint fk_emp_eid foreign key(eid) references emp(eid);
alter table welfare add constraint fk_emp_eid foreign key(eid) references emp(eid);

