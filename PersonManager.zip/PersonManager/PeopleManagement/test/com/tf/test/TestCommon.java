package com.tf.test;

import org.junit.Test;

import cn.pm.utils.Common;



public class TestCommon {
	
	@Test
	public void test(){
		System.out.println("aaa");
	}
	
	@Test
	public void TestLog(){
		Common.log.fatal("这是一个致命错误");
		Common.log.error("这是一个错误信息");
		Common.log.info("这是一个正常信息");
		Common.log.debug("调式");
		
		
		
	}
}
