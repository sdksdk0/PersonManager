package com.tf.test;

import java.sql.Connection;

import junit.framework.Assert;

import org.junit.Test;

import cn.pm.dao.DBHelper;



public class TestDBHelp {

	@Test
	public void test() {
		DBHelper db=new DBHelper();
		Connection con=db.getConnection();
		Assert.assertNotNull(con);  //断言
	}
	/*@Test
	public void testDoDDL() {
		DBHelper db=new DBHelper();
		String sql="create table taet(id int)";
		db.find(sql, null);
	}	*/
	
	@Test
	public void testSelect() {
		DBHelper db=new DBHelper();
		String sql="select *from manager  where mname='a'  and password='a' ";
		db.find(sql, null);
	}	
}
