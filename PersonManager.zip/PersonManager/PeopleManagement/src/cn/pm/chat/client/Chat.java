package cn.pm.chat.client;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Combo;

import javax.swing.ScrollPaneConstants;

import java.awt.Component;

public class Chat extends JFrame implements ListSelectionListener,
		ItemListener, Runnable {
	Border titleBorder1 = BorderFactory.createTitledBorder("主频道");
	Border titleBorder2 = BorderFactory.createTitledBorder("用户频道");
	Border titleBorder3 = BorderFactory.createTitledBorder("用户列表");
	Box b3 = Box.createHorizontalBox(); // 私聊选择行
	Box b5 = Box.createHorizontalBox(); // 中间
	Box b2 = Box.createVerticalBox(); // 第二行左边
	Box b = Box.createVerticalBox(); // 总

	JScrollPane commonArea;
	JScrollPane selfArea;
	JScrollPane userlist;
	JPanel j4 = new JPanel(new FlowLayout(0));
	JPanel j6 = new JPanel(new FlowLayout(0));
	JPanel j5 = new JPanel(new BorderLayout());
	JTextArea jt1; // 公聊
	JTextArea jt2;
	JList jl1;
	JLabel jla;
	JLabel jima = new JLabel();
	JLabel juser = new JLabel("当前登录用户为：         ");
	JLabel jla1; // 登录当前用户名
	JComboBox jc1; // 用户下拉框
	JCheckBox jch1;
	JCheckBox checkBox;
	
	JTextField send1 = new JTextField(36);
	JButton send2 = new JButton("发送信息");
	private DataOutputStream dout; // 向服务器传输信息
	private DataInputStream din; // 接收服务器信息
	private DefaultListModel lis1; // 用户列表数据模型
	private DefaultComboBoxModel comb; // 下拉框数据模型
	JButton button = new JButton("发给机器人");
	
	private String sendname;
	private boolean isscret;
	private boolean rooboot;
	private boolean flag = true;

	public Chat(String user, DataOutputStream dout, DataInputStream din) {
		isscret = false;
		sendname = null;
		lis1 = new DefaultListModel();
		comb = new DefaultComboBoxModel();
		comb.addElement("所有人");
		this.dout = dout;
		this.din = din;
		jla1 = new JLabel(user);
		jt1 = new JTextArea(10, 30);
		jt2 = new JTextArea(10, 30);
		jl1 = new JList(lis1);
		jl1.addListSelectionListener(this);
		jc1 = new JComboBox(comb);
		jch1 = new JCheckBox("私聊");
		checkBox = new JCheckBox("机器人");
		
		jch1.addItemListener(this);
		jla = new JLabel("和");
		commonArea = new JScrollPane(jt1);
		commonArea.setSize(190, 190);
		selfArea = new JScrollPane(jt2);
		commonArea.setBorder(titleBorder1);
		selfArea.setBorder(titleBorder2);
		selfArea.setSize(200, 200);
		userlist = new JScrollPane(jl1);
		userlist.setAlignmentX(Component.RIGHT_ALIGNMENT);
		userlist.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		b2.add(commonArea);
		b2.add(selfArea);
		b3.add(jla);
		b3.add(jc1);
		b3.add(jch1);
		b2.add(b3);
		
		b3.add(checkBox);
		b5.add(b2);
		b5.add(userlist);
		j4.add(send1);
		j4.add(send2);
		send2.addActionListener(sendmsg);
		j6.add(jima);
		j6.add(juser);
		j6.add(jla1);
		b.add(j6);
		b.add(b5);
		b.add(j4);
		
		j4.add(button);
	
		getContentPane().add(b);
		this.setSize(650, 549);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		
		//发给机器人
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
					String answer = null;
					sendname = (String) jc1.getSelectedItem();
					try {
						answer = machine(send1.getText().trim());
						dout.writeUTF("info," + sendname + ","
								+ jla1.getText() + "," + send1.getText());
						dout.writeUTF("info," +sendname +","+"机器人,"+answer);
						
					/*	System.out.println("root," +jla1.getText()+","+"机器人,"+answer);
						System.out.println("输入"+send1.getText());
						System.out.println("返回值:"+answer);*/
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					send1.setText("");
				
			}
		});

		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent event) {
				try {
					Chat.this.dout.writeUTF("quit," + jla1.getText()); // 用户退出时，向服务器发送下线信息
					System.exit(0);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			@Override
			public void windowClosed(WindowEvent arg0) {
				flag = false;
			}
		});
		setTitle(user + "的聊天窗口");
		this.setVisible(true);
		Thread t = new Thread(this);
		t.start();
	}
	


	// 发送信息
	ActionListener sendmsg = new ActionListener() {

		public void actionPerformed(ActionEvent e) {
			
		//	if(rooboot==false){
				if (isscret == false) {
					sendname = (String) jc1.getSelectedItem();
					if (!(sendname.equals("所有人"))) {
						JOptionPane.showMessageDialog(null, "您选择的是单人，请勾选私聊");
					} else {
						try {
							dout.writeUTF("info," + sendname + ","
									+ jla1.getText() + "," + send1.getText());
							
							send1.setText("");
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				} else {
					sendname = (String) jc1.getSelectedItem();
					if (sendname.equals("所有人")) {
						JOptionPane.showMessageDialog(null, "您已选择私聊，请选择单个用户");
					} else {
						if (sendname.equals(jla1.getText())) {
							JOptionPane.showMessageDialog(null, "您不能对自己发起聊天！");
						} else {
							try {
								dout.writeUTF("info," + sendname + ","
										+ jla1.getText() + ","
										+ send1.getText());
								send1.setText("");
							} catch (IOException e1) {
								e1.printStackTrace();
							}
						}
					}
				}
			
			/*}else{
				String answer = null;
				sendname = (String) jc1.getSelectedItem();
				try {
					answer = machine(send1.getText().trim());
					dout.writeUTF("info," + sendname + ","
							+ jla1.getText() + "," + send1.getText());
					dout.writeUTF("info," +sendname +","+"机器人,"+answer);
					
					System.out.println("root," +jla1.getText()+","+"机器人,"+answer);
					System.out.println("输入"+send1.getText());
					System.out.println("返回值:"+answer);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				send1.setText("");
				
			}*/
	
		}
	};
	


	// 选择私聊对象
	public void valueChanged(ListSelectionEvent e) {
		if (e.getSource() == jl1) {
			String s = (String) jl1.getSelectedValue();
			if (s != null) {
				String s1 = s.substring(0, s.indexOf("【"));
				jc1.setSelectedItem(s1);
			}
		}

	}

	// 是否机器人
	public void root(ItemEvent e) {
		if (e.getSource() == checkBox) {
			if (checkBox.isSelected()) {
				rooboot = true;
			} else {
				rooboot = false;
			}
		}
	}


	// 是否私聊
	public void itemStateChanged(ItemEvent e) {
		if (e.getSource() == jch1) {
			if (jch1.isSelected()) {
				isscret = true;
			} else {
				isscret = false;
			}
		}
	}

	//单独线程，不断接收服务器发送的信息
			public void run() {
				// TODO Auto-generated method stub
				while(true) {
					String info = null;
					try {
						if((info = din.readUTF())!=null) {
							String[] s = info.split(",");
							if(s[0].equals("remind")) {
								lis1.addElement(s[1]);
								comb.addElement(s[1]);
							} else if(s[0].equals("new")) {
								lis1.addElement(s[1]);
								comb.addElement(s[1]);
								jt1.append("【【公告信息】】："+s[1]+"加入了聊天频道\n");
							} else if(s[0].equals("all")) {
								jt1.append("【"+s[1]+"说:】  "+s[2]+"\n");
							} else if(s[0].equals(jla1.getText())) {
								jt2.append("【"+s[1]+"悄悄的说:】"+s[2]+"\n");
							} else if(s[0].equals("quit")) {
								jt1.append("【【公告信息】】："+s[1]+"退出了频道\n");
								lis1.removeElement(s[1]);
								comb.removeElement(s[1]);
							} else{
								
							}
						} else {
						}
			} catch (IOException e) {
				setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			}
		}
	}

	private static String machine(String quesiton) throws IOException {
		// 接入机器人，输入问题
		String APIKEY = "5d2460b7198f28cee8baedd2a6fbe928";
		String INFO = URLEncoder.encode(quesiton, "utf-8");// 这里可以输入问题
		String getURL = "http://www.tuling123.com/openapi/api?key=" + APIKEY
				+ "&info=" + INFO;
		URL getUrl = new URL(getURL);
		HttpURLConnection connection = (HttpURLConnection) getUrl
				.openConnection();
		connection.connect();

		// 取得输入流，并使用Reader读取
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				connection.getInputStream(), "utf-8"));
		StringBuffer sb = new StringBuffer();
		String line = "";
		while ((line = reader.readLine()) != null) {
			sb.append(line);
		}
		reader.close();
		// 断开连接
		connection.disconnect();
		String[] ss = new String[10];
		String s = sb.toString();
		String answer;
		ss = s.split(":");
		answer = ss[ss.length - 1];
		answer = answer.substring(1, answer.length() - 2);
		return answer;
	}
}
