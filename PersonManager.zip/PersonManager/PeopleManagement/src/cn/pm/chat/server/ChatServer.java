package cn.pm.chat.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 聊天系统的服务器
 * @author Ocean_Howard
 *
 */
public class ChatServer extends Thread{
		@Override
		public void run() {
			startServer();
		}
		private static boolean bool=true;
		public static void startServer()
		{
			try 
			{
				ServerSocket server=new ServerSocket(9999);		
				System.out.println("服务器已经启动............");
				while(bool)
				{
					Socket s=server.accept();
	                FriendsThread ft=new FriendsThread(s);		
	                ft.start();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public static void close()
		{
			
		}
		
}
