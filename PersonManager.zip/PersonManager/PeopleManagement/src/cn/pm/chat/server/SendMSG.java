package cn.pm.chat.server;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 * 发送信息
 *
 */
public class SendMSG 
{
	private  UserVo user;
	private  Socket soc;
	private  DataOutputStream dout;
	public void sendInfo(String sendname,String sayname,String info)
	{
		try{
			
			//发送群聊信息			
			if(sendname.equals("所有人")) {
				for(String s:LoginUser.map.keySet()) {
					user = LoginUser.map.get(s);
					soc = user.getSoc();
					dout=new DataOutputStream(soc.getOutputStream());
					dout.writeUTF("all,"+sayname+","+info);
				}
			}
			
			//发送私聊信息
			else {
				user=LoginUser.map.get(sendname);
				soc = user.getSoc(); 
				dout=new DataOutputStream(soc.getOutputStream());
				dout.writeUTF(sendname+","+sayname+","+info);
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	

}

