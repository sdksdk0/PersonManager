package cn.pm.chat.server;

import java.net.Socket;
import java.util.HashMap;
/**
 * 储存用户信息和所使用的socket
 * @author Ocean_Howard
 *
 */
public class LoginUser
{
	public static HashMap<String, UserVo> map=new HashMap<String, UserVo>();

}
