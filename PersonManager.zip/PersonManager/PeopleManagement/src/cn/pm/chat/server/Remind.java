package cn.pm.chat.server;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * 用户上下线提醒，更新当前用户列表
 *
 */
public class Remind {
	private UserVo user;
	private DataOutputStream dout;
	//添加已登录人员到新用户中
	
		public void remindOne(Socket soc) {
			for(String s:LoginUser.map.keySet()) {
				user = LoginUser.map.get(s);
				try {
					dout=new DataOutputStream(soc.getOutputStream());
					dout.writeUTF("remind,"+user.getUsername());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	//添加新用户到所有列表中
		
		public void remindAll(UserVo user1) {
			for(String s:LoginUser.map.keySet()) {
				user = LoginUser.map.get(s);
				Socket soc = user.getSoc();
				try {
					dout=new DataOutputStream(soc.getOutputStream());
					dout.writeUTF("new,"+user1.getUsername());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		public void remindQuit(UserVo user1) {
			for(String s:LoginUser.map.keySet()) {
				user = LoginUser.map.get(s);
				Socket soc = user.getSoc();
				try {
					dout=new DataOutputStream(soc.getOutputStream());
					dout.writeUTF("quit,"+user1.getUsername());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
}
