package cn.pm.chat.server;

import java.io.IOException;
import java.net.Socket;

/**
 * 用户的基本信息
 *
 */
public class UserVo {
	private String username;
	private Socket soc;
	public UserVo(String username, Socket soc) {
		super();
		this.username = username;
		this.soc = soc;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}

	public Socket getSoc() {
		return soc;
	}
	public void setSoc(Socket soc) {
		this.soc = soc;
	}
	
	public void SocketClose() {
		try {
			this.soc.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	

}
