package cn.pm.chat.server;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * 由此启动服务器
 *
 */
public class ServerStart extends JFrame
{
    private JButton btnStart=new JButton("启动");
	private JButton btnStop=new JButton("停止");
	ChatServer s;
	private ActionListener arg0=new ActionListener() 
	{		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			if(arg0.getSource()==btnStart)
			{
			  s=new ChatServer();
			  s.start();
			  btnStart.setEnabled(false);
			
			}
			if(arg0.getSource()==btnStop)
			{
				  s.stop();
				  System.out.println("服务器已经关闭");
				 btnStart.setEnabled(true);
			}
			
		}
	};
	public ServerStart()
	{
		getContentPane().setLayout(new FlowLayout());
		getContentPane().add(btnStart);
		getContentPane().add(btnStop);
		btnStart.addActionListener(arg0);
		btnStop.addActionListener(arg0);
		setSize(400,110);
		setLocationRelativeTo(null);
		 setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setVisible(true);
		
	}
	public static void main(String[] args) 
	{
	  new ServerStart();

	}

}