package cn.pm.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;

import com.ibm.icu.text.SimpleDateFormat;
import com.ibm.icu.util.Calendar;

import cn.pm.dao.DBHelper;
import cn.pm.utils.LayoutUtil;

import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.DateTime;

public class AdjustSalary extends Composite {
	private Table table;
	private Text text;
	DBHelper db = new DBHelper();

	private Combo combo;
	private Combo combo_1;
	private Shell shell;
	private Event event;

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public AdjustSalary(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_DEFAULT);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setLayout(new FillLayout(SWT.HORIZONTAL));

		shell = parent.getShell();
		Composite composite = new Composite(this, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));
		setSize(1414, 760);
		SashForm sashForm = new SashForm(composite, SWT.VERTICAL);

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group = new Group(composite_1, SWT.NONE);
		group.setText("当前是>员工管理>调薪管理");

		Button button = new Button(group, SWT.NONE);

		button.setBounds(699, 67, 80, 27);
		button.setText("查询");

		Label label = new Label(group, SWT.NONE);
		label.setBounds(281, 70, 61, 17);
		label.setText("员工名：");

		text = new Text(group, SWT.BORDER);
		text.setBounds(420, 67, 124, 23);

		Button button_1 = new Button(group, SWT.NONE);

		button_1.setBounds(833, 65, 98, 30);
		button_1.setText("调职");

		Button button_2 = new Button(group, SWT.NONE);

		button_2.setBounds(1000, 65, 98, 30);
		button_2.setText("删除");

		Composite composite_2 = new Composite(sashForm, SWT.NONE);
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));

		table = new Table(composite_2, SWT.BORDER | SWT.FULL_SELECTION);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(100);
		tableColumn_1.setText("调薪号");

		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(187);
		tblclmnNewColumn.setText("员工号");

		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(203);
		tblclmnNewColumn_1.setText("员工名");

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(208);
		tableColumn.setText("职位名");

		TableColumn tblclmnNewColumn_3 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_3.setWidth(267);
		tblclmnNewColumn_3.setText("该职务基本工资");

		TableColumn tblclmnNewColumn_2 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_2.setWidth(266);
		tblclmnNewColumn_2.setText("调整日期");

		Composite composite_3 = new Composite(sashForm, SWT.NONE);

		Label label_1 = new Label(composite_3, SWT.NONE);
		label_1.setBounds(390, 55, 76, 20);
		label_1.setText("员工号：");

		Label label_3 = new Label(composite_3, SWT.NONE);
		label_3.setBounds(390, 134, 76, 20);
		label_3.setText("职位名：");

		combo = new Combo(composite_3, SWT.READ_ONLY);
		combo.setBounds(539, 52, 92, 28);

		combo_1 = new Combo(composite_3, SWT.READ_ONLY);
		combo_1.setBounds(539, 126, 92, 28);
		sashForm.setWeights(new int[] { 119, 295, 340 });

		intiCombo();
		initCombo2();
		event = new Event();
		event.widget = button;

		// 删除
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length <= 0) {
					return;
				}
				TableItem ti = tis[0];
				String ajid = ti.getText(0);

				String sql = " delete from  adjust where ajid='" + ajid + "'";

				int rs = db.update(sql, null);

				if (rs > 0) {
					MessageDialog.openInformation(shell, "成功", "删除成功");
					button.notifyListeners(SWT.Selection, event);
				} else {
					MessageDialog.openError(shell, "错误", "删除失败");
				}

			}
		});

		// 调职
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String eid = combo.getText().trim();
				String jname = combo_1.getText().trim();

				String sql1 = " insert into adjust values(seq_adjust_ajid.nextval,?,sysdate)";

				List<Object> params = new ArrayList<Object>();
				params.add(eid);

				int rs = db.update(sql1, params);

				String sql2 = " update emp set jid=(select jid from job where name=?) where eid=? ";

				List<Object> params1 = new ArrayList<Object>();
				params1.add(jname);
				params1.add(eid);
				int rs1 = db.update(sql2, params1);

				if (rs > 0 && rs1 > 0) {
					MessageDialog.openInformation(shell, "成功", "职务调动成功");
					button.notifyListeners(SWT.Selection, event);
				} else {
					MessageDialog.openError(shell, "错误", "职务调动失败");
					return;
				}
			}
		});

		// 查询
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String ename = text.getText().trim();

				String sql = " select a.ajid,e.eid,e.name as ename,j.name as jname ,s.smoney,a.ajtime  from   adjust a left join emp e on a.eid=e.eid join job j on j.jid=e.jid  join  salary s on e.jid=s.jid  where 1=1  ";

				if (ename != null && !"".equals(ename)) {
					sql += " and e.name='" + ename + "'";
				}
				table.removeAll();
				List<Map<String, Object>> list = db.find(sql.toString(), null);
				if (list != null && !"".equals(list)) {
					for (Map<String, Object> map : list) {
						TableItem ti = new TableItem(table, SWT.NONE);
						String ajid = (String) map.get("AJID");
						String eid = (String) map.get("EID");
						String ename2 = (String) map.get("ENAME");
						String jname = (String) map.get("JNAME");
						String smoney = (String) map.get("SMONEY");
						String ajtime = (String) map.get("AJTIME");

						String[] str = new String[] { ajid, eid, ename2, jname,
								smoney, ajtime };
						ti.setText(str);
					}
				}
			}
		});

	}

	public void initCombo2() {
		String sql = "select name from job  ";
		DBHelper db = new DBHelper();
		try {
			List<Map<String, Object>> list = db.find(sql, null);

			if (list != null && list.size() > 0) {
				combo_1.removeAll();
				for (Map<String, Object> map : list) {
					String jname = (String) map.get("NAME");
					combo_1.add(jname);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	public void intiCombo() {
		String sql = "select eid from emp  ";
		DBHelper db = new DBHelper();
		try {
			List<Map<String, Object>> list = db.find(sql, null);

			if (list != null && list.size() > 0) {
				combo.removeAll();
				for (Map<String, Object> map : list) {
					String eid = (String) map.get("EID");
					combo.add(eid);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
