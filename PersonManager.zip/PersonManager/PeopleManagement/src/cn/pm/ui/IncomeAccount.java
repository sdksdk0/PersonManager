package cn.pm.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import cn.pm.dao.DBHelper;

import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;

public class IncomeAccount {

	protected Shell shell;
	public static Table table;
	private Combo combo_1;
	private Text text;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			IncomeAccount window = new IncomeAccount();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		shell.setBackgroundMode(SWT.INHERIT_FORCE);
		shell.setSize(1059, 600);
		shell.setText("薪资报表");
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(shell, SWT.VERTICAL);

		Composite composite = new Composite(sashForm, SWT.NONE);

		Group group = new Group(composite, SWT.NONE);
		group.setBounds(0, 0, 858, 22);
		group.setText("当前是>统计报表>薪资报表");

		Combo combo = new Combo(composite, SWT.NONE);
		combo.setItems(new String[] { "全部", "2016", "2015", "2014", "2013" });
		combo.setBounds(130, 49, 86, 28);

		Label label_2 = new Label(composite, SWT.NONE);
		label_2.setBounds(229, 52, 19, 17);
		label_2.setText("年");

		Combo combo_2 = new Combo(composite, SWT.READ_ONLY);
		combo_2.setItems(new String[] { "全部", "第一", "第二", "第三", "第四" });
		combo_2.setBounds(328, 49, 71, 28);

		Label label_3 = new Label(composite, SWT.NONE);
		label_3.setBounds(405, 52, 36, 17);
		label_3.setText("季度");

		Combo combo_3 = new Combo(composite, SWT.READ_ONLY);
		combo_3.setItems(new String[] { "全部", "1", "2", "3", "4", "5", "6",
				"7", "8", "9", "10", "11", "12" });
		combo_3.setBounds(533, 49, 61, 28);

		Label lblNewLabel_1 = new Label(composite, SWT.NONE);
		lblNewLabel_1.setBounds(600, 52, 54, 17);
		lblNewLabel_1.setText("月份");

		Button btnNewButton = new Button(composite, SWT.NONE);

		btnNewButton.setBounds(951, 49, 80, 27);
		btnNewButton.setText("查询");

		combo_1 = new Combo(composite, SWT.READ_ONLY);
		combo_1.setBounds(720, 49, 92, 28);

		Label label_4 = new Label(composite, SWT.NONE);
		label_4.setBounds(818, 52, 76, 20);
		label_4.setText("部门");

		Label label_5 = new Label(composite, SWT.NONE);
		label_5.setBounds(10, 106, 76, 20);
		label_5.setText("总工资：");

		text = new Text(composite, SWT.BORDER);
		text.setEditable(false);
		text.setBounds(86, 106, 127, 26);

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		table = new Table(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(87);
		tblclmnNewColumn.setText("员工号");

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(69);
		tableColumn.setText("姓名");

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(82);
		tableColumn_1.setText("性别");

		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(87);
		tableColumn_2.setText("所属部门");

		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(75);
		tableColumn_3.setText("职务");

		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(89);
		tableColumn_4.setText("基本工资");

		TableColumn tableColumn_8 = new TableColumn(table, SWT.NONE);
		tableColumn_8.setWidth(108);
		tableColumn_8.setText("福利金额");

		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(99);
		tblclmnNewColumn_1.setText("奖励");

		TableColumn tableColumn_10 = new TableColumn(table, SWT.NONE);
		tableColumn_10.setWidth(102);
		tableColumn_10.setText("惩罚");

		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(100);
		tableColumn_5.setText("时间");

		TableColumn tableColumn_11 = new TableColumn(table, SWT.NONE);
		tableColumn_11.setWidth(143);
		tableColumn_11.setText("总工资");
		sashForm.setWeights(new int[] { 107, 325 });

		initCombo();

		// 综合查询
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String year = combo.getText().toString().trim();
				String season = combo_2.getText().toString().trim();
				String month = combo_3.getText().toString().trim();
				String dname = combo_1.getText().toString().trim();

				List<Object> params = new ArrayList<Object>();

				String sql = "select e.eid,e.name as ename,e.sex,d.name as dname,j.name as jname,w.wmoney,"
						+ "extract(year from gaintime) year,  "
						+ "extract(month from gaintime) month  "
						+ "from emp e join  dept d on e.did=d.did  join  job j  on j.jid=e.jid  join salary s  on  s.jid=e.jid  join welfare w  on w.eid=e.eid "
						+ "left join rm   on  rm.eid=e.eid  "
						+ "group by  e.eid,e.name ,e.sex,d.name ,j.name ,w.wmoney, "
						+ " extract(year from gaintime) ,extract(month from gaintime)   having  1=1 ";

				if (year.equals("全部")) {
					sql += "  ";
				} else if (year != null && !"".equals(year)) {
					sql += "   and extract(year from gaintime)=? ";
					params.add(year);
				}

				if (month.equals("全部")) {
					sql += "  ";
				} else if (month != null && !"".equals(month)) {
					sql += "   and extract(month from gaintime)=? ";
					params.add(month);
				}

				if (season.equals("全部")) {
					sql += "  ";
				} else if (season.equals("第一")) {
					sql += " and extract(month from gaintime) between 1 and 3 ";

				} else if (season.equals("第二")) {
					sql += " and extract(month from gaintime) between 4 and 6 ";

				} else if (season.equals("第三")) {
					sql += " and extract(month from gaintime) between 7 and 9 ";

				} else if (season.equals("第四")) {
					sql += " and extract(month from gaintime) between 10 and 12 ";

				}

				if (dname.equals("全部")) {
					sql += " ";
				} else if (dname != null && !"".equals(dname)) {
					sql += "  and d.name=? ";
					params.add(dname);
				}

				DBHelper db = new DBHelper();
				table.removeAll();
				List<Map<String, Object>> list = db.find(sql.toString(), params);

				int summoney = 0; // 查询时工资条总工资数 
				int tol = 0;   //个人总工资
				TableItem ti = null;
				String[] str = null;
				if (list != null && list.size() > 0) {
					for (Map<String, Object> data : list) {
						ti = new TableItem(table, SWT.None);
						String eid2 = (String) data.get("EID");
						String ename2 = (String) data.get("ENAME");
						String sex2 = (String) data.get("SEX");
						String dname2 = (String) data.get("DNAME");
						String wmoney2 = (String) data.get("WMONEY");
						int  month2 = Integer.parseInt((String) data.get("MONTH"));

						String gaintime = (String) data.get("YEAR") + "年"
								+ data.get("MONTH") + "月";

						int rmoney = 0, rmoney1 = 0; //奖励，惩罚
						int smoney2 = 0;  //基本工资
						int  month3=0;     //循环的月份
						String jname2=null;
						String sql4=" select extract(month from ajtime )  as month3  from adjust where eid='"+eid2+"'";
						List<Map<String, Object>> list5 = db.find(sql4, null);
						for (Map<String, Object> map : list5) {
							month3=Integer.parseInt((String) map
									.get("MONTH3"));
						}
						if(month2>=month3){
							String sql5="select smoney,j.name  from emp  e , salary s ,adjust a ,job j where  e.jid=s.jid and a.eid=e.eid and e.jid=j.jid  and e.eid='"+eid2+"'";
							List<Map<String, Object>> list6 = db.find(sql5, null);
							
							for (Map<String, Object> map : list6) {
								smoney2 = Integer.parseInt((String) map
										.get("SMONEY"));
								jname2=(String) map.get("NAME");
							}
							
						}else{
							
							String sql6=" select smoney,j.name from job j ,salary s where j.jid=s.jid  and j.name='实习生' ";
							List<Map<String, Object>> list7 = db.find(sql6, null);
							for (Map<String, Object> map : list7) {
								smoney2 = Integer.parseInt((String) map
										.get("SMONEY"));
								jname2=(String) map.get("NAME");
							}
						}
						

						String sql3 = " select type,rmoney from rm  where eid='"
								+ eid2
								+ "'"
								+ "  and extract(month from gaintime)='"
								+ month2 + "'";
						String type = null;

						List<Map<String, Object>> list3 = db.find(sql3, null);
						for (Map<String, Object> map : list3) {
							type = (String) map.get("TYPE");

							if (type.equals("奖励")) {
								rmoney += Integer.parseInt((String) map
										.get("RMONEY"));
							} else {
								rmoney1 -= Integer.parseInt((String) map
										.get("RMONEY"));
							}
						}

						tol = rmoney + rmoney1 + smoney2
								+ Integer.parseInt((String) data.get("WMONEY"));
						str = new String[] { eid2, ename2, sex2, dname2,
								jname2, String.valueOf(smoney2), wmoney2,
								String.valueOf(rmoney),
								String.valueOf(rmoney1), gaintime,
								String.valueOf(tol) };
						ti.setText(str);

						summoney += tol;
					}

				}
				text.setText(summoney + "");
			}
		});
	}

	public void initCombo() {
		String sql = "select  name from dept ";
		DBHelper db = new DBHelper();
		combo_1.removeAll();
		combo_1.add("全部");
		List<Map<String, Object>> list = db.find(sql, null);
		for (Map<String, Object> map : list) {
			String ename = (String) map.get("NAME");
			combo_1.add(ename);
		}
		combo_1.select(0);
	}
}
