package cn.pm.ui;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import cn.pm.chart.showBar;
import cn.pm.dialog.TTMAddDialog;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.experimental.chart.swt.ChartComposite;
import org.jfree.ui.RefineryUtilities;

public class SalayManagement extends Composite {
	private static DefaultCategoryDataset dataset;
	private JFreeChart chart;
	private Composite composite_2;

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public SalayManagement(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_DEFAULT);

		setBackground(SWTResourceManager.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		setLayout(new FillLayout(SWT.HORIZONTAL));
		setSize(1414, 760);
		SashForm sashForm = new SashForm(this, SWT.VERTICAL);
		sashForm.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));

		Composite composite = new Composite(sashForm, SWT.NONE);

		Label lblNewLabel = new Label(composite, SWT.NONE);
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				IncomeAccount window = new IncomeAccount();
				window.open();

			}
		});
		lblNewLabel.setBackgroundImage(SWTResourceManager.getImage(
				SalayManagement.class, "/image/b1 (2).jpg"));
		lblNewLabel.setBounds(312, 205, 214, 230);
		lblNewLabel.setText("双击查询->报表");

		Label label = new Label(composite, SWT.NONE);
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				showBar sb = new showBar();
		        sb.open();
			}
		});
		label.setBackgroundImage(SWTResourceManager.getImage(
				SalayManagement.class, "/image/b1 (2).jpg"));
		label.setBounds(731, 205, 219, 212);
		label.setText("双击查询->图表");
		sashForm.setWeights(new int[] { 87 });

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
