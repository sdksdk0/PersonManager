package cn.pm.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import cn.pm.dao.DBHelper;
import cn.pm.main.MainUi;
import cn.pm.main.MainUiUser;
import cn.pm.utils.Common;
import cn.pm.utils.MD5;

import org.eclipse.swt.widgets.Group;

public class NoticeManagement extends Composite {
	private Table table;
	private Text text;
	private Text text_1;
	private Shell shell;

	DBHelper db = new DBHelper();
	private List<Object> params;
	private Text text_2;
	private Event event;

	private Button button_1;

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public NoticeManagement(Composite parent, int style) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setBackgroundMode(SWT.INHERIT_FORCE);

		shell = parent.getShell();
		setSize(1414, 760);
		setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group = new Group(this, SWT.NONE);

		group.setBackgroundMode(SWT.INHERIT_FORCE);

		group.setText("当前是>系统设置>发布公告");
		group.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(group, SWT.NONE);

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setBackgroundMode(SWT.INHERIT_FORCE);

		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_1 = new SashForm(composite_1, SWT.VERTICAL);

		Composite composite_2 = new Composite(sashForm_1, SWT.NONE);
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_2 = new SashForm(composite_2, SWT.VERTICAL);

		Composite composite_4 = new Composite(sashForm_2, SWT.NONE);

		button_1 = new Button(composite_4, SWT.NONE);

		button_1.setBounds(532, 31, 98, 30);
		button_1.setText("查询");

		Label label = new Label(composite_4, SWT.NONE);
		label.setBounds(43, 36, 76, 20);
		label.setText("公告号：");

		text_1 = new Text(composite_4, SWT.BORDER);
		text_1.setBounds(169, 33, 145, 26);

		table = new Table(sashForm_2, SWT.BORDER | SWT.FULL_SELECTION);

		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(203);
		tableColumn.setText("公告号");

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(348);
		tableColumn_1.setText("内容");

		Menu menu = new Menu(table);
		table.setMenu(menu);

		MenuItem menuItem = new MenuItem(menu, SWT.NONE);

		menuItem.setText("删除");

		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(383);
		tableColumn_2.setText("发布时间");
		sashForm_2.setWeights(new int[] { 46, 99 });

		Composite composite_3 = new Composite(sashForm_1, SWT.NONE);
		composite_3.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_3 = new SashForm(composite_3, SWT.VERTICAL);

		Composite composite_5 = new Composite(sashForm_3, SWT.NONE);
		composite_5.setLayout(null);

		Label label_1 = new Label(composite_5, SWT.NONE);
		label_1.setBounds(364, 69, 79, 29);
		label_1.setText("内容：");

		text = new Text(composite_5, SWT.BORDER);
		text.setBounds(485, 81, 476, 256);

		Label label_2 = new Label(composite_5, SWT.NONE);
		label_2.setBounds(364, 31, 76, 20);
		label_2.setText("公告号：");

		text_2 = new Text(composite_5, SWT.BORDER | SWT.READ_ONLY);
		text_2.setBounds(485, 28, 213, 26);
		sashForm_3.setWeights(new int[] { 206 });
		sashForm_1.setWeights(new int[] { 242, 266 });

		event = new Event();
		event.widget = button_1;

		Button btnNewButton = new Button(composite_4, SWT.NONE);
		btnNewButton.setBounds(682, 31, 98, 30);
		btnNewButton.setText("修改");

		Button button = new Button(composite_4, SWT.NONE);
		button.setBounds(824, 28, 98, 36);
		button.setText("发布");

		Button button_2 = new Button(composite_4, SWT.NONE);
		button_2.setBounds(377, 31, 98, 30);
		button_2.setText("重置");

		Button button_3 = new Button(composite_4, SWT.NONE);
		button_3.setBounds(992, 31, 98, 30);
		button_3.setText("邮件群发");

		// 邮件群发
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String notify = text.getText().trim();
				String address = null;

				String sql = " select  email  from emp  ";
				DBHelper db = new DBHelper();
				List<Map<String, Object>> list = db.find(sql, null);
				if (list != null && !"".equals(list)) {
					for (Map<String, Object> map : list) {

						address = (String) map.get("EMAIL");

						Properties props = new Properties();
						props.setProperty("mail.smtp.auth", "true");
						props.setProperty("mail.transport.protocol", "smtp");
						Session session = Session.getInstance(props);
						session.setDebug(true);

						Message msg = new MimeMessage(session);
						try {
							msg.setText(notify);
							msg.setFrom(new InternetAddress(
									"邮箱账号"));

							Transport transport = session.getTransport();
							transport.connect("邮箱驱动接口", 25,
									"邮箱账号", "密码");

							transport
									.sendMessage(
											msg,
											new Address[] { new InternetAddress(
													address) });
							transport.close();
						} catch (AddressException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (NoSuchProviderException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (MessagingException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				MessageDialog.openInformation(shell, "成功", "公告已群发！");
			}
		});

		// 清空
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text_1.setText("");
				text.setText("");
				text_2.setText("");
			}
		});

		// 添加,发布
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String nid = text_1.getText().toString().trim();
				String content = text.getText().toString().trim();

				if (content == null || "".equals(content)) {
					MessageDialog.openError(shell, "错误", "内容不能为空");
					return;
				}

				String sql = "insert into notify  values( ";

				if (nid != null && !"".equals(nid)) {
					sql += " nid,   ";
				} else {
					sql += " seq_notify_nid.nextval,";
				}
				sql += "  ?,sysdate)";

				params = new ArrayList<Object>();
				params.add(content);

				int result = db.update(sql.toString(), params);
				if (result > 0) {

					button_1.notifyListeners(SWT.Selection, event);
					MessageDialog.openConfirm(shell, "成功", "发布成功!");
					MainUi.label_4.setText(content);
					text_1.setText("");
					text.setText("");
				} else {
					MessageDialog.openError(shell, "错误", "发布失败！");
				}
			}
		});

		// 修改,更新
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String nid = text_2.getText().toString().trim();
				String content = text.getText().toString().trim();

				if (content == null || "".equals(content)) {
					MessageDialog.openError(shell, "错误", "内容不能为空");
					return;
				}

				try {
					String sql = "update  notify  set content=? ,time=sysdate where  nid=?";
					params = new ArrayList<Object>();
					params.add(content);
					params.add(nid);

					int result = db.update(sql, params);
					if (result > 0) {

						button_1.notifyListeners(SWT.Selection, event);
						MessageDialog.openConfirm(shell, "成功", "修改成功!");
						text_2.setText("");
						text.setText("");

					} else {

						MessageDialog.openError(shell, "错误", "修改失败！");
					}
				} catch (Exception e1) {

					e1.printStackTrace();
				}

			}
		});

		// 树被选中的时候
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String nid = ti.getText(0);
				String content = ti.getText(1);

				text.setText(content);
				text_2.setText(nid);

			}
		});

		// 右键删除
		menuItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				deleteMethod(button);
			}

		});

		// 查询按钮
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String nid = text_1.getText().trim();

				String sql = "select *from notify ";

				if (nid != null && !"".equals(nid)) {
					sql += " where nid= '" + nid + "'";
				}

				try {
					table.removeAll();
					List<Map<String, Object>> list = db.find(sql, null);
					if (list != null && list.size() > 0) {
						for (Map<String, Object> map : list) {
							TableItem tableItem = new TableItem(table, SWT.NONE);
							tableItem.setText(new String[] {
									(String) map.get("NID"),
									(String) map.get("CONTENT"),
									(String) map.get("TIME") });
						}
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}
			}
		});

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setBackgroundImage(SWTResourceManager.getImage(NoticeManagement.class, "/image/e3.jpg"));
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));
		sashForm.setWeights(new int[] { 549, 136 });
	}

	@Override
	protected void checkSubclass() {

	}

	private void deleteMethod(Button button) {
		TableItem[] tis = table.getSelection();

		if (tis == null || tis.length <= 0) {
			return;
		}
		TableItem ti = tis[0];
		String nid = ti.getText(0);

		String sql = "delete from notify  where nid='" + nid + "'";
		DBHelper db = new DBHelper();
		int result = db.update(sql, null);
		if (result > 0) {
			MessageDialog.openConfirm(shell, "成功", "删除成功");
			button_1.notifyListeners(SWT.Selection, event);

		} else {
			MessageDialog.openError(shell, "错误", "删除失败！");
		}
	}
}
