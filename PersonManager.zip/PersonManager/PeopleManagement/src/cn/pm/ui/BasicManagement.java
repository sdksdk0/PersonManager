package cn.pm.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.layout.TreeColumnLayout;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

import cn.pm.dao.DBHelper;

import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.events.VerifyEvent;

public class BasicManagement extends Composite {
	private Text text;
	private Text text_1;
	private Table table;
	private Text text_2;
	static Combo combo;
	private Shell shell = null;
	DBHelper db = new DBHelper();

	private Event event; // 与按钮绑定的事件
	private int pagesize = 8;
	// 第几页
	private int page = 1;
	private int totalpages;

	private Button button_3;
	private Combo combo_1;

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public BasicManagement(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_FORCE);
		
		shell = parent.getShell();
		setLayout(new FillLayout(SWT.HORIZONTAL));
		setSize(1414, 760);
		SashForm sashForm = new SashForm(this, SWT.NONE);
		sashForm.setBackgroundMode(SWT.INHERIT_DEFAULT);

		Group group = new Group(sashForm, SWT.NONE);
	
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setText("当前是>薪资管理>基本工资管理");
		group.setBackgroundMode(SWT.INHERIT_DEFAULT);

		Label label = new Label(group, SWT.SEPARATOR | SWT.HORIZONTAL);
		label.setBounds(-50, 76, 1422, 16);

		Label label_1 = new Label(group, SWT.SEPARATOR);
		label_1.setBounds(120, 127, 14, 623);

		Label label_2 = new Label(group, SWT.NONE);
		label_2.setBounds(193, 127, 76, 20);
		label_2.setText("工资号：");

		Label label_3 = new Label(group, SWT.NONE);
		label_3.setBounds(543, 127, 76, 20);
		label_3.setText("职务名：");

		text = new Text(group, SWT.BORDER);
		text.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent e) {
				Pattern pattern = Pattern.compile("[0-9]\\d*");
				Matcher matcher = pattern.matcher(e.text);
				if (matcher.matches()) // 处理数字
					e.doit = true;
				else if (e.text.length() > 0) // 有字符情况,包含中文、空格
					e.doit = false;
				else
					// 控制键
					e.doit = true;

			}
		});
		text.setBounds(331, 124, 73, 26);

		combo = new Combo(group, SWT.READ_ONLY);
		combo.setBounds(681, 124, 131, 28);

		Label label_4 = new Label(group, SWT.NONE);
		label_4.setBounds(286, 574, 76, 20);
		label_4.setText("基本工资：");

		text_1 = new Text(group, SWT.BORDER);
		text_1.setBounds(437, 571, 124, 26);

		Button button_1 = new Button(group, SWT.NONE);

		button_1.setBounds(1060, 40, 98, 30);
		button_1.setText("修改");

		button_3 = new Button(group, SWT.NONE);

		button_3.setBounds(760, 40, 98, 30);
		button_3.setText("查询");

		Button button_4 = new Button(group, SWT.NONE);

		button_4.setBounds(591, 40, 98, 30);
		button_4.setText("重置");

		table = new Table(group, SWT.BORDER | SWT.FULL_SELECTION);

		table.setBounds(128, 172, 1055, 226);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(260);
		tableColumn_5.setText("基本工资号");

		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(295);
		tableColumn_4.setText("职务号");

		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(245);
		tableColumn_2.setText("职务名");

		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(156);
		tableColumn_3.setText("基本工资");

		Button btnNewButton = new Button(group, SWT.NONE);

		btnNewButton.setBounds(1060, 430, 98, 30);
		btnNewButton.setText("下一页");

		Button btnNewButton_1 = new Button(group, SWT.NONE);

		btnNewButton_1.setBounds(884, 430, 98, 30);
		btnNewButton_1.setText("上一页");

		Label label_5 = new Label(group, SWT.NONE);
		label_5.setBounds(348, 435, 420, 20);

		Label label_6 = new Label(group, SWT.NONE);
		label_6.setBounds(286, 500, 76, 20);
		label_6.setText("工资号：");

		text_2 = new Text(group, SWT.BORDER);
		text_2.setEditable(false);
		text_2.setBounds(434, 497, 127, 26);
		sashForm.setWeights(new int[] { 1 });

		Button button = new Button(group, SWT.NONE);

		button.setBounds(1229, 40, 98, 30);
		button.setText("删除");

		Label label_7 = new Label(group, SWT.NONE);
		label_7.setBounds(286, 639, 76, 20);
		label_7.setText("职务名：");

		combo_1 = new Combo(group, SWT.READ_ONLY);
		combo_1.setBounds(437, 636, 124, 28);

		Button button_2 = new Button(group, SWT.NONE);

		button_2.setBounds(906, 40, 98, 30);
		button_2.setText("添加");

		intiCombo();
		event = new Event();
		event.widget = button_3;
	
		// 添加
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String smoney = text_1.getText().trim();
				String jname = combo_1.getText().trim();

				String sql = "insert into salary values(seq_salary_said.nextval,(select jid from job where name=?),?)";

				if (jname != null && !"".equals(jname) && smoney != null
						&& !"".equals(smoney)) {

					try {
						List<Object> params = new ArrayList<Object>();
						params.add(jname);
						params.add(smoney);

						int rs = db.update(sql, params);
						if (rs > 0) {
							button_3.notifyListeners(SWT.Selection, event);
							MessageDialog.openInformation(shell, "成功", "添加成功！");
						} else {
							MessageDialog.openError(shell, "错误", "添加失败");
						}
					} catch (Exception e1) {
						e1.printStackTrace();
						MessageDialog.openError(shell, "错误", e1.getMessage());
					}
				}
			}
		});

		// 删除
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();

				if (tis == null || tis.length <= 0) {
					return;
				}
				TableItem ti = tis[0];
				String said = ti.getText(0);

				String sql = "delete from salary  where said='" + said + "'";
				DBHelper db = new DBHelper();
				int result = db.update(sql, null);
				if (result > 0) {
					button_3.notifyListeners(SWT.Selection, event);
					MessageDialog.openConfirm(shell, "成功", "删除成功");
				} else {
					MessageDialog.openError(shell, "错误", "删除失败！");
				}

			}
		});

		// 修改
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String said = text_2.getText().toString().trim();
				String smoney = text_1.getText().toString().trim();

				if (smoney == null || "".equals(smoney)) {
					MessageDialog.openError(shell, "错误", "基本工资不能为空");
					return;
				}

				String sql = "update  salary set smoney=?  where  said=?";
				List<Object> params = new ArrayList<Object>();
				params.add(smoney);
				params.add(said);

				int result = db.update(sql, params);
				if (result > 0) {
					button_3.notifyListeners(SWT.Selection, event);
					MessageDialog.openConfirm(shell, "成功", "修改成功!");
					text.setText("");
					text_1.setText("");

				} else {
					MessageDialog.openError(shell, "错误", "修改失败！");
				}
			}
		});

		// 重置
		button_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				text_1.setText("");
				text_2.setText("");
			}
		});

		// 下一页
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page++;
				if (page > totalpages) {
					MessageDialog.openError(shell, "错误", "已经是最后一页了！");
					page = totalpages;
				}
				button_3.notifyListeners(SWT.Selection, event);
			}
		});

		// 上一页
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page--;
				if (page <= 0) {
					MessageDialog.openError(shell, "错误", "没有上一页了！");
					page = 1;
					return;
				}
				button_3.notifyListeners(SWT.Selection, event);

			}
		});

		// 表被选中的时候
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String said = ti.getText(0);
				String jid = ti.getText(1);
				String jname = ti.getText(2);
				String smoney = ti.getText(3);

				text_2.setText(said);
				text_1.setText(smoney);
				combo_1.setText(jname);
			}
		});

		// 查询
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String said = text.getText().toString().trim();
				String jname = combo.getText().toString().trim();

				List<Object> params = new ArrayList<Object>();
				String sql = " select *from (select A.*,rownum rn from ( select s.said,s.jid,j.name as jname,smoney from salary s,job j where s.jid=j.jid   ";
				if (said != null && !"".equals(said)) {
					sql += " and s.said=? ";
					params.add(said);
				}
				if(jname.equals("全部")){
					sql+=" ";
				}else if (jname != null && !"".equals(jname)) {
					sql += " and j.name=?  ";
					params.add(jname);
				}

				int max = page * pagesize;
				int min = (page - 1) * pagesize;
				sql += " ) A where rownum<? ) where rn>?";
				params.add(max);
				params.add(min);

				table.removeAll();
				List<Map<String, Object>> list = db.find(sql, params);

				if (list != null && list.size() > 0) {
					for (Map<String, Object> map : list) {
						TableItem tableItem = new TableItem(table, SWT.NONE);
						tableItem.setText(new String[] {
								(String) map.get("SAID"),
								(String) map.get("JID"),
								(String) map.get("JNAME"),
								(String) map.get("SMONEY") });
					}
				}
				String sql2 = "select count(*) from salary s,job j where s.jid=j.jid  ";
				List<String> params2 = new ArrayList<String>();
				if (said != null && !"".equals(said)) {
					sql2 += " and s.said=? ";
					params2.add(said);
				}
				if(jname.equals("全部")){
					sql+=" ";
				}else if (jname != null && !"".equals(jname)) {
					sql2 += " and j.name=?  ";
					params2.add(jname);
				}
				int count = (int) db.doSelectFunction(sql2, params2);

				totalpages = count % pagesize == 0 ? count / pagesize : count
						/ pagesize + 1;
				label_5.setText("第" + page + "页/ 共" + totalpages + "页/ 共"
						+ count + "条数据");
				
				text_1.setText("");
				text_2.setText("");
				combo_1.setText("");
			}
		});
	}

	public void intiCombo() {
		String sql = "select *from job";

		try {
			List<Map<String, Object>> list = db.find(sql, null);
			if (list != null && list.size() > 0) {
				combo.removeAll();
				combo_1.removeAll();
				for (Map<String, Object> map : list) {
					String jname = (String) map.get("NAME");
					combo.add(jname);
					combo_1.add(jname);
				}
				combo.add("全部");
				combo_1.add("");
			}
		} catch (Exception e) {
			e.printStackTrace();
			MessageDialog.openError(shell, "错误", e.getMessage());
		}

	}

	@Override
	protected void checkSubclass() {
	}
}
