package cn.pm.ui;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.TableTree;
import org.eclipse.swt.widgets.TableColumn;

public class DefaultIndex extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public DefaultIndex(Composite parent, int style) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(240, 248, 255));
		setLayout(new FillLayout(SWT.HORIZONTAL));
		
		Group group = new Group(this, SWT.NONE);
		group.setText("欢迎登录");
		group.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		Label label = new Label(group, SWT.NONE);
		label.setAlignment(SWT.CENTER);
		label.setImage(SWTResourceManager.getImage(DefaultIndex.class, "/image/a4.jpg"));

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
