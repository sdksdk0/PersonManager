package cn.pm.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.ImageData;

import cn.pm.biz.FileBiz;
import cn.pm.dao.DBHelper;
//import cn.pm.utils.LayoutUtil;

import cn.pm.utils.Common;
import cn.pm.utils.DBtoExcel;
import cn.pm.utils.ExceltoDB;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

import com.ibm.icu.text.SimpleDateFormat;

import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.events.VerifyEvent;

public class FileManagement extends Composite {
	private Table table;
	private Text text;
	private Text text_6;
	private Text text_1;
	private Text text_2;
	private Text picpath;
	private Combo combo;
	private Button button_4;
	private Text text_7;

	private Shell shell;
	private MenuItem menuItem;

	private Event event; // 与按钮绑定的事件
	private DBHelper db = new DBHelper();
	private int pagesize = 8;
	// 第几页
	private int page = 1;
	private int totalpages;

	private DateTime dateTime;
	private Button button;
	private Display display;
	private Label pic;
	private Combo combo_2;
	private Combo combo_3;
	private Combo combo_4;
	public static  Combo combo_5;
	private Text text_3;
	private Combo combo_1;

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public FileManagement(Composite parent, int style) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setBackgroundMode(SWT.INHERIT_FORCE);

		shell = parent.getShell();
		display = parent.getDisplay();

		setLayout(new FillLayout(SWT.HORIZONTAL));
		setSize(1414, 760);
		SashForm sashForm = new SashForm(this, SWT.VERTICAL);

		Composite composite_2 = new Composite(sashForm, SWT.NONE);
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_1 = new SashForm(composite_2, SWT.VERTICAL);

		Composite composite_4 = new Composite(sashForm_1, SWT.NONE);

		Group group_1 = new Group(composite_4, SWT.NONE);
		group_1.setText("当前是>员工管理>档案管理");
		group_1.setBounds(0, 0, 342, 41);

		Composite composite_5 = new Composite(sashForm_1, SWT.NONE);
		sashForm_1.setWeights(new int[] { 39, 178 });

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		TabFolder tabFolder = new TabFolder(composite, SWT.NONE);

		TabItem tbtmNewItem = new TabItem(tabFolder, SWT.NONE);
		tbtmNewItem.setText("档案信息");

		Composite composite_3 = new Composite(tabFolder, SWT.NONE);
		tbtmNewItem.setControl(composite_3);
		composite_3.setLayout(new FillLayout(SWT.HORIZONTAL));

		table = new Table(composite_3, SWT.BORDER | SWT.FULL_SELECTION);

		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(115);
		tblclmnNewColumn.setText("员工号");

		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(134);
		tblclmnNewColumn_1.setText("员工名");

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(130);
		tableColumn.setText("部门名");

		TableColumn tblclmnNewColumn_8 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_8.setWidth(132);
		tblclmnNewColumn_8.setText("职务名");

		TableColumn tblclmnNewColumn_9 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_9.setWidth(134);
		tblclmnNewColumn_9.setText("状态");

		TableColumn tblclmnNewColumn_2 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_2.setWidth(121);
		tblclmnNewColumn_2.setText("性别");

		TableColumn tblclmnNewColumn_4 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_4.setWidth(127);
		tblclmnNewColumn_4.setText("电话");

		TableColumn tblclmnNewColumn_6 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_6.setWidth(143);
		tblclmnNewColumn_6.setText("地址");

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(142);
		tableColumn_1.setText("出生日期");

		Menu menu = new Menu(table);
		table.setMenu(menu);

		menuItem = new MenuItem(menu, SWT.NONE);
		menuItem.setText("删除");

		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(207);
		tableColumn_2.setText("邮箱");

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_2 = new SashForm(composite_1, SWT.VERTICAL);

		Composite composite_7 = new Composite(sashForm_2, SWT.NONE);

		Button btnNewButton_2 = new Button(composite_7, SWT.NONE);

		btnNewButton_2.setBounds(1205, 10, 98, 30);
		btnNewButton_2.setText("下一页");

		Button btnNewButton_3 = new Button(composite_7, SWT.NONE);

		btnNewButton_3.setBounds(1029, 10, 98, 30);
		btnNewButton_3.setText("上一页");

		Label label_1 = new Label(composite_7, SWT.NONE);
		label_1.setBounds(601, 20, 336, 20);

		Button btnNewButton_1 = new Button(composite_7, SWT.NONE);
		btnNewButton_1.setBounds(20, 15, 73, 38);
		btnNewButton_1.setText("修改");

		Button button_1 = new Button(composite_7, SWT.NONE);
		button_1.setBounds(150, 10, 73, 38);
		button_1.setText("添加");

		Button btnNewButton = new Button(composite_7, SWT.NONE);
		btnNewButton.setBounds(299, 10, 76, 43);
		btnNewButton.setText("删除");
		
		Composite composite_6 = new Composite(sashForm_2, SWT.NONE);

		Group group = new Group(composite_6, SWT.NONE);
		group.setLocation(0, 0);
		group.setSize(1392, 293);

		group.setText("操作");
		group.setLayout(null);

		Label lblNewLabel = new Label(group, SWT.NONE);
		lblNewLabel.setBounds(96, 32, 48, 17);
		lblNewLabel.setText("员工号:");

		text = new Text(group, SWT.BORDER);
		text.setEditable(false);
		text.setBounds(154, 29, 64, 23);

		Label lblNewLabel_4 = new Label(group, SWT.NONE);
		lblNewLabel_4.setBounds(96, 107, 48, 17);
		lblNewLabel_4.setText("部门名:");

		Label lblNewLabel_6 = new Label(group, SWT.NONE);
		lblNewLabel_6.setBounds(96, 233, 39, 17);
		lblNewLabel_6.setText("电话:");

		text_6 = new Text(group, SWT.BORDER);
		text_6.setBounds(158, 230, 141, 23);

		Label label_3 = new Label(group, SWT.NONE);
		label_3.setText("地址:");
		label_3.setBounds(96, 184, 39, 17);

		text_1 = new Text(group, SWT.BORDER);
		text_1.setBounds(154, 181, 147, 23);

		Label lblNewLabel_1 = new Label(group, SWT.NONE);
		lblNewLabel_1.setBounds(360, 32, 61, 17);
		lblNewLabel_1.setText("员工名：");

		text_2 = new Text(group, SWT.BORDER);
		text_2.setBounds(447, 29, 73, 23);

		Label lblNewLabel_2 = new Label(group, SWT.NONE);
		lblNewLabel_2.setBounds(360, 107, 61, 17);
		lblNewLabel_2.setText("职务名：");

		Label lblNewLabel_5 = new Label(group, SWT.NONE);
		lblNewLabel_5.setBounds(674, 107, 62, 27);
		lblNewLabel_5.setText("性别：");

		Label lblNewLabel_7 = new Label(group, SWT.NONE);
		lblNewLabel_7.setBounds(360, 184, 61, 17);
		lblNewLabel_7.setText("出生日期");

		Label lblNewLabel_8 = new Label(group, SWT.NONE);
		lblNewLabel_8.setBounds(676, 32, 39, 27);
		lblNewLabel_8.setText("状态");

		combo = new Combo(group, SWT.READ_ONLY);
		combo.setItems(new String[] { "在职", "离职", "退休" });
		combo.setBounds(746, 27, 88, 25);
		combo.select(0);

		Label label_6 = new Label(group, SWT.NONE);
		label_6.setBounds(940, 32, 48, 20);
		label_6.setText("照片：");

		Label label_7 = new Label(group, SWT.NONE);
		label_7.setBounds(963, 233, 76, 20);
		label_7.setText("图片地址：");

		picpath = new Text(group, SWT.BORDER);
		picpath.setBounds(1045, 230, 147, 26);

		button_4 = new Button(group, SWT.NONE);

		button_4.setBounds(1214, 228, 98, 30);
		button_4.setText("浏览");

		pic = new Label(group, SWT.BORDER);
		pic.setBackground(SWTResourceManager
				.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		pic.setBounds(1023, 32, 214, 169);

		combo_1 = new Combo(group, SWT.NONE);
		combo_1.setItems(new String[] { "男", "女" });
		combo_1.select(0);
		combo_1.setBounds(742, 104, 92, 28);

		dateTime = new DateTime(group, SWT.BORDER);
		dateTime.setBounds(447, 184, 110, 28);

		combo_4 = new Combo(group, SWT.READ_ONLY);
		combo_4.setBounds(154, 104, 92, 28);

		combo_5 = new Combo(group, SWT.READ_ONLY);
		combo_5.setEnabled(false);
		combo_5.setBounds(447, 104, 92, 28);

		Label label_2 = new Label(group, SWT.NONE);
		label_2.setBounds(676, 184, 64, 20);
		label_2.setText("邮箱：");

		text_3 = new Text(group, SWT.BORDER);

		text_3.setBounds(746, 181, 115, 26);
		sashForm_2.setWeights(new int[] { 55, 274 });

		composite_5.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group_3 = new Group(composite_5, SWT.NONE);
		group_3.setLayout(null);

		button = new Button(group_3, SWT.NONE);
		button.setBounds(843, 22, 93, 31);

		button.setText("查询");

		Label label = new Label(group_3, SWT.NONE);
		label.setBounds(569, 27, 59, 20);
		label.setText("部门：");

		Label label_4 = new Label(group_3, SWT.NONE);
		label_4.setBounds(20, 27, 59, 20);
		label_4.setText("员工名：");

		text_7 = new Text(group_3, SWT.BORDER);
		text_7.setBounds(118, 24, 73, 26);

		Button btnNewButton_4 = new Button(group_3, SWT.NONE);

		btnNewButton_4.setBounds(990, 22, 98, 30);
		btnNewButton_4.setText("重置");

		combo_2 = new Combo(group_3, SWT.NONE);
		combo_2.setBounds(665, 24, 92, 28);

		combo_3 = new Combo(group_3, SWT.NONE);
		combo_3.setBounds(385, 24, 92, 28);

		Label label_5 = new Label(group_3, SWT.NONE);
		label_5.setBounds(257, 27, 59, 20);
		label_5.setText("职务：");

		sashForm.setWeights(new int[] { 123, 240, 306 });
	
		Button button_2 = new Button(group_3, SWT.NONE);

		button_2.setBounds(1134, 22, 98, 30);
		button_2.setText("导入数据");

		Button button_3 = new Button(group_3, SWT.NONE);

		button_3.setBounds(1274, 22, 98, 30);
		button_3.setText("导出数据");
		
		initCombo();
		event = new Event();
		event.widget = button;

		
		
		// 按键删除
				btnNewButton.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						String eid = text.getText().trim();
						String sql = "delete from emp where eid='" + eid + "'";
						try {
							int result = db.update(sql, null);
							if (result > 0) {
								button.notifyListeners(SWT.Selection, event);
								MessageDialog.openConfirm(shell, "成功", "删除成功");
								Common.rpm.initCombo();
								Common.scm.initCombo();
								Common.tm.initCombo2();
								Common.ttm.initCombo();
								Common.cm.intiCombo();
								Common.as.intiCombo();
								clear();
							} else {
								MessageDialog.openError(shell, "错误", "删除失败！");
							}
						} catch (Exception e1) {
							MessageDialog.openError(shell, "错误", e1.getMessage());
							return;
						}
					}
				});

				// 添加
				button_1.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						String eid = text.getText().toString().trim();
						String ename = text_2.getText().toString().trim();
						String dname = combo_4.getText().trim();
						String jname = combo_5.getText().trim();
						String status = combo.getText().toString().trim();
						String sex = combo_1.getText().trim();
						String tel = text_6.getText().trim();
						String address = text_1.getText().trim();
						String birthday = LayoutUtil.parseDateTime(dateTime);
						String email = text_3.getText().trim();

						String photopath = picpath.getText().toString().trim();

						String sql1 = "select did from dept where name='" + dname + "'";
						String sql2 = "select jid from job where name='" + jname + "'";

						String did = null;
						String jid = null;
						List<Map<String, Object>> list1 = db.find(sql1, null);
						if (list1 != null && !"".equals(list1)) {
							for (Map<String, Object> map : list1) {
								did = (String) map.get("DID");
							}
						}
						List<Map<String, Object>> list2 = db.find(sql2, null);
						if (list1 != null && !"".equals(list2)) {
							for (Map<String, Object> map : list2) {
								jid = (String) map.get("JID");
							}
						}

						FileBiz fb = new FileBiz();
						try {
							int r = fb.saveEMP(eid, ename, did, jid, status, sex, tel,
									address, birthday, photopath, email);
							if (r > 0) {
								button.notifyListeners(SWT.Selection, event);
								MessageDialog.openConfirm(shell, "成功", "添加成功!");
								Common.rpm.initCombo();
								Common.scm.initCombo();
								Common.tm.initCombo2();
								Common.ttm.initCombo();
								Common.cm.intiCombo();
								Common.as.intiCombo();
								clear();
							} else {
								MessageDialog.openError(shell, "失败", "添加失败!");
							}

						} catch (Exception e2) {
							e2.printStackTrace();
							MessageDialog.openError(shell, "错误", e2.getMessage());
							return;
						}
					}
				});

				// 修改
				btnNewButton_1.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						String eid = text.getText().toString().trim();
						String ename = text_2.getText().toString().trim();
						String dname = combo_4.getText().trim();
						String jname = combo_5.getText().trim();
						String status = combo.getText().toString().trim();
						String sex = combo_1.getText().trim();
						String tel = text_6.getText().trim();
						String address = text_1.getText().trim();
						String birthday = LayoutUtil.parseDateTime(dateTime);
						String email = text_3.getText().trim();

						String photopath = picpath.getText().toString().trim();

						String sql1 = "select did from dept where name='" + dname + "'";
						String sql2 = "select jid from job where name='" + jname + "'";

						String did = null;
						String jid = null;
						List<Map<String, Object>> list1 = db.find(sql1, null);
						if (list1 != null && !"".equals(list1)) {
							for (Map<String, Object> map : list1) {
								did = (String) map.get("DID");
							}
						}
						List<Map<String, Object>> list2 = db.find(sql2, null);
						if (list1 != null && !"".equals(list2)) {
							for (Map<String, Object> map2 : list2) {
								jid = (String) map2.get("JID");
							}
						}
						FileBiz fb = new FileBiz();
						try {
							int rs = fb.updateEMP(eid, ename, did, jid, status, sex,
									tel, address, birthday, photopath, email);

							if (rs > 0) {
								button.notifyListeners(SWT.Selection, event);
								MessageDialog.openConfirm(shell, "成功", "修改成功!");
								Common.rpm.initCombo();
								Common.scm.initCombo();
								Common.tm.initCombo2();
								Common.ttm.initCombo();
								Common.cm.intiCombo();
								Common.as.intiCombo();
								clear();
							} else {
								MessageDialog.openError(shell, "失败", "修改失败");
							}
						} catch (Exception e2) {
							e2.printStackTrace();
							MessageDialog.openError(shell, "错误", e2.getMessage());
							return;
						}
					}
				});


		// 数据导入
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(shell, SWT.OPEN);
				dialog.setFilterPath(System.getProperty("user.home")); // 设置初始路径//设置打开默认的路径
				dialog.setFilterExtensions(new String[] { "*.*", "*.xls" });
				String fileName = dialog.open();
				if (fileName == null || "".equals(fileName)) {
					return;
				}

				ExceltoDB etd = new ExceltoDB();
				int rs = etd.excelToDB(fileName);
				if (rs > 0) {
					MessageDialog.openInformation(shell, "成功", "文件成功导入");
					button.notifyListeners(SWT.Selection, event);
				} else {
					MessageDialog.openError(shell, "错误", "文件导入失败");
				}
			}
		});

		// 数据导出
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				FileDialog dialog = new FileDialog(shell, SWT.SAVE);
				dialog.setFilterPath(System.getProperty("user.home")); // 设置初始路径//设置打开默认的路径
				dialog.setFilterExtensions(new String[] { "*.*", "*.xls" });
				String fileName = dialog.open();
				if (fileName == null || "".equals(fileName)) {
					return;
				}

				DBtoExcel dte = new DBtoExcel();
				int rs = dte.TOExcel(fileName);
				if (rs > 0) {
					MessageDialog
							.openInformation(shell, "成功", "文件成功导出，请在你桌面查看");
				} else {
					MessageDialog.openError(shell, "错误", "文件导出失败");
				}
			}
		});

		

		// 重置
		btnNewButton_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				clear();

			}
		});

		// 右键删除
		menuItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length <= 0) {
					return;
				}
				TableItem ti = tis[0];
				String eid = ti.getText(0);

				String sql = "delete from emp where eid='" + eid + "'";
				int result = db.update(sql, null);
				if (result > 0) {
					button.notifyListeners(SWT.Selection, event);
					MessageDialog.openConfirm(shell, "成功", "删除成功");
					Common.rpm.initCombo();
					Common.scm.initCombo();
					Common.tm.initCombo2();
					Common.ttm.initCombo();
					Common.cm.intiCombo();
					Common.as.intiCombo();
					clear();
				} else {
					MessageDialog.openError(shell, "错误", "删除失败！");
				}
			}
		});

		// 上一页
		btnNewButton_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page--;
				if (page <= 0) {
					MessageDialog.openError(shell, "错误", "没有上一页了！");
					page = 1;
					return;
				}
				button.notifyListeners(SWT.Selection, event);
			}
		});
		// 下一页
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page++;
				if (page > totalpages) {
					MessageDialog.openError(shell, "错误", "已经是最后一页了！");
					page = totalpages;
				}
				button.notifyListeners(SWT.Selection, event);
			}
		});

		// table被选中的时候
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String eid = ti.getText(0);
				String ename = ti.getText(1);
				String dname = ti.getText(2);
				String jname = ti.getText(3);
				String status = ti.getText(4);
				String sex = ti.getText(5);
				String tel = ti.getText(6);
				String address = ti.getText(7);
				String birthday = ti.getText(8).substring(0, 10);
				String email = ti.getText(9);

				text.setText(eid);
				text_2.setText(ename);
				combo_4.setText(dname);
				combo_5.setText(jname);
				combo.setText(status);
				combo_1.setText(sex);
				text_6.setText(tel);
				text_1.setText(address);

				try {
					LayoutUtil.showTime(dateTime, birthday);
				} catch (ParseException e1) {
					e1.printStackTrace();
				}
				text_3.setText(email);

				FileBiz fb = new FileBiz();

				ImageData imageData = fb.findPic(ti.getText(0));
				if (imageData != null) {
					LayoutUtil.showPic(display, pic, imageData);
				} else {
					picpath.setText("");
				}

			}
		});

		// 查询
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String dname = combo_2.getText().toString().trim();
				String jname = combo_3.getText().toString().trim();
				String ename = text_7.getText().toString().trim();

				StringBuffer sql = new StringBuffer(
						"select *from (select A.*,rownum rn from (select e.eid,e.name as ename ,d.name as dname ,j.name as jname, status,sex,tel,address,birthday,email   from emp e left join dept d on e.did=d.did   left join job j on e.jid=j.jid  where  1=1");

				List<Object> params = new ArrayList<Object>();

				if (ename != null && !"".equals(ename)) {
					sql.append("  and e.name like ?  ");
					params.add("%" + ename + "%");
				}
				if (dname.equals("全部")) {
					sql.append("  ");
				} else if (dname != null && !"".equals(dname)) {
					sql.append(" and   d.name like ? ");
					params.add("%" + dname + "%");
				}
				if (jname.equals("全部")) {
					sql.append(" ");
				} else if (jname != null && !"".equals(jname)) {
					sql.append(" and   j.name like ? ");
					params.add("%" + jname + "%");
				}

				int max = page * pagesize;
				int min = (page - 1) * pagesize;

				sql.append(") A where rownum<? ) where rn>?");
				params.add(max);
				params.add(min);

				try {
					table.removeAll();
					List<Map<String, Object>> list = db.find(sql.toString(),
							params);
					if (list != null && list.size() > 0) {
						for (Map<String, Object> map : list) {
							TableItem tableItem = new TableItem(table, SWT.NONE);
							String[] str = new String[] {
									(String) map.get("EID"),
									(String) map.get("ENAME"),
									(String) map.get("DNAME"),
									(String) map.get("JNAME"),
									(String) map.get("STATUS"),
									(String) map.get("SEX"),
									(String) map.get("TEL"),
									(String) map.get("ADDRESS"),
									(String) map.get("BIRTHDAY"),
									(String) map.get("EMAIL") };

							tableItem.setText(str);
						}
					}

					List<String> params2 = new ArrayList<String>();
					String sql2 = "select count(*) from emp e left join dept d on e.did=d.did   left join job j on e.jid=j.jid  where  1=1 ";
					if (ename != null && !"".equals(ename)) {
						sql2 += "  and e.name like ?  ";
						params2.add("%" + ename + "%");
					}
					if (dname.equals("全部")) {
						sql.append("  ");
					} else if (dname != null && !"".equals(dname)) {
						sql2 += " and   d.name like ? ";
						params2.add("%" + dname + "%");
					}
					if (jname.equals("全部")) {
						sql.append(" ");
					} else if (jname != null && !"".equals(jname)) {
						sql2 += " and   j.name like ? ";
						params2.add("%" + jname + "%");
					}
					int count = (int) db.doSelectFunction(sql2, params2);

					totalpages = count % pagesize == 0 ? count / pagesize
							: count / pagesize + 1;
					label_1.setText("第" + page + "页/ 共" + totalpages + "页/ 共"
							+ count + "条数据");

				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}
			}
		});

		// 浏览图片
		button_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// 打开一个文件对话框
				FileDialog dialog = new FileDialog(shell, SWT.OPEN);
				dialog.setFilterPath(System.getProperty("user.home")); // 设置初始路径
				dialog.setFilterExtensions(new String[] { "*.*", ".jpg",
						".gif", ".png", ".jpeg", ".bmp" });
				String fileName = dialog.open();
				if (fileName == null || "".equals(fileName)) {
					return;
				}
				// 选择完文件后把路径显示到text中
				picpath.setText(fileName);
				try {
					FileInputStream fis = new FileInputStream(
							new File(fileName));
					ImageData imageData = new ImageData(fis);
					LayoutUtil.showPic(display, pic, imageData);

				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}
			}
		});
	}

	public void initCombo() {
		String sql = "select  name from dept ";
		String sql2 = "select  name from job ";
		DBHelper db = new DBHelper();
		combo_2.removeAll();
		combo_3.removeAll();
		combo_4.removeAll();
		combo_5.removeAll();

		combo_2.add("全部");
		combo_3.add("全部");
		List<Map<String, Object>> list = db.find(sql, null);
		for (Map<String, Object> map : list) {
			String dname = (String) map.get("NAME");
			combo_2.add(dname);
			combo_4.add(dname);
		}
		List<Map<String, Object>> list2 = db.find(sql2, null);
		for (Map<String, Object> map : list2) {
			String jname = (String) map.get("NAME");
			combo_3.add(jname);
			combo_5.add(jname);
		}
		combo_2.select(0);
		combo_3.select(0);
	}

	@Override
	protected void checkSubclass() {
	}

	private void clear() {
		text_7.setText("");
		combo.setText("");
		combo_2.setText("");
		combo_3.setText("");
		combo_4.setText("");
		combo_5.setText("");
		text.setText("");
		text_2.setText("");
		text_6.setText("");
		text_1.setText("");

		picpath.setText("");
	}
}
