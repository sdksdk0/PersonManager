package cn.pm.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;

import swing2swt.layout.BoxLayout;
import swing2swt.layout.BorderLayout;

import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.GridData;

import cn.pm.dao.DBHelper;
import cn.pm.utils.Common;

public class PostManagement extends Composite {
	private Text text;
	private Text text_1;
	private Table table;
	private Text text_2;
	private Shell shell;
	DBHelper db = new DBHelper();
	private List<Object> params;

	private Event event;

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public PostManagement(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_FORCE);

		shell = parent.getShell();
		setSize(1414, 760);
		setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(this, SWT.VERTICAL);
		Group group = new Group(sashForm, SWT.NONE);
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setBackgroundMode(SWT.INHERIT_DEFAULT);
		
		group.setText("当前是>部门管理>职务管理");
		Label label = new Label(group, SWT.SEPARATOR | SWT.VERTICAL);
		label.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		label.setBounds(66, 45, 2, 213);

		Label label_1 = new Label(group, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_1.setBounds(43, 94, 380, 2);

		Label label_2 = new Label(group, SWT.NONE);
		label_2.setBounds(509, 558, 76, 20);
		label_2.setText("职务号：");

		text = new Text(group, SWT.BORDER);
		text.setEditable(false);
		text.setBounds(602, 555, 119, 26);

		Label label_3 = new Label(group, SWT.NONE);
		label_3.setBounds(509, 640, 76, 20);
		label_3.setText("职务名：");

		text_1 = new Text(group, SWT.BORDER);
		text_1.setBounds(608, 637, 119, 26);

		Button button = new Button(group, SWT.NONE);

		button.setBounds(930, 66, 98, 30);
		button.setText("添加");

		Button button_1 = new Button(group, SWT.NONE);

		button_1.setBounds(1237, 66, 98, 30);
		button_1.setText("删除");

		Button btnNewButton = new Button(group, SWT.NONE);

		btnNewButton.setBounds(1077, 66, 98, 30);
		btnNewButton.setText("修改");

		Label label_4 = new Label(group, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_4.setBounds(35, 540, 686, 9);

		Label label_5 = new Label(group, SWT.SEPARATOR | SWT.VERTICAL);
		label_5.setBounds(906, 479, 19, 324);

		Button button_2 = new Button(group, SWT.NONE);

		button_2.setText("查询");
		button_2.setBounds(769, 66, 98, 30);

		table = new Table(group, SWT.BORDER | SWT.FULL_SELECTION);

		table.setBounds(111, 211, 642, 300);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(321);
		tableColumn.setText("职务号");

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(317);
		tableColumn_1.setText("职务名");

		Menu menu = new Menu(table);
		table.setMenu(menu);

		MenuItem mntmS = new MenuItem(menu, SWT.NONE);

		mntmS.setText("删除");

		text_2 = new Text(group, SWT.BORDER);
		text_2.setBounds(201, 137, 73, 26);

		Label label_6 = new Label(group, SWT.NONE);
		label_6.setBounds(119, 140, 76, 20);
		label_6.setText("职务名：");

		event = new Event();
		event.widget = button_2;

		Button button_3 = new Button(group, SWT.NONE);

		button_3.setBounds(623, 66, 98, 30);
		button_3.setText("重置");

		Label label_7 = new Label(group, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_7.setBounds(571, 109, 341, 9);

		Label label_8 = new Label(group, SWT.SEPARATOR | SWT.VERTICAL);
		label_8.setBounds(408, 494, -19, 266);

		Label label_9 = new Label(group, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_9.setBounds(10, 45, 700, 2);

		// 重置
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				text_1.setText("");
				text_2.setText("");
			}
		});

		// 添加
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String jid = text.getText().toString().trim();
				String jname = text_1.getText().toString().trim();

				if (jname == null || "".equals(jname)) {
					MessageDialog.openError(shell, "错误", "职务名不能为空");
					return;
				}

				String sql = "insert into job  values( ";

				if (jid != null && !"".equals(jid)) {
					sql += " jid,   ";
				} else {
					sql += " seq_job_jid.nextval,";
				}
				sql += "  ?)";

				try {
					params = new ArrayList<Object>();
					params.add(jname);

					int result = db.update(sql.toString(), params);
					if (result > 0) {

						button_2.notifyListeners(SWT.Selection, event);
						MessageDialog.openConfirm(shell, "成功", "添加成功!");
						Common.bm.intiCombo();
						Common.fm.initCombo();
						Common.as.initCombo2();
						text.setText("");
						text_1.setText("");

					} else {
						MessageDialog.openError(shell, "错误", "添加失败！");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}

			}
		});

		// 右键删除
		mntmS.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				deteMethod(button_2);
			}
		});

		// 删除
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				deteMethod(button_2);
			}
		});

		// 修改
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String jid = text.getText().toString().trim();
				String jname = text_1.getText().toString().trim();

				if (jname == null || "".equals(jname)) {
					MessageDialog.openError(shell, "错误", "职务名不能为空");
					return;
				}

				try {
					String sql = "update  job set name=?  where  jid=?";
					params = new ArrayList<Object>();
					params.add(jname);
					params.add(jid);

					int result = db.update(sql, params);
					if (result > 0) {
						button_2.notifyListeners(SWT.Selection, event);
						MessageDialog.openConfirm(shell, "成功", "修改成功!");
						Common.bm.intiCombo();
						Common.fm.initCombo();
						Common.as.initCombo2();
						text.setText("");
						text_1.setText("");

					} else {

						MessageDialog.openError(shell, "错误", "修改失败！");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}

			}
		});

		// 选中table
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String jid = ti.getText(0);
				String jname = ti.getText(1);

				text.setText(jid);
				text_1.setText(jname);

			}
		});

		// 查询
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String jname = text_2.getText().toString().trim();

				String sql = "select *from job ";

				params = new ArrayList<Object>();
				if (jname != null && !"".equals(jname)) {
					sql += " where name like ?";
					params.add("%" + jname + "%");
				}
				try {
					table.removeAll();
					List<Map<String, Object>> list = db.find(sql, params);
					if (list != null && list.size() > 0) {
						for (Map<String, Object> map : list) {
							TableItem tableItem = new TableItem(table, SWT.NONE);
							tableItem.setText(new String[] {
									(String) map.get("JID"),
									(String) map.get("NAME"), });
						}
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}
			}
		});

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	private void deteMethod(Button button_2) {
		TableItem[] tis = table.getSelection();
		if (tis == null || tis.length <= 0) {
			return;
		}
		TableItem ti = tis[0];
		String jid = ti.getText(0);

		String sql = "delete from job  where jid='" + jid + "'";
		try {
			DBHelper db = new DBHelper();
			int result = db.update(sql, null);
			if (result > 0) {
				button_2.notifyListeners(SWT.Selection, event);
				MessageDialog.openConfirm(shell, "成功", "删除成功");
				Common.bm.intiCombo();
				Common.fm.initCombo();
				Common.as.initCombo2();
				text.setText("");
				text_1.setText("");
			} else {
				MessageDialog.openError(shell, "错误", "删除失败！");
			}
		} catch (Exception e) {
			MessageDialog.openError(shell, "错误", e.getMessage());
			return ;
		}
	}
}
