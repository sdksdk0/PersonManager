package cn.pm.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.internal.C;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import cn.pm.dao.DBHelper;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.custom.TableCursor;

import com.alibaba.fastjson.JSONObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.ibm.icu.util.Calendar;

import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.layout.RowLayout;

public class CheckManagement extends Composite {
	private Table table;
	private Text text;
	private Shell shell;
	private Event event;
	private Text text_2;
	private Combo combo;
	private Label pic;
	private Display display;
	DBHelper db = new DBHelper();

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public CheckManagement(Composite parent, int style) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setBackgroundMode(SWT.INHERIT_DEFAULT);

		shell = parent.getShell();
		display = parent.getDisplay();
		setLayout(new FillLayout(SWT.HORIZONTAL));
		setSize(1414, 760);
		SashForm sashForm = new SashForm(this, SWT.VERTICAL);

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group_1 = new Group(composite, SWT.NONE);
		group_1.setText("当前是>考勤管理>超级标签");

		Composite composite_4 = new Composite(sashForm, SWT.NONE);
		event = new Event();
		composite_4.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group_2 = new Group(composite_4, SWT.NONE);
		group_2.setLayout(null);

		Button button_1_1 = new Button(group_2, SWT.NONE);
		button_1_1.setBounds(1003, 28, 112, 46);
		button_1_1.setText("查询");
		

		text = new Text(group_2, SWT.BORDER);
		text.setBounds(219, 38, 264, 28);

		Label label_2 = new Label(group_2, SWT.NONE);
		label_2.setBounds(90, 41, 112, 28);
		label_2.setText("标签号：");

		Label label = new Label(group_2, SWT.NONE);
		label.setBounds(514, 38, 384, 20);
		label.setText("请使用扫描仪扫描标签信息");
		
		Button button_2 = new Button(group_2, SWT.NONE);
	
		button_2.setBounds(1170, 36, 98, 30);
		button_2.setText("重置");
		
		Button button_3 = new Button(group_2, SWT.NONE);
		
		button_3.setBounds(1290, 38, 98, 30);
		button_3.setText("删除");

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		TabFolder tabFolder = new TabFolder(composite_1, SWT.NONE);

		TabItem tabItem_1 = new TabItem(tabFolder, SWT.NONE);
		tabItem_1.setText("标签信息");

		table = new Table(tabFolder, SWT.BORDER | SWT.FULL_SELECTION);
		tabItem_1.setControl(table);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(354);
		tblclmnNewColumn.setText("标签号：");

		TableColumn tblclmnNewColumn_1 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_1.setWidth(202);
		tblclmnNewColumn_1.setText("员工号");

		TableColumn tblclmnNewColumn_2 = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn_2.setWidth(234);
		tblclmnNewColumn_2.setText("员工名");

		TableCursor tableCursor = new TableCursor(table, SWT.NONE);

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setText("部门");
		tableColumn_1.setWidth(227);

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(253);
		tableColumn.setText("职务");

		Composite composite_2 = new Composite(sashForm, SWT.NONE);

		Label label_1 = new Label(composite_2, SWT.NONE);
		label_1.setBounds(87, 45, 76, 20);
		label_1.setText("员工号：");

		Label label_3 = new Label(composite_2, SWT.NONE);
		label_3.setBounds(64, 125, 76, 20);
		label_3.setText("标签号：");

		text_2 = new Text(composite_2, SWT.BORDER);
		text_2.setEditable(false);
		text_2.setBounds(185, 125, 277, 26);

		combo = new Combo(composite_2, SWT.NONE);
		combo.setBounds(185, 37, 92, 28);

		Label lblNewLabel = new Label(composite_2, SWT.NONE);
		lblNewLabel.setBounds(620, 45, 76, 20);
		lblNewLabel.setText("二维码区：");

		Button button = new Button(composite_2, SWT.NONE);

		button.setBounds(122, 246, 98, 30);
		button.setText("生成标签");

		pic = new Label(composite_2, SWT.BORDER);
		pic.setBounds(736, 44, 285, 272);
		
		Label label_4 = new Label(composite_2, SWT.NONE);
		label_4.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		label_4.setBounds(1075, 56, 118, 20);

		intiCombo();
		event = new Event();
		event.widget = button_1_1;
		sashForm.setWeights(new int[] {33, 117, 202, 399});
		
		//删除
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length <= 0) {
					return;
				}
				TableItem ti = tis[0];
				String qrid = ti.getText(0);

				String sql = "delete from qr where qrid='" + qrid + "'";
				int result = db.update(sql, null);
				button_1_1.notifyListeners(SWT.Selection, event);
				
			}
		});
		
		
		//重置
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				combo.setText("");
				text.setText("");
				text_2.setText("");
			}
		});

		// 生成二维码
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Random r = new Random();
				text_2.setText(r.nextInt(2000000000) + "");

				String eid = combo.getText().trim();
				String qrid = text_2.getText().trim();
				
				try {
					createQR(eid, qrid);
				} catch (WriterException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

				FileInputStream fis;
				try {
					fis = new FileInputStream(new File("D:" + File.separator
							+ "qr.png"));
					ImageData imageData = new ImageData(fis);
					LayoutUtil.showPic(display, pic, imageData);

				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}

				label_4.setText("未入库");
				if (eid != null && !"".equals(eid)) {
					
					String sql = " insert into qr values(?,?) ";
					List<Object> params = new ArrayList<Object>();
					params.add(qrid);
					params.add(eid);
					int rs = db.update(sql, params);
					label_4.setText("");
					button_1_1.notifyListeners(SWT.Selection, event);
				}
			}
		});

		// 查询
		button_1_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String qrid = text.getText().trim();

				String sql = " select qr.qrid,qr.eid,e.name as ename,d.name as dname,j.name as jname  from qr join emp e on qr.eid=e.eid  join dept d on e.did=d.did "
						+ " join  job j on e.jid=j.jid  where 1=1 ";

				if (qrid != null && !"".equals(qrid)) {
					sql += " and qrid='" + qrid + "'";

				}
				table.removeAll();
				List<Map<String, Object>> list = db.find(sql.toString(), null);
				if (list != null && !"".equals(list)) {
					for (Map<String, Object> map : list) {
						TableItem tableItem = new TableItem(table, SWT.NONE);
						String[] str = new String[] { (String) map.get("QRID"),
								(String) map.get("EID"),
								(String) map.get("ENAME"),
								(String) map.get("DNAME"),
								(String) map.get("JNAME") };
						tableItem.setText(str);
					}
				}

			}
		});

	}

	public void intiCombo() {
		String sql = "select eid from emp";
		DBHelper db = new DBHelper();
		try {
			List<Map<String, Object>> list = db.find(sql, null);

			if (list != null && list.size() > 0) {
				combo.removeAll();
				for (Map<String, Object> map : list) {
					String eid = (String) map.get("EID");
					combo.add(eid);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			MessageDialog.openError(shell, "错误", e.getMessage());
		}

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	private void createQR(String eid, String qrid) throws WriterException,
			IOException {

		String filePath = "D://";
		String fileName = "qr.png";

		JSONObject json = new JSONObject();
		json.put(eid, qrid);
		
		json.put("员工号", "标签号");
		String content = json.toJSONString();// 内容
		int width = 250; // 图像宽度
		int height = 250; // 图像高度
		String format = "png";// 图像类型
		Map<EncodeHintType, Object> hints = new HashMap<EncodeHintType, Object>();
		hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
		BitMatrix bitMatrix = new MultiFormatWriter().encode(content,
				BarcodeFormat.QR_CODE, width, height, hints);// 生成矩阵
		Path path = FileSystems.getDefault().getPath(filePath, fileName);
		MatrixToImageWriter.writeToPath(bitMatrix, format, path);// 输出图像

	}
}
