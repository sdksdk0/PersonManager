package cn.pm.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.custom.TableCursor;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import cn.pm.dao.DBHelper;
import cn.pm.dialog.TTMAddDialog;
import cn.pm.dialog.TTMUpdateDialog;

public class TreatmentManagement extends Composite {

	private Shell shell;
	private Display display; // 显示的容器

	private Button button;
	public static Button deletebutton;
	public static Button updatebutton;
	public static Button selectbutton;

	private Table table;
	private StackLayout sl; // 堆栈式布局
	private Text text;
	// 有几页
	private int pagesize = 10;
	// 第几页
	private int page = 1;
	private int totalpages;
	// 与查询按钮绑定的事件
	public static Event event;
	public static Text text_1;
	private Label label_3;
	public static Combo combo_1;

	public TreatmentManagement(Composite parent, int style) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setBackgroundMode(SWT.INHERIT_FORCE);
		setSize(1414, 760);
		setLayout(new FillLayout(SWT.HORIZONTAL));
		SashForm sashForm = new SashForm(this, SWT.VERTICAL);

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setForeground(SWTResourceManager
				.getColor(SWT.COLOR_WIDGET_BACKGROUND));
		composite.setBackgroundMode(SWT.INHERIT_DEFAULT);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group_2 = new Group(composite, SWT.NONE);
		group_2.setText("当前是>薪资管理>待遇管理");

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_1 = new SashForm(composite_1, SWT.SMOOTH
				| SWT.VERTICAL);

		Composite composite_2 = new Composite(sashForm_1, SWT.NONE);
		composite_2.setLayout(null);

		Group group = new Group(composite_2, SWT.NONE);
		group.setBounds(0, 0, 1414, 125);
		group.setText("操作");
		group.setLayout(null);

		deletebutton = new Button(group, SWT.NONE);

		deletebutton.setText("删除");
		deletebutton.setBounds(1263, 35, 80, 37);

		updatebutton = new Button(group, SWT.NONE);

		updatebutton.setText("修改\r\n");
		updatebutton.setBounds(1153, 35, 80, 37);

		selectbutton = new Button(group, SWT.NONE);
		selectbutton.setText("查询");
		selectbutton.setBounds(882, 35, 80, 37);

		event = new Event();
		event.widget = selectbutton;

		Label lblNewLabel = new Label(group, SWT.NONE);
		lblNewLabel.setBounds(45, 66, 43, 17);
		lblNewLabel.setText("员工名：");

		text = new Text(group, SWT.BORDER);
		text.setBounds(161, 63, 80, 23);

		Label label_1 = new Label(group, SWT.NONE);
		label_1.setBounds(331, 66, 43, 17);
		label_1.setText("类型：");

		Combo combo = new Combo(group, SWT.READ_ONLY);
		combo.setItems(new String[] {"全部", "五险一金", "四险一金", "三险一金"});
		combo.setBounds(435, 63, 123, 25);
		combo.select(0);

		Button button_1 = new Button(group, SWT.NONE);

		button_1.setBounds(1000, 35, 98, 37);
		button_1.setText("添加");
		
		Button button_2 = new Button(group, SWT.NONE);
		button_2.setBounds(719, 31, 105, 44);
		button_2.setText("重置");
		
		//清空
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text_1.setText("");
			    text.setText("");
				
			}
		});

		Composite composite_3 = new Composite(sashForm_1, SWT.NONE);
		composite_3.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_2 = new SashForm(composite_3, SWT.VERTICAL);

		TabFolder tabFolder = new TabFolder(sashForm_2, SWT.NONE);

		TabItem tabItem_1 = new TabItem(tabFolder, SWT.NONE);
		tabItem_1.setText("福利管理记录");

		Composite composite_4 = new Composite(tabFolder, SWT.NONE);
		tabItem_1.setControl(composite_4);
		composite_4.setLayout(new FillLayout(SWT.HORIZONTAL));

		table = new Table(composite_4, SWT.BORDER | SWT.FULL_SELECTION);

		table.setHeaderVisible(true);
		table.setLinesVisible(true);

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(204);
		tableColumn_1.setText("福利号");

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setText("员工号");
		tableColumn.setWidth(179);

		TableColumn eidColumn = new TableColumn(table, SWT.NONE);
		eidColumn.setWidth(208);
		eidColumn.setText("员工名");

		TableColumn typeColumn_1 = new TableColumn(table, SWT.NONE);
		typeColumn_1.setWidth(184);
		typeColumn_1.setText("福利类型");

		TableColumn moneyColumn = new TableColumn(table, SWT.NONE);
		moneyColumn.setWidth(233);
		moneyColumn.setText("金额");

		TableCursor tableCursor = new TableCursor(table, SWT.NONE);

		Composite composite_5 = new Composite(sashForm_2, SWT.NONE);
		composite_5.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group_1 = new Group(composite_5, SWT.NONE);
		group_1.setText("分页查询");

		Button btnNewButton_1 = new Button(group_1, SWT.NONE);

		btnNewButton_1.setBounds(1001, 25, 80, 27);
		btnNewButton_1.setText("上一页");

		Button btnNewButton_2 = new Button(group_1, SWT.NONE);

		btnNewButton_2.setBounds(1194, 25, 80, 27);
		btnNewButton_2.setText("下一页");

		Label label_2 = new Label(group_1, SWT.NONE);
		label_2.setBounds(496, 28, 313, 24);

		Label label = new Label(group_1, SWT.NONE);
		label.setBounds(132, 92, 76, 20);
		label.setText("福利号：");

		text_1 = new Text(group_1, SWT.BORDER | SWT.READ_ONLY);
		text_1.setEditable(false);
		text_1.setBounds(259, 89, 109, 26);

		combo_1 = new Combo(group_1, SWT.READ_ONLY);
		combo_1.setBounds(618, 89, 92, 28);

		label_3 = new Label(group_1, SWT.NONE);
		label_3.setBounds(480, 92, 76, 20);
		label_3.setText("员工号：");
		sashForm_2.setWeights(new int[] { 375, 158 });
		sashForm_1.setWeights(new int[] { 104, 452 });
		sashForm.setWeights(new int[] { 26, 615 });

		initCombo();

		// 添加
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TTMAddDialog dialog = new TTMAddDialog(new Shell(),
						SWT.DIALOG_TRIM | SWT.SYSTEM_MODAL);
				dialog.open();
			}
		});

		// table被选中的时候
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String rmid = ti.getText(0);
				text_1.setText(rmid);
				combo_1.setText(ti.getText(1));
			}
		});

		// 更新
		updatebutton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				TTMUpdateDialog dialog = new TTMUpdateDialog(new Shell(),
						SWT.DIALOG_TRIM | SWT.SYSTEM_MODAL);
				dialog.open();

			}
		});

		// 删除
		deletebutton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String name = eidColumn.getText();
				// 1、取出表格中的选定的数据
				TableItem[] tis = table.getSelection();
				// 若没有选定任何类别，则返回
				if (tis == null || tis.length <= 0) {
					return;
				}
				TableItem ti = tis[0];
				String wid = ti.getText(0);
				String sql = "delete from welfare where wid=	'" + wid + " '";
				DBHelper db = new DBHelper();
				int result = db.update(sql, null);
				if (result > 0) {
					MessageDialog.openInformation(shell, "温馨提示", "删除成功");
					selectbutton.notifyListeners(SWT.Selection, event);
				} else {
					MessageDialog.openError(shell, "错误提示", "更新失败");
				}
			}
		});

		// 下一页
		btnNewButton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page++;
				if (page > totalpages) {
					MessageDialog.openError(shell, "错误", "已经是最后一页了！");
					page = totalpages;
				}
				selectbutton.notifyListeners(SWT.Selection, event);
			}
		});

		// 上一页
		btnNewButton_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page--;
				if (page <= 0) {
					page = 1;
					MessageDialog.openConfirm(shell, "错误", "这是第一页");
					return;
				}
				selectbutton.notifyListeners(SWT.Selection, event);

			}
		});

		// 查询福利管理记录
		selectbutton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String name = text.getText().toString().trim();
				String type = combo.getText().toString().trim();

				String sql = "select * from (select A.*,rownum rn  from (select w.wid,e.eid ,e.name as ename, type, "
						+ " wmoney  from welfare w inner join  emp e on e.eid=w.eid   where 1=1 ";
				List<Object> params = new ArrayList<Object>();

				if (name != null && !"".equals(name)) {
					sql += " and e.name like ? ";
					params.add("%" + name + "%");
				}
				if(type.equals("全部")){
					sql+=" ";
				}else if (type != null && !"".equals(type)) {
					sql += " and type like ? ";
					params.add("%" + type + "%");
				}
				int max = page * pagesize;
				int min = (page - 1) * pagesize;

				sql += "  ) A where rownum<? ) where rn>?";
				params.add(max);
				params.add(min);

				DBHelper db = new DBHelper();
				table.removeAll();
				List<Map<String, Object>> listmap = db.find(sql.toString(),
						params);
				if (listmap != null && listmap.size() > 0) {

					for (Map<String, Object> map : listmap) {
						TableItem tableItem = new TableItem(table, SWT.NONE);
						String[] str = new String[] {
								(String) map.get("WID"),
								(String) map.get("EID"), // 员工号
								(String) map.get("ENAME"),
								(String) map.get("TYPE"),
								(String) map.get("WMONEY")};
						tableItem.setText(str);
					}
				}
				String sql2 = "select count(*)  from welfare w inner join  emp e on e.eid=w.eid   where 1=1   ";
				List<String> params2 = new ArrayList<String>();
				if (name != null && !"".equals(name)) {
					sql2 += " and e.name  like ? ";
					params2.add("%" + name + "%");
				}
				if(type.equals("全部")){
					sql+=" ";
				}else if (type != null && !"".equals(type)) {
					sql2 += " and type like ? ";
					params2.add("%" + type+ "%");
				}
				int count = (int) db.doSelectFunction(sql2, params2);

				totalpages = count % pagesize == 0 ? count / pagesize : count
						/ pagesize + 1;
				label_2.setText("第" + page + "页/ 共" + totalpages + "页/ 共"
						+ count + "条数据");
			}
		});
	}

	public  void initCombo() {
		String sql = "select  eid from emp ";
		DBHelper db = new DBHelper();
		combo_1.removeAll();
		List<Map<String, Object>> list = db.find(sql, null);
		for (Map<String, Object> map : list) {
			String eid = (String) map.get("EID");
			combo_1.add(eid);
		}

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
