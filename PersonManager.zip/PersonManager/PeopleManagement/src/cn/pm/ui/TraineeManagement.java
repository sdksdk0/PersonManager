﻿package cn.pm.ui;

import java.util.ArrayList;
import java.util.List;

import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.custom.TableCursor;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.junit.runner.Request;

import cn.pm.dao.DBHelper;

public class TraineeManagement extends Composite {
	private Table table_1;
	private Text numbertext_1;
	private Text nametext_2;
	private Text teltext_3;

	private Shell shell;
	private Combo statuscombo_2; // 录取的状态
	private Combo jobcombo_1; // 职位
	private Event event;

	private int page = 1;
	private int totalPage;
	private int pageSize = 8; // 每页最多显示多少条数据

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public TraineeManagement(Composite parent, int style) {
		super(parent, style);

		setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(this, SWT.VERTICAL);
		sashForm.setBackgroundMode(SWT.INHERIT_FORCE);
		setSize(1414, 760);

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setBackgroundMode(SWT.INHERIT_FORCE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group_1 = new Group(composite, SWT.NONE);
		group_1.setBackground(SWTResourceManager
				.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		group_1.setText("当前是>人事管理>招聘管理");

		Composite composite_4 = new Composite(sashForm, SWT.NONE);
		composite_4.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));

		Label lblNewLabel_3 = new Label(composite_4, SWT.NONE);
		lblNewLabel_3.setBackground(SWTResourceManager
				.getColor(SWT.COLOR_WHITE));
		lblNewLabel_3.setBounds(129, 78, 36, 17);
		lblNewLabel_3.setText("姓名：");

		nametext_2 = new Text(composite_4, SWT.BORDER);
		nametext_2.setBounds(209, 75, 107, 23);

		Label label_1 = new Label(composite_4, SWT.NONE);
		label_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		label_1.setText("应聘职位：");
		label_1.setBounds(366, 78, 60, 17);

		jobcombo_1 = new Combo(composite_4, SWT.NONE);
		jobcombo_1.setBounds(494, 75, 168, 28);
		jobcombo_1.select(0);

		Button button_3 = new Button(composite_4, SWT.NONE);
		button_3.setBounds(829, 42, 80, 27);
		button_3.setText("查询");

		Button button_4 = new Button(composite_4, SWT.NONE);

		button_4.setBounds(695, 42, 80, 27);
		button_4.setText("重置");

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		TabFolder tabFolder = new TabFolder(composite_1, SWT.NONE);

		TabItem tabItem = new TabItem(tabFolder, SWT.NONE);
		tabItem.setText("招聘管理信息");

		table_1 = new Table(tabFolder, SWT.BORDER | SWT.FULL_SELECTION);

		table_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		tabItem.setControl(table_1);
		table_1.setHeaderVisible(true);
		table_1.setLinesVisible(true);

		TableColumn tblclmnNewColumn = new TableColumn(table_1, SWT.NONE);
		tblclmnNewColumn.setWidth(146);
		tblclmnNewColumn.setText("应聘号");

		TableColumn tblclmnNewColumn_1 = new TableColumn(table_1, SWT.NONE);
		tblclmnNewColumn_1.setWidth(132);
		tblclmnNewColumn_1.setText("姓名");

		TableColumn tblclmnNewColumn_3 = new TableColumn(table_1, SWT.NONE);
		tblclmnNewColumn_3.setWidth(129);
		tblclmnNewColumn_3.setText("性别");

		TableColumn tblclmnNewColumn_2 = new TableColumn(table_1, SWT.NONE);
		tblclmnNewColumn_2.setWidth(208);
		tblclmnNewColumn_2.setText("应聘职位号");

		TableColumn tableColumn_2 = new TableColumn(table_1, SWT.NONE);
		tableColumn_2.setWidth(162);
		tableColumn_2.setText("应聘职位");

		TableColumn tableColumn = new TableColumn(table_1, SWT.NONE);
		tableColumn.setWidth(183);
		tableColumn.setText("电话");

		TableColumn tableColumn_1 = new TableColumn(table_1, SWT.NONE);
		tableColumn_1.setWidth(202);
		tableColumn_1.setText("状态");

		Composite composite_2 = new Composite(sashForm, SWT.NONE);
		composite_2.setBackgroundMode(SWT.INHERIT_FORCE);
		composite_2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));

		Button button_2 = new Button(composite_2, SWT.NONE);
		button_2.setBounds(1247, 25, 80, 27);
		button_2.setText("下一页");

		Button button_1 = new Button(composite_2, SWT.NONE);
		button_1.setBounds(1044, 17, 80, 27);
		button_1.setText("上一页");

		Label lblNewLabel_2 = new Label(composite_2, SWT.NONE);
		lblNewLabel_2.setBounds(451, 17, 455, 35);
		lblNewLabel_2.setBackground(SWTResourceManager
				.getColor(SWT.COLOR_LIST_BACKGROUND));

		// 上一页
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page--;
				if (page <= 0) {
					page = 1;
					MessageDialog.openInformation(shell, "温馨提示",
							"当前是第一页，没有上一页了。。");
					button_3.notifyListeners(SWT.Selection, event);
				}
			}
		});

		// 下一页
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page++;
				if (page > totalPage) {
					page = totalPage;
					MessageDialog.openInformation(shell, "温馨提示", "当前是最后一页了");
					button_3.notifyListeners(SWT.Selection, event);

				}
			}
		});

		Composite composite_3 = new Composite(sashForm, SWT.NONE);
		composite_3.setBackgroundMode(SWT.INHERIT_DEFAULT);
		composite_3.setBackground(SWTResourceManager
				.getColor(SWT.COLOR_LIST_SELECTION_TEXT));

		statuscombo_2 = new Combo(composite_3, SWT.NONE);
		statuscombo_2.setBounds(992, 30, 107, 28);
		statuscombo_2.setItems(new String[] { "", "录取", "淘汰" });
		statuscombo_2.select(0);

		Label label_4 = new Label(composite_3, SWT.NONE);
		label_4.setBounds(894, 33, 33, 17);
		label_4.setText("状态：");

		Group group = new Group(composite_3, SWT.NONE);
		group.setBounds(587, 23, 199, 35);

		Button girlbutton = new Button(group, SWT.RADIO);
		girlbutton.setBounds(110, 10, 49, 17);
		girlbutton.setText("女");

		Button boybutton = new Button(group, SWT.RADIO);
		boybutton.setBounds(54, 10, 49, 17);
		boybutton.setText("男");

		Label label = new Label(composite_3, SWT.NONE);
		label.setBounds(466, 33, 36, 17);
		label.setText("性别：");

		numbertext_1 = new Text(composite_3, SWT.BORDER | SWT.READ_ONLY);
		numbertext_1.setBounds(210, 30, 98, 23);

		Label label_3 = new Label(composite_3, SWT.NONE);
		label_3.setBounds(74, 33, 53, 17);
		label_3.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		label_3.setText("应聘号：");

		teltext_3 = new Text(composite_3, SWT.BORDER);
		teltext_3.setBounds(600, 93, 186, 23);

		Label lblNewLabel_1 = new Label(composite_3, SWT.NONE);
		lblNewLabel_1.setBounds(464, 93, 38, 17);
		lblNewLabel_1.setText("电话：");

		boybutton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				boybutton.setSelection(true);
				girlbutton.setSelection(false);
			}
		});

		girlbutton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				girlbutton.setSelection(true);
				boybutton.setSelection(false);
			}
		});

		inticombo();
		event = new Event();
		event.widget = button_3;

		Button addbutton_2 = new Button(composite_4, SWT.NONE);
		addbutton_2.setBounds(971, 42, 69, 27);
		addbutton_2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		addbutton_2.setText("添加");

		Button button = new Button(composite_4, SWT.NONE);
		button.setBounds(1107, 42, 68, 27);

		button.setText("修改");

		Button deletebutton_3 = new Button(composite_4, SWT.NONE);
		deletebutton_3.setBounds(1245, 42, 64, 27);
		deletebutton_3.setText("删除");
		sashForm.setWeights(new int[] { 51, 132, 338, 73, 154 });

		// 删除
		deletebutton_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				// 1、取出表格中的选定的数据
				TableItem[] tis = table_1.getSelection();
				// 若没有选定任何类别，则返回
				if (tis == null || tis.length <= 0) {
					return;
				}
				TableItem ti = tis[0];
				String recid = ti.getText(0);
				String sql = "delete from recruit where recid = '" + recid
						+ " '";

				DBHelper db = new DBHelper();
				int result = db.update(sql, null);
				if (result > 0) {
					clear();
					MessageDialog.openInformation(shell, "提示", "删除成功");

					button_3.notifyListeners(SWT.Selection, event);
				} else {
					MessageDialog.openError(shell, "提示", "sorry，删除失败");
				}
			}
		});
		// 更新
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				String recid = numbertext_1.getText().trim();
				String rname = nametext_2.getText().toString().trim();
				String sex = null;
				if (girlbutton.getSelection() == true) {
					sex = "女";
				} else if (boybutton.getSelection() == true) {
					sex = "男";
				}
				String cel = teltext_3.getText();
				String status = statuscombo_2.getText().toString().trim();

				String jname = jobcombo_1.getText().toString().trim();
				DBHelper db = new DBHelper();
				String sql1 = "select jid from job where name='" + jname + "'";

				String jid = null;
				List<Map<String, Object>> list = db.find(sql1, null);
				if (list != null && !"".equals(list)) {
					for (Map<String, Object> map : list) {
						jid = (String) map.get("JID");
					}
				}

				String sql = "update  recruit  set rname=?,sex=?,tel=?,jid=?,status=? where recid=?  ";

				List<Object> params = new ArrayList<Object>();
				params.add(rname);
				params.add(sex);
				params.add(cel);
				params.add(jid);
				params.add(status);
				params.add(recid);

				int result = db.update(sql, params);
				if (result > 0) {
					clear();
					MessageDialog.openInformation(shell, "恭喜", "数据更新成功");
					button_3.notifyListeners(SWT.Selection, event);
				} else {
					MessageDialog.openError(shell, "错误", "更新失败");
				}

			}
		});

		// 添加
		addbutton_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String rname = nametext_2.getText().toString().trim();
				String sex = null;
				if (girlbutton.getSelection() == true) {
					sex = "女";
				} else if (boybutton.getSelection() == true) {
					sex = "男";
				}

				if (rname == null || "".equals(rname)) {
					MessageDialog.openInformation(shell, "提示", "名字不能为空");
					return;
				}

				String cel = teltext_3.getText();
				String status = statuscombo_2.getText().toString().trim();
				String jname = jobcombo_1.getText().toString().trim();
				DBHelper db = new DBHelper();
				String sql1 = "select jid from job where name='" + jname + "'";

				String jid = null;
				List<Map<String, Object>> list = db.find(sql1, null);
				if (list != null && !"".equals(list)) {
					for (Map<String, Object> map : list) {
						jid = (String) map.get("JID");
					}
				}

				String sql = "insert into recruit values( seq_recruit_recid.nextval,?,?,?,?,?)";

				List<Object> params = new ArrayList<Object>();
				params.add(rname);
				params.add(sex);
				params.add(cel);
				params.add(jid);
				params.add(status);

				int result = db.update(sql, params);
				if (result > 0) {
					clear();
					MessageDialog.openInformation(shell, "恭喜", "数据添加成功");
					button_3.notifyListeners(SWT.Selection, event);
				} else {
					MessageDialog.openError(shell, "错误", "添加失败");
				}
			}
		});

		// 重置
		button_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				clear();
			}
		});

		// 该表被选中时
		table_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table_1.getSelection();
				if (tis == null || tis.length == 0) {
					return;
				}
				TableItem ti = tis[0];
				String recid = ti.getText(0);
				String rname = ti.getText(1);
				String sex = ti.getText(2).trim();
				String jname = ti.getText(4);
				String tel = ti.getText(5);
				String status = ti.getText(6);

				numbertext_1.setText(recid);
				nametext_2.setText(rname);

				if (sex.equals("男")) {
					boybutton.setSelection(true);
					girlbutton.setSelection(false);
				} else if (sex.equals("女")) {
					girlbutton.setSelection(true);
					boybutton.setSelection(false);
				}

				teltext_3.setText(tel);
				statuscombo_2.setText(status);
				jobcombo_1.setText(jname);
			}
		});

		// 查询
		button_3.addSelectionListener(new SelectionAdapter() {

			@Override
			public void widgetSelected(SelectionEvent e) {

				String rname = nametext_2.getText().trim();
				String jname = "";
				if ("-所有职位-".equals(jname)) {
					jname = jobcombo_1.getText().trim();
				}
				String sql = "select r.recid,r.rname,r.sex,j.jid,j.name,r.tel,r.status from recruit r inner join  job j on r.jid=j.jid  where 1=1";

				List<Object> params = new ArrayList<Object>();
				if (rname != null && !"".equals(rname)) {
					sql += "  and  r.rname like ?  ";
					params.add("%" + rname + "%");

				}
				if (jname != null && !"".equals(jname)) {
					sql += "   and j.name like ? ";
					params.add("%" + jname + "%");
				}
				DBHelper db = new DBHelper();
				List<Map<String, Object>> listmap = db.find(sql.toString(),
						params);
				if (listmap != null && listmap.size() > 0) {
					table_1.removeAll();
					for (Map<String, Object> map : listmap) {
						TableItem tableitem = new TableItem(table_1, SWT.None);
						String[] strs = new String[] {
								(String) map.get("RECID"),
								(String) map.get("RNAME"),
								(String) map.get("SEX"),
								(String) map.get("JID"),
								(String) map.get("NAME"),
								(String) map.get("TEL"),
								(String) map.get("STATUS"), };
						tableitem.setText(strs);
					}
				}
			}
		});
	}

	// 初始化combo
	public void inticombo() {
		String sql = "select jid,name  from  job ";
		DBHelper db = new DBHelper();
		List<Map<String, Object>> listmap = db.find(sql, null);
		jobcombo_1.removeAll();
		jobcombo_1.add("-所有职位-");
		if (listmap != null && listmap.size() > 0) {
			for (Map<String, Object> map : listmap) {
				String jid = (String) map.get("JID");
				String jname = (String) map.get("NAME");
				jobcombo_1.add(jname);
			}
			jobcombo_1.select(0);
		}
	}

	@Override
	protected void checkSubclass() {
	}

	private void clear() {
		nametext_2.setText("");
		numbertext_1.setText("");
		teltext_3.setText("");
		statuscombo_2.setText("");
		jobcombo_1.setText("");
	}
}
