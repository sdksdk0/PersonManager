package cn.pm.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import cn.pm.dao.DBHelper;

import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.wb.swt.SWTResourceManager;

public class LeaveManagement extends Composite {
	private Table table;
	private Text text;
	private Text text_1;
	
	DBHelper db=new DBHelper();
	private Shell shell;
	private Label label_5 ;
	
	private Event event; // 与按钮绑定的事件
	private int pagesize = 10;
	// 第几页
	private int page = 1;
	private int totalpages;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public LeaveManagement(Composite parent, int style) {
		super(parent, style);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setBackgroundMode(SWT.INHERIT_DEFAULT);
	
		setLayout(new FillLayout(SWT.HORIZONTAL));
		setSize(1414, 760);
		SashForm sashForm = new SashForm(this, SWT.VERTICAL);
		
		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		Group group = new Group(composite, SWT.NONE);
		group.setText("当前是>考勤管理>请假申请批复");
		
		Label label = new Label(group, SWT.NONE);
		label.setBounds(211, 74, 76, 20);
		label.setText("请假状态：");
		
		Combo combo = new Combo(group, SWT.READ_ONLY);
		combo.setItems(new String[] {"全部", "同意", "不同意", "待审核"});
		combo.setBounds(344, 71, 92, 28);
		
		Button button = new Button(group, SWT.NONE);

		button.setBounds(957, 69, 98, 30);
		button.setText("查询");
		
		Label label_4 = new Label(group, SWT.NONE);
		label_4.setBounds(531, 74, 76, 20);
		label_4.setText("员工号：");
		
		text_1 = new Text(group, SWT.BORDER);
		text_1.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent e) {
				Pattern pattern = Pattern.compile("[0-9]\\d*");
				Matcher matcher = pattern.matcher(e.text);
				if (matcher.matches()) // 处理数字
					e.doit = true;
				else if (e.text.length() > 0) // 有字符情况,包含中文、空格
					e.doit = false;
				else
					// 控制键
					e.doit = true;

			}
		});
		text_1.setBounds(650, 71, 135, 26);
		
		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		table = new Table(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
	
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(147);
		tableColumn.setText("请假号");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(190);
		tableColumn_2.setText("员工号");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(186);
		tableColumn_1.setText("员工名");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(170);
		tableColumn_3.setText("开始时间");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(212);
		tableColumn_4.setText("结束时间");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(237);
		tableColumn_5.setText("原因");
		
		TableColumn tableColumn_6 = new TableColumn(table, SWT.NONE);
		tableColumn_6.setWidth(215);
		tableColumn_6.setText("状态");
		
		Composite composite_2 = new Composite(sashForm, SWT.NONE);
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		SashForm sashForm_1 = new SashForm(composite_2, SWT.VERTICAL);
		
		Composite composite_3 = new Composite(sashForm_1, SWT.NONE);
		
		Button button_1 = new Button(composite_3, SWT.NONE);
	
		button_1.setBounds(966, 10, 98, 30);
		button_1.setText("上一页");
		
		Button button_2 = new Button(composite_3, SWT.NONE);
	
		button_2.setBounds(1167, 10, 98, 30);
		button_2.setText("下一页");
		
		Label label_1 = new Label(composite_3, SWT.NONE);
		label_1.setBounds(337, 15, 461, 20);
		
		Composite composite_4 = new Composite(sashForm_1, SWT.NONE);
		
		Label label_2 = new Label(composite_4, SWT.NONE);
		label_2.setBounds(198, 54, 59, 20);
		label_2.setText("请假号：");
		
		text = new Text(composite_4, SWT.BORDER);
		text.setEditable(false);
		text.setBounds(299, 51, 73, 26);
		
		Label label_3 = new Label(composite_4, SWT.NONE);
		label_3.setBounds(503, 54, 104, 20);
		label_3.setText("是否同意请假：");
		
		Combo combo_1 = new Combo(composite_4, SWT.READ_ONLY);
		combo_1.setItems(new String[] {"同意", "不同意"});
		combo_1.setBounds(656, 51, 92, 28);
		
		label_5 = new Label(composite_4, SWT.NONE);
		label_5.setBounds(888, 65, 103, 20);
		sashForm_1.setWeights(new int[] {39, 179});
		sashForm.setWeights(new int[] {100, 243, 220});
		
		initDay();
		event = new Event();
		event.widget = button;
		
		Button button_3 = new Button(group, SWT.NONE);
		button_3.setBounds(1160, 69, 98, 30);
		button_3.setText("提交");
		//提交
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ApplicationMethod(button, combo_1);
			}
		});
		
		
		//下一页
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page++;
				if (page > totalpages) {
					MessageDialog.openError(shell, "错误", "已经是最后一页了！");
					page = totalpages;
				}
				button.notifyListeners(SWT.Selection, event);
				
			}
		});
		
		//上一页
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page--;
				if (page <= 0) {
					MessageDialog.openError(shell, "错误", "没有上一页了！");
					page = 1;
					return;
				}
				button.notifyListeners(SWT.Selection, event);
			}
		});
		
		
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String lid= ti.getText(0);
				String type= ti.getText(6);

				text.setText(lid);
				combo_1.setText(type);
		
				initDay();
				
			}
		});
		
		
		//查询
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String type=combo.getText().trim();
				String eid=text_1.getText().trim();
				
				String sql="select *from (select A.*,rownum rn from (select lid,l.eid as leid,e.name as ename,lstart,lend,reason,type  from leave  l  left join emp e on e.eid=l.eid  where 1=1  ";
				List<Object> params=new ArrayList<Object>();
				if(type.equals("全部")){
					sql+=" ";
				}else if(type!=null && !"".equals(type)){
					sql+=" and type= ? ";
					params.add(type);
				}
				if(eid!=null && !"".equals(eid)){
					sql+=" and l.eid=?";
					params.add(eid);
				}
				int max = page * pagesize;
				int min = (page - 1) * pagesize;
				
				sql+=" ) A where rownum<? ) where rn>?";
				params.add(max);
				params.add(min);	
				
				table.removeAll();
				text_1.setText("");
				List<Map<String,Object>>  list=db.find(sql, params);
				if(list!=null && !"".equals(list)){
					for (Map<String, Object> map : list) {
						TableItem tableItem = new TableItem(table, SWT.NONE);
						tableItem.setText(new String[] {
								(String) map.get("LID"),
								(String) map.get("LEID"),
								(String) map.get("ENAME"),
								(String) map.get("LSTART"),
								(String) map.get("LEND"),
								(String)  map.get("REASON"),
								(String) map.get("TYPE") });
					}
				}
				
				List<String> params1=new ArrayList<String>();
				String sql2 = "select count(*) from leave  where 1=1 ";
				if(type.equals("全部")){
					sql+=" ";
				}else  if(type!=null && !"".equals(type)){
					sql2+=" and type= ? ";
					params1.add(type);
				}
				if(eid!=null && !"".equals(eid)){
					sql2+=" and eid=?";
					params1.add(eid);
				}
		
				int count = (int) db.doSelectFunction(sql2, params1);

				totalpages = count % pagesize == 0 ? count / pagesize : count
						/ pagesize + 1;
				label_1.setText("第" + page + "页/ 共" + totalpages + "页/ 共"
						+ count + "条数据");
						
			}
		});

	}
	private void initDay() {
		String lid=text.getText().trim();
		String sql="select round(lend-lstart) as day  from leave where lid=?";
		
		List<Object>  params=new ArrayList<Object>();
		params.add(lid);
		label_5.setText("");
		List<Map<String,Object>>  list=db.find(sql, params);
		if(list!=null && !"".equals(list)){
			for (Map<String, Object> map : list) {
				String day=(String) map.get("DAY");
				label_5.setText("共"+day+"天");
			}
		}
	}
	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	private void ApplicationMethod(Button button, Combo combo_1) {
		String lid=text.getText().trim();
		String type=combo_1.getText().trim();
		List<Object> params=new ArrayList<Object>();
		String sql=" update leave set type=? where lid=? ";
		params.add(type);
		params.add(lid);
		
		try {
			int rs=db.update(sql, params);
			if(rs>0){
				button.notifyListeners(SWT.Selection, event);
				MessageDialog.openInformation(shell, "成功", "操作成功！");
				text_1.setText("");
				text.setText("");
			}else{
				MessageDialog.openError(shell, "错误", "操作失败");
			}
		} catch (Exception e1) {
			e1.printStackTrace();
			MessageDialog.openError(shell, "错误", e1.getMessage());
		}
	}
}
