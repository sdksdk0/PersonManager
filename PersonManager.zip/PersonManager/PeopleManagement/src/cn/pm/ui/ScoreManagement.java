package cn.pm.ui;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import cn.pm.dao.DBHelper;
import cn.pm.utils.Common;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.events.VerifyEvent;

public class ScoreManagement extends Composite {
	private Table table;
	private Text text;
	private Text text_1;
	private Shell shell;

	DBHelper db = new DBHelper();
	private List<Object> params;

	private Button button_1 ;
	private Text text_2;
	
	private Event event; // 与按钮绑定的事件
	private int pagesize = 8;
	private int page = 1;
	private int totalpages;
	private Combo combo_1;
	private Combo combo;

	/**
	 * Create the composite.
	 * 
	 * @param parent
	 * @param style
	 */
	public ScoreManagement(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_FORCE);
	
		
		shell = parent.getShell();
		setSize(1414, 760);
		setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group = new Group(this, SWT.NONE);
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setBackgroundMode(SWT.INHERIT_FORCE);
	
		group.setText("当前是>考勤管理>业绩评分");
		group.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(group, SWT.NONE);

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_1 = new SashForm(composite_1, SWT.VERTICAL);
	

		Composite composite_2 = new Composite(sashForm_1, SWT.NONE);
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_2 = new SashForm(composite_2, SWT.VERTICAL);

		Composite composite_4 = new Composite(sashForm_2, SWT.NONE);

	    button_1 = new Button(composite_4, SWT.NONE);

		button_1.setBounds(722, 50, 98, 30);
		button_1.setText("查询");

		Label label = new Label(composite_4, SWT.NONE);
		label.setBounds(108, 55, 76, 20);
		label.setText("员工名：");

		text_1 = new Text(composite_4, SWT.BORDER);
		
		text_1.setBounds(228, 52, 145, 26);

		table = new Table(sashForm_2, SWT.BORDER | SWT.FULL_SELECTION);

		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(230);
		tableColumn_4.setText("评分号");

		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(234);
		tableColumn.setText("员工号");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(219);
		tableColumn_3.setText("员工名");

		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(228);
		tableColumn_1.setText("业绩分");

		Menu menu = new Menu(table);
		table.setMenu(menu);

		MenuItem menuItem = new MenuItem(menu, SWT.NONE);

		menuItem.setText("删除");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(249);
		tableColumn_2.setText("时间");

		Composite composite_3 = new Composite(sashForm_1, SWT.NONE);
		composite_3.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_3 = new SashForm(composite_3, SWT.VERTICAL);

		Composite composite_5 = new Composite(sashForm_3, SWT.NONE);
		composite_5.setLayout(null);

		Label label_1 = new Label(composite_5, SWT.NONE);
		label_1.setBounds(562, 150, 59, 29);
		label_1.setText("业绩分：");

		text = new Text(composite_5, SWT.BORDER);
	
		text.setBounds(696, 147, 119, 29);
		
		Label lblNewLabel = new Label(composite_5, SWT.NONE);
		lblNewLabel.setBounds(151, 220, 61, 17);
		lblNewLabel.setText("员工号：");
		
		Label lblNewLabel_1 = new Label(composite_5, SWT.NONE);
		lblNewLabel_1.setBounds(562, 228, 61, 17);
		lblNewLabel_1.setText("时间：");
		
		DateTime dateTime = new DateTime(composite_5, SWT.BORDER);
		dateTime.setBounds(696, 228, 119, 24);
		
		Label label_2 = new Label(composite_5, SWT.NONE);
		label_2.setBounds(151, 139, 76, 20);
		label_2.setText("评分号：");
		
		text_2 = new Text(composite_5, SWT.BORDER);
		text_2.setEditable(false);
		text_2.setBounds(263, 147, 119, 26);
		
		Button button_2 = new Button(composite_5, SWT.NONE);
	
		button_2.setBounds(1051, 58, 98, 30);
		button_2.setText("上一页");
		
		Button button_3 = new Button(composite_5, SWT.NONE);
	
		button_3.setBounds(1222, 58, 98, 30);
		button_3.setText("下一页");
		
		Label label_3 = new Label(composite_5, SWT.NONE);
		label_3.setBounds(562, 63, 315, 20);
		
		 combo_1 = new Combo(composite_5, SWT.READ_ONLY);
		combo_1.setBounds(263, 217, 119, 28);
		sashForm_3.setWeights(new int[] { 206 });

	
		
		Label label_4 = new Label(composite_4, SWT.NONE);
		label_4.setBounds(108, 114, 76, 20);
		label_4.setText("分数范围：");
		
		 combo = new Combo(composite_4, SWT.NONE);
		combo.setItems(new String[] {"全部", "0-60", "60-75", "75-90", "90-100"});
		combo.setBounds(232, 114, 141, 28);
		combo.select(0);
		sashForm_2.setWeights(new int[] {74, 98});
		
		sashForm.setWeights(new int[] { 549 });
		
		initCombo();
		event=new Event();
		event.widget = button_1;
		
		Button button_4 = new Button(composite_4, SWT.NONE);
		button_4.setBounds(538, 50, 98, 30);
		button_4.setText("重置");
		
		Button button = new Button(composite_4, SWT.NONE);
		button.setBounds(910, 50, 98, 30);
		button.setText("添加");
		
				Button btnNewButton = new Button(composite_4, SWT.NONE);
				btnNewButton.setBounds(1083, 50, 98, 30);
				btnNewButton.setText("修改");
				
				Button btnNewButton_1 = new Button(composite_4, SWT.NONE);
				btnNewButton_1.setBounds(1260, 52, 98, 27);
				btnNewButton_1.setText("删除");
				sashForm_1.setWeights(new int[] {426, 308});
				
				
				
				//删除
				btnNewButton_1.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						deleteMethod(btnNewButton_1);
						combo_1.setText("");
						text.setText("");
					}
					
				});
				
						// 修改,更新
						btnNewButton.addSelectionListener(new SelectionAdapter() {
							@Override
							public void widgetSelected(SelectionEvent e) {
								String scid=text_2.getText().toString().trim();
								String eid = combo_1.getText().toString().trim();
								String score = text.getText().toString().trim();
								String stime=LayoutUtil.parseDateTime(dateTime);
				
								if (score == null || "".equals(score)) {
									MessageDialog.openError(shell, "错误", "内容不能为空");
									return;
								}
								
								try {
									String sql = "update sc set eid=?,score=?,stime=to_date(?,'yyyy-MM-dd')  where scid=? ";
									
									List<Object> params = new ArrayList<Object>();
									
									params.add(eid);
									params.add(score);
									params.add(stime);
									params.add(scid);
									
									DBHelper db = new DBHelper();
									int result = db.update(sql.toString(), params);
									if (result > 0) {
				
										button_1.notifyListeners(SWT.Selection, event);
										MessageDialog.openConfirm(shell, "成功", "修改成功!");
										combo_1.setText("");
										text.setText("");
									} else {
										MessageDialog.openError(shell, "错误", "修改失败！");
									}
								} catch (Exception e1) {
				
									e1.printStackTrace();
								}
				
							}
						});
		
				// 添加
				button.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						String eid = combo_1.getText().toString().trim();
						String score = text.getText().toString().trim();
						String stime=LayoutUtil.parseDateTime(dateTime);
						
						if (eid == null || "".equals(eid)) {
							MessageDialog.openError(shell, "错误", "内容不能为空");
							return;
						}
		
						String sql = "insert into sc sequence values(seq_sc_scid.nextval,?,?,to_date(?,'yyyy-mm-dd'))" ;
						
						List<Object> params = new ArrayList<Object>();
						params.add(eid);
						params.add(score);
						params.add(stime);
						
						DBHelper db = new DBHelper();
						int result = db.update(sql.toString(), params);
						if (result > 0) {
		
							button_1.notifyListeners(SWT.Selection, event);
							MessageDialog.openConfirm(shell, "成功", "添加成功!");
							text_2.setText("");
							text.setText("");
						} else {
							MessageDialog.openError(shell, "错误", "添加失败！");
						}
					}
				});
		
		
		//重置
		button_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				text_1.setText("");
				text_2.setText("");
				combo_1.setText("");
				
			}
		});
		
		//不能输数字
		text_1.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent arg0) {
				
				
			}
		});
		
		text.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent e) {
				Pattern pattern = Pattern.compile("[0-9]\\d*");
				Matcher matcher = pattern.matcher(e.text);
				if (matcher.matches()) // 处理数字
					e.doit = true;
				else if (e.text.length() > 0) // 有字符情况,包含中文、空格
					e.doit = false;
				else
					// 控制键
					e.doit = true;
				
			}
		});
		
		//下一页
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page++;
				if (page > totalpages) {
					MessageDialog.openError(shell, "错误", "已经是最后一页了！");
					page = totalpages;
				}
				button_1.notifyListeners(SWT.Selection, event);
			}
		});
		//上一页
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page--;
				if (page <= 0) {
					MessageDialog.openError(shell, "错误", "没有上一页了！");
					page = 1;
					return;
				}
				button_1.notifyListeners(SWT.Selection, event);
			}
		});
		// 右键删除
		menuItem.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				deleteMethod(btnNewButton_1);
				combo_1.setText("");
				text.setText("");
			}

		});
		
		// 树被选中的时候
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String scid=ti.getText(0);
				String eid=ti.getText(1);
	
				String score = ti.getText(3);
				String stime = ti.getText(4).substring(0,10);
				
				text_2.setText(scid);
				combo_1.setText(eid);
				text.setText(score);
				
				try {
					LayoutUtil.showTime(dateTime, stime);
				} catch (ParseException e1) {
					e1.printStackTrace();
				}
			}
		});

	

		// 查询按钮
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String name=text_1.getText().toString().trim();
				String choice=combo.getText().toString().trim();

				String sql = "select *from (select A.*,rownum rn from (select scid,s.eid,e.name as ename,score,stime  from sc s left join emp e on e.eid=s.eid  where 1=1 "; 
				List<Object> params = new ArrayList<Object>();
				if(name!=null && !"".equals(name)){
					sql+=" and e.name like ? ";
					params.add("%"+ name +"%");
				}
				if (choice.equals("全部")) {
					sql+=" ";
				}else if(choice.equals("0-60")){
					sql+="  and s.score between 0 and 60 ";
				}else  if(choice.equals("60-75")){
					sql+=" and s.score between 60 and 75 ";
				}else if(choice.equals("75-90")){
					sql+=" and s.score between 75 and 90 ";
				}else if(choice.equals( "90-100")){
					sql+=" and s.score between 90 and 100 ";
				}
				
				int max = page * pagesize;
				int min = (page - 1) * pagesize;

				sql+=") A where rownum<? ) where rn>?";
				params.add(max);
				params.add(min);
				try {
					table.removeAll();
					List<Map<String, Object>> list = db.find(sql.toString(), params);
					if (list != null && list.size() > 0) {
						for (Map<String, Object> map : list) {
							TableItem tableItem = new TableItem(table, SWT.NONE);
							tableItem.setText(new String[] {
									(String) map.get("SCID"),
									(String) map.get("EID"),
									(String) map.get("ENAME") ,
									(String) map.get("SCORE"),
									(String) map.get("STIME")
									});
						}
					}
					List<String> params2 = new ArrayList<String>();
					String sql2=" select count(*)  from sc s left join emp e on e.eid=s.eid  where 1=1 ";
					if(name!=null && !"".equals(name)){
						sql2+=" and e.name like ? ";
						params2.add("%"+ name +"%");
					}
					if (choice.equals("全部")) {
						sql2+=" ";
					}else if(choice.equals("0-60")){
						sql2+="  and s.score between 0 and 60  ";
					}else  if(choice.equals("60-75")){
						sql2+=" and s.score between 60 and 75 ";
					}else if(choice.equals("75-90")){
						sql2+=" and s.score between 75 and 90  ";
					}else if(choice.equals("90-100")){
						sql2+=" and s.score between 90 and 100";
					}
					
					int count = (int) db.doSelectFunction(sql2, params2);

					totalpages = count % pagesize == 0 ? count / pagesize
							: count / pagesize + 1;
					label_3.setText("第" + page + "页/ 共" + totalpages + "页/ 共"
							+ count + "条数据");
						
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}
			}
		});
		
	}

	@Override
	protected void checkSubclass() {

	}
	
	public  void initCombo() {
		String sql = "select  eid from emp ";
		DBHelper db = new DBHelper();
		combo_1.removeAll();
		List<Map<String, Object>> list = db.find(sql, null);
		for (Map<String, Object> map : list) {
			String eid = (String) map.get("EID");
			combo_1.add(eid);
		}

	}

	private void deleteMethod(Button btnNewButton_1) {
		TableItem[] tis = table.getSelection();

		if (tis == null || tis.length <= 0) {
			return;
		}
		TableItem ti = tis[0];
		String scid = ti.getText(0);

		String sql = "delete from sc  where eid='" + scid + "'";
		DBHelper db = new DBHelper();
		int result = db.update(sql, null);
		if (result > 0) {
			MessageDialog.openConfirm(shell, "成功", "删除成功");
			button_1.notifyListeners(SWT.Selection, event);
			
		} else {
			MessageDialog.openError(shell, "错误", "删除失败！");
		}
	}
}
