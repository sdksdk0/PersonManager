package cn.pm.utils;

public class DataDictory {
	public static String pwd;
	
	

}
