package cn.pm.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5 {
	private final static String[] hexDigits = { "0","1","2","3","4","5","6","7","8",
		"9","a","b","c","d","e","f"};
	
	/**
	 * 将一个字节数组中的每一个字节值转换为两个十六进制的字符，并拼接成一个字符串
	 * @param b
	 * @return
	 */
	private static String byteArrayToHexString( byte[] b){
		StringBuffer resultSb = new StringBuffer();
		for( int i = 0 ;i< b.length;i++){
			resultSb.append(byteToHexString(b[i]));
		}
		return resultSb.toString();
	}
	
	/**
	 * 将一个字节数字转换为两位十六进制值
	 * @param b
	 * @return
	 */
	private static String byteToHexString(byte b) {
		int n=b;
		if( n<0)
			n = 256+n;
		int d1 = n / 16;
		int d2 = n % 16;
		return hexDigits[d1]+hexDigits[d2];
	
	}
	
	public static String MD5Encode(String origin) throws Exception{
		String resultString = null;
		try {
			resultString = new String(origin);
			/**
			 * MessageDigest 类为应用程序提供信息摘要算法功能
			 */
			MessageDigest md= MessageDigest.getInstance("MD5");
			resultString = byteArrayToHexString(md.digest(resultString.getBytes()));
		} catch (Exception e) {
			throw e;
		}
		
		return resultString;
	}
	
	
	public static void main(String[] args) throws Exception {
		System.out.println(MD5.MD5Encode("b"));
		System.out.println(MD5.MD5Encode("a"));
		System.out.println(MD5.MD5Encode("aaaaaaaaaaaaaaaaaaaa"));
	}

}
