package cn.pm.utils;

import java.io.File;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;



import cn.pm.bean.EmpEntry;
import cn.pm.biz.EmpService;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class DBtoExcel {


	public int  TOExcel(String fileName) {

	
		try {
			WritableWorkbook wwb = null;
			
			 // 创建可写入的Excel工作簿
         // String fileName = System.getProperty("user.home")+File.separator+"Desktop"+File.separator+"人事管理系统.xls";
            File file=new File(fileName);
            if (!file.exists()) {
                file.createNewFile();
            }
			//File file = new File(fileName);

			// 以fileName为文件名来创建一个Workbook
			wwb = Workbook.createWorkbook(file);

			// 创建工作表
			WritableSheet ws = wwb.createSheet("Test Shee 1", 0);

			// 查询数据库中所有的数据
			List<EmpEntry> list = EmpService.getAllByDb();
			
			// 要插入到的Excel表格的行号，默认从0开始
			Label eid = new Label(0, 0, "员工号");
			Label ename = new Label(1, 0, "姓名");
			Label dname = new Label(2, 0, "部门名");
			Label jname = new Label(3, 0, "职务名");
			Label status = new Label(4, 0, "状态");
			Label sex = new Label(5, 0, "性别");
			Label tel = new Label(6, 0, "电话");
			Label address = new Label(7, 0, "地址");
			Label birthday = new Label(8, 0, "生日");
			Label email = new Label(9, 0, "邮箱");

			ws.addCell(eid);
			ws.addCell(ename);
			ws.addCell(dname);
			ws.addCell(jname);
			ws.addCell(status);
			ws.addCell(sex);
			ws.addCell(tel);
			ws.addCell(address);
			ws.addCell(birthday);
			ws.addCell(email);

			for (int i = 0; i < list.size(); i++) {

				Label labeleid = new Label(0, i + 1, list.get(i).getEid());
				Label labelename = new Label(1, i + 1, list.get(i).getEname());
				Label labeldname = new Label(2, i + 1, list.get(i).getDname());
				Label labeljname = new Label(3, i + 1, list.get(i).getJname());
				Label labelstatus = new Label(4, i + 1, list.get(i).getStatus());
				Label labelsex = new Label(5, i + 1, list.get(i).getSex());
				Label labeltel = new Label(6, i + 1, list.get(i).getTel());
				Label labelsaddress = new Label(7, i + 1, list.get(i)
						.getAddress());
				Label labelbirthday = new Label(8, i + 1, list.get(i)
						.getBirthday());
				Label labelemail = new Label(9, i + 1, list.get(i).getEmail());

				ws.addCell(labeleid);
				ws.addCell(labelename);
				ws.addCell(labeldname);
				ws.addCell(labeljname);
				ws.addCell(labelstatus);
				ws.addCell(labelsex);
				ws.addCell(labeltel);
				ws.addCell(labelsaddress);
				ws.addCell(labelbirthday);
				ws.addCell(labelemail);

			}

			// 写进文档
			wwb.write();
			// 关闭Excel工作簿对象
			wwb.close();
			return 1;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
}
