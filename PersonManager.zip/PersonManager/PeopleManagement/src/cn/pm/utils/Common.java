package cn.pm.utils;

import org.apache.log4j.Logger;

import cn.pm.bean.Admin;
import cn.pm.main.Login;
import cn.pm.main.MainUi;
import cn.pm.ui.AdjustSalary;
import cn.pm.ui.BasicManagement;
import cn.pm.ui.CheckManagement;
import cn.pm.ui.DepartmentManagement;
import cn.pm.ui.FileManagement;
import cn.pm.ui.IncomeAccount;
import cn.pm.ui.PostManagement;
import cn.pm.ui.RPManagement;
import cn.pm.ui.ScoreManagement;
import cn.pm.ui.TrainManagemant;
import cn.pm.ui.TreatmentManagement;



public class Common {
	public static BasicManagement bm;
	public static FileManagement fm;
	public static RPManagement rpm;
	public static ScoreManagement scm;
	public static TrainManagemant  tm;
	public static TreatmentManagement ttm;
	public static CheckManagement cm;
	public static AdjustSalary as;
	
	public static  Admin loginAdmin;
	
	public static Logger log=Logger.getLogger(Common.class);

	public static void error(Exception e){
		StackTraceElement[] sts=e.getStackTrace();
		log.error("========================");
		log.error(e.getMessage());
		for(StackTraceElement  ste:sts){
			log.error(ste.toString());
		}
		log.error("========================");
	}

	public static void debug(Exception e){
		StackTraceElement[] sts=e.getStackTrace();
		log.debug("========================");
		log.debug(e.getMessage());
		for(StackTraceElement  ste:sts){
			log.debug(ste.toString());
		}
		log.debug("========================");
	}
	
	
	
}
