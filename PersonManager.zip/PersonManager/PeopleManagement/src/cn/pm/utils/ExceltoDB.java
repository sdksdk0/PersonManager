package cn.pm.utils;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;

import cn.pm.bean.EmpEntry;
import cn.pm.biz.EmpService;
import cn.pm.biz.FileBiz;
import cn.pm.dao.DBHelper;

public class ExceltoDB {
	
	
	public static int excelToDB(String fileName){
	 //得到表格中所有的数据
   // List<EmpEntry> listExcel=EmpService.getAllByExcel(System.getProperty("user.home")+File.separator+"Desktop"+File.separator+"人事管理系统.xls");
 
		List<EmpEntry> listExcel=EmpService.getAllByExcel(fileName);
    EmpService es=new EmpService();
   DBHelper db=new DBHelper();
    
    for (EmpEntry empEntry : listExcel) {
        String eid=empEntry.getEid();
       /* String ename=(String) empEntry.getEname();
    	String dname=(String)  empEntry.getDname();
    	String jname=(String)  empEntry.getJname();
    	String status=(String)  empEntry.getStatus();
    	String sex=(String)  empEntry.getSex();
    	String tel=(String)  empEntry.getTel();
    	String address=(String)  empEntry.getAddress();
    	String birthday=(String)  empEntry.getBirthday().substring(0,10);
    	System.out.println(birthday);
    	String email=(String)  empEntry.getEmail();
    	
    	String photopath=null;
    	
    	
    	String sql1=" select did from dept where name='"+dname+"'";
    	String sql2=" select jid from job where name='"+jname+"'";
    	String did=null;
    	String jid=null;
    	
    	List<Map<String,Object>>  list1=db.find(sql1, null);
    	System.out.println(list1);
    	if(list1!=null && !"".equals(list1)){
    		for (Map<String, Object> map2 : list1) {
    			 did=(String) map2.get("DID");
    			 System.out.println(did);
			}
    	}
    	List<Map<String,Object>>  list2=db.find(sql2, null);
    	if(list2!=null && !"".equals(list2)){
    		for (Map<String, Object> map3 : list2) {
    			 jid=(String) map3.get("JID");
    			 System.out.println(jid);
			}
    	}*/
        
        String did =null;
        String jid =null;
        
    	ResultSet r=null;
        String sql1=" select did from dept where name=?";
        String[] dnamestr={empEntry.getDname()};
        Connection con=db.getConnection();
        try {
			PreparedStatement pst1 = con.prepareStatement(sql1);
			if (dnamestr != null) {
			    for (int i = 0; i < dnamestr.length; i++) {
			        pst1.setString(i + 1, dnamestr[i]);
			        r = pst1.executeQuery();
					while(r.next()){
						 did=r.getString(1);
					}
			        
			    }
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        ResultSet r2=null;
        String sql2=" select did from dept where name=? ";
        String[] jnamestr={empEntry.getDname()};
       
     
        try {
			PreparedStatement pst2 = con.prepareStatement(sql2);
			if (jnamestr != null) {
			    for (int i = 0; i < jnamestr.length; i++) {
			        pst2.setString(i+1 , jnamestr[i]);
			    }
			}
			r2 = pst2.executeQuery();
			while(r2.next()){
					jid=r2.getString(1);
				System.out.println(jid);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
       
        
        
        if (!EmpService.isExist(eid)) {
        
        	
        	String sql3=" insert into emp values(seq_emp_eid.nextval,?,?,?,'0cc175b9c0f1b6a831c399e269772661',?,?,?,?,to_date(?,'yyyy-MM-dd'),empty_blob(),? ) ";
        	
        	String[] str=new String[]{empEntry.getEname(),did,jid,empEntry.getStatus(),empEntry.getSex(),
            		empEntry.getTel(),empEntry.getAddress(),empEntry.getBirthday(),empEntry.getEmail() };
        	
        	int rs=es.AddU(sql3, str);
            if(rs>0){
            	return 1;
            }else{
            	return 0;
            }
        	
        	
        	/*FileBiz fb = new FileBiz();
			try {
				int r = fb.saveEMP(eid, ename, did, jid, status, sex, tel,
						address, birthday, photopath, email);
				if(r>0){
				return 1;
				} else	{
					return 0;
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
        	
        	return 0;*/
        	
        	
        	/*
        	String[] str=new String[]{empEntry.getEname(),empEntry.getDname(),empEntry.getJname(),empEntry.getStatus(),empEntry.getSex(),
            		empEntry.getTel(),empEntry.getAddress(),empEntry.getBirthday(),empEntry.getEmail() };
        	
            //不存在就添加
        	String sql1=" select did from dept where name='"+empEntry.getDname()+"'";
        	String sql2=" select jid from job where name='"+empEntry.getJname()+"'";
        	String did=null;
        	String jid=null;
        	
        	List<Map<String,Object>>  list1=db.find(sql1, null);
        	System.out.println(list1);
        	if(list1!=null && !"".equals(list1)){
        		for (Map<String, Object> map2 : list1) {
        			 did=(String) map2.get("DID");
        			 System.out.println(did);
				}
        	}
        	List<Map<String,Object>>  list2=db.find(sql2, null);
        	if(list2!=null && !"".equals(list2)){
        		for (Map<String, Object> map3 : list2) {
        			 jid=(String) map3.get("JID");
        			 System.out.println(jid);
				}
        	}
        	
        	  for (int i = 0; i < str.length; i++) {
                 
              }
        	
        	
        	
        	
           // String sql="insert into emp values(seq_emp_eid.nextval,?,?,?,'0cc175b9c0f1b6a831c399e269772661',?,?,?,?,to_date(?,'yyyy-MM-dd'),empty_blob(),? )";
          
           List<Object> params = new ArrayList<Object>();
           params.add();
           params.add(did);
           params.add(jid);
           params.add();
           
            int rs=es.AddU(sql, str);
            if(rs>0){
            	return 1;
            }else{
            	return 0;
            }*/
        }else {
        	
        	
        	
        	
        	/*FileBiz fb = new FileBiz();
			try {
				int rs = fb.updateEMP(eid, ename, did, jid, status, sex,
						tel, address, birthday, photopath, email);

				if (rs > 0) {
					return 1;
				} else {
				return 0;
				}
			} catch (Exception e2) {
				e2.printStackTrace();
				
			}*/
        	
        	
        	
            //存在就更新
            String sql4="update emp set name=?,did=(select did from dept where name=? ),jid=(select jid from job where name=? ),status=? ,sex=?,tel=?,address=?,birthday=to_date(?,'yyyy-MM-dd'),email=?  where eid=? ";
            String[] str=new String[]{empEntry.getEname(),empEntry.getDname(),empEntry.getJname(),empEntry.getStatus(),empEntry.getSex(),
            		empEntry.getTel(),empEntry.getAddress(),empEntry.getBirthday().substring(0,10),empEntry.getEmail() ,empEntry.getEid()};
  
            int rs=es.AddU(sql4, str);
            if(rs>0){
            	return 1;
            }else{
            	return 0;
            }
        }
       
    }
	return 0;
	}


}
