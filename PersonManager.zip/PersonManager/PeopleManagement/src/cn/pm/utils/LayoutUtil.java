package cn.pm.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;


public class LayoutUtil {
	
	
	//显示图片
	public static void showPic(Display display, Label label,ImageData imageData){
		imageData=imageData.scaledTo(label.getBounds().width, label.getBounds().height);
		Image image=new Image(display,imageData);
		label.setImage(image);
		
	}
	
	
	public static void showTime( DateTime dt, String value ) throws ParseException{
		SimpleDateFormat sdf=new SimpleDateFormat( "yyyy-MM-dd");
		Date d=sdf.parse(value);
		Calendar c=Calendar.getInstance(  );
		c.setTime(d);
		
		dt.setYear(  c.get(Calendar.YEAR));
		dt.setMonth( c.get(Calendar.MONTH));
		dt.setDay( c.get(Calendar.DATE));
	}
	
	//格式化时间
	public static String parseDateTime( DateTime dt){
		int year=dt.getYear()-1900;
		int month=dt.getMonth();
		int day=dt.getDay();
		
		Date d=new Date(year, month, day);
		SimpleDateFormat sdf=new SimpleDateFormat( "yyyy-MM-dd");
		return sdf.format(d);
	}

	
	//窗口最大化
	
	public static void maxShell(Display display,Shell shell){
		Rectangle displayBounds=display.getPrimaryMonitor().getBounds();
		Rectangle shellBounds=shell.getBounds();
		shell.setLocation(0,0);
		
		shell.setSize(displayBounds.width,displayBounds.height);
	}
	
	//居中显示窗口
	public static void centerShell(Display display,Shell shell){
		Rectangle displayBounds=display.getPrimaryMonitor().getBounds();
		Rectangle shellBounds=shell.getBounds();
		int x=displayBounds.x+(displayBounds.width-shellBounds.width>>1);
		int y=displayBounds.y+(displayBounds.height-shellBounds.height>>1);
		shell.setLocation(x,y);
	}




}
