package cn.pm.bean;

public class TreeBean {
	private String pname;
	private String mname;
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public TreeBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TreeBean(String pname, String mname) {
		super();
		this.pname = pname;
		this.mname = mname;
	}
	@Override
	public String toString() {
		return "Tree [pname=" + pname + ", mname=" + mname + "]";
	}
	public String setString(String pname2) {
		return this.pname=pname;
		
	}
	
	

}
