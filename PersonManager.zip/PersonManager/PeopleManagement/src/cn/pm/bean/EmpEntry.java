package cn.pm.bean;

import java.sql.Blob;
import java.util.Date;

import jxl.NumberCell;

public class EmpEntry {
	
	private String eid;
	private  String ename;
	private String dname;
	private  String jname;
	private String status;
	private  String sex;
	private  String tel;
	private String address;
	private  String birthday;
	private String email;
	public  String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
	public  String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public  String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public  String getJname() {
		return jname;
	}
	public void setJname(String jname) {
		this.jname = jname;
	}
	public  String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public  String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public  String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public  String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public  String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public  String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "EmpEntry [eid=" + eid + ", ename=" + ename + ", dname=" + dname
				+ ", jname=" + jname + ", status=" + status + ", sex=" + sex
				+ ", tel=" + tel + ", address=" + address + ", birthday="
				+ birthday + ", email=" + email + "]";
	}
	public EmpEntry(String eid, String ename, String dname, String jname,
			String status, String sex, String tel, String address,
			String birthday, String email) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.dname = dname;
		this.jname = jname;
		this.status = status;
		this.sex = sex;
		this.tel = tel;
		this.address = address;
		this.birthday = birthday;
		this.email = email;
	}
	
	
	
	
	
	
	
	
	
}