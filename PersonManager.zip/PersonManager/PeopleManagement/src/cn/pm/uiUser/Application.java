package cn.pm.uiUser;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

import cn.pm.dao.DBHelper;
import cn.pm.main.Login;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.Combo;

public class Application extends Composite {
	private Text text_1;
	DBHelper db=new DBHelper();
	private Shell shell;
	
	private DateTime dateTime;
	private DateTime dateTime_1;
	private Table table;
	private Text text;
	private Label label_2;
	
	private Event event; // 与按钮绑定的事件
	private int pagesize = 8;
	// 第几页
	private int page = 1;
	private int totalpages;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Application(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_FORCE);
		shell = parent.getShell();
		setSize(1414, 760);
		setLayout(new FillLayout(SWT.HORIZONTAL));
		
		SashForm sashForm = new SashForm(this, SWT.NONE);
		
		Group group = new Group(sashForm, SWT.NONE);
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setBackgroundMode(SWT.INHERIT_DEFAULT);
	
		group.setText("当前是>用户系统>请假申请");
		
		Label label = new Label(group, SWT.NONE);
		label.setBounds(226, 462, 114, 20);
		label.setText("请假开始时间：");
		
		Label label_1 = new Label(group, SWT.NONE);
		label_1.setBounds(226, 549, 115, 20);
		label_1.setText("请假结束时间：");
		
		 dateTime = new DateTime(group, SWT.BORDER);
		dateTime.setBounds(391, 462, 110, 28);
		
		 dateTime_1 = new DateTime(group, SWT.BORDER);
		dateTime_1.setBounds(391, 541, 110, 28);
		
		 label_2 = new Label(group, SWT.NONE);
		label_2.setBounds(425, 627, 76, 20);
		label_2.setText("共计:天");
		
		Button button = new Button(group, SWT.NONE);

		button.setBounds(1198, 148, 98, 30);
		button.setText("确认提交");
		
		Button button_1 = new Button(group, SWT.NONE);
	
		button_1.setBounds(1198, 252, 98, 30);
		button_1.setText("修改申请");
		
		Button button_2 = new Button(group, SWT.NONE);

		button_2.setBounds(1198, 61, 98, 30);
		button_2.setText("查询");
		
		Label label_4 = new Label(group, SWT.NONE);
		label_4.setBounds(550, 494, 76, 20);
		label_4.setText("请假原因：");
		
		text_1 = new Text(group, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL);
		text_1.setBounds(712, 491, 264, 155);
		
		Button button_3 = new Button(group, SWT.NONE);
		
		button_3.setBounds(1198, 355, 98, 30);
		button_3.setText("删除申请");
		
		table = new Table(group, SWT.BORDER | SWT.FULL_SELECTION);
	
		table.setBounds(10, 108, 1084, 221);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(100);
		tableColumn.setText("假条号");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(218);
		tableColumn_1.setText("开始时间");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(260);
		tableColumn_2.setText("结束时间");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(273);
		tableColumn_4.setText("原因");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(199);
		tableColumn_3.setText("状态");
		
		Button button_4 = new Button(group, SWT.NONE);
	
		button_4.setBounds(823, 378, 98, 30);
		button_4.setText("上一页");
		
		Button button_5 = new Button(group, SWT.NONE);
	
		button_5.setBounds(994, 378, 98, 30);
		button_5.setText("下一页");
		
		Label label_3 = new Label(group, SWT.NONE);
		label_3.setBounds(226, 360, 327, 36);
		
		Label label_5 = new Label(group, SWT.NONE);
		label_5.setBounds(129, 66, 76, 20);
		label_5.setText("请假状态：");
		
		Combo combo = new Combo(group, SWT.READ_ONLY);
		combo.setItems(new String[] {"", "同意", "不同意", "待审核"});
		combo.setBounds(248, 63, 92, 28);
		
		Label label_6 = new Label(group, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_6.setBounds(433, 414, 698, 11);
		
		Label label_7 = new Label(group, SWT.SEPARATOR | SWT.VERTICAL);
		label_7.setBounds(1118, 32, 5, 555);
		
		Label label_8 = new Label(group, SWT.SEPARATOR | SWT.HORIZONTAL);
		label_8.setBounds(401, 79, 722, 12);
		
		Label label_9 = new Label(group, SWT.NONE);
		label_9.setBounds(28, 448, 76, 20);
		label_9.setText("请假号：");
		
		text = new Text(group, SWT.BORDER);
		text.setEditable(false);
		text.setBounds(41, 526, 73, 26);
		sashForm.setWeights(new int[] {1});
		
		event = new Event();
		event.widget = button_2;
		
		Button button_6 = new Button(group, SWT.NONE);
		//重置
		button_6.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				text_1.setText("");
			}
		});
	
		button_6.setBounds(1198, 472, 98, 30);
		button_6.setText("重置");
		
		//table被选中的时候
		table.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TableItem[] tis = table.getSelection();
				if (tis == null || tis.length < 0) {
					return;
				}
				TableItem ti = tis[0];
				String lid= ti.getText(0);
				String lstart= ti.getText(1).substring(0, 10);;
				String lend = ti.getText(2).substring(0, 10);;
				String reason=ti.getText(3);
		
				text.setText(lid);
				
				try {
					LayoutUtil.showTime(dateTime, lstart);
					LayoutUtil.showTime(dateTime_1, lend);
				} catch (ParseException e1) {
					e1.printStackTrace();
				}
				
				text_1.setText(reason);
				initDay();
				
			}
		});
		
		
		//下一页
		button_5.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page++;
				if (page > totalpages) {
					MessageDialog.openError(shell, "错误", "已经是最后一页了！");
					page = totalpages;
				}
				button_2.notifyListeners(SWT.Selection, event);
				
			}
		});
		
		
		//上一页
		button_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				page--;
				if (page <= 0) {
					MessageDialog.openError(shell, "错误", "没有上一页了！");
					page = 1;
					return;
				}
				button_2.notifyListeners(SWT.Selection, event);

			}
		});
		
		//删除
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String lid=text.getText().trim();
				
				String sql="delete from  leave where lid='"+lid+"'";
				
				try {
					int rs=db.update(sql, null);
					if(rs>0){
						button_2.notifyListeners(SWT.Selection, event);
						MessageDialog.openInformation(shell, "成功", "删除成功！");
						text_1.setText("");
						text.setText("");
					}else{
						MessageDialog.openError(shell, "错误", "删除失败");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}
				
			}
		});
		
		//修改申请
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String lid=text.getText().trim();
				String lstart=LayoutUtil.parseDateTime(dateTime);
				String lend=LayoutUtil.parseDateTime(dateTime_1);
				String reason=text_1.getText().trim();
				
				String sql="update leave set lstart=to_date(?,'yyyy-MM-dd'),lend=to_date(?,'yyyy-MM-dd'),reason=?  where lid=?";
				
				List<Object> params=new ArrayList<Object>();
				params.add(lstart);
				params.add(lend);
				params.add(reason);
				params.add(lid);
				
				try {
					int rs=db.update(sql, params);
					if(rs>0){
						button_2.notifyListeners(SWT.Selection, event);
						MessageDialog.openInformation(shell, "成功", "修改成功！");
						text_1.setText("");
						text.setText("");
					}else{
						MessageDialog.openError(shell, "错误", "修改失败");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}
				
			}
		});
		
		
		//请假状态查询
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String eid=Login.text.getText().trim();
				String type=combo.getText().trim();
			
				List<Object> params = new ArrayList<Object>();
				String sql="select *from (select A.*,rownum rn from (select * from leave where eid =?  " ;
				params.add(eid);
				
				if(type!=null && !"".equals(type)){
					sql+=" and type=?  and eid=? ";
					params.add(type);
					params.add(eid);
				}
				
				
				int max = page * pagesize;
				int min = (page - 1) * pagesize;
				
				sql+=" ) A where rownum<? ) where rn>?";
				params.add(max);
				params.add(min);

				table.removeAll();
				text.setText("");
				List<Map<String,Object>>  list=db.find(sql, params);
				if(list!=null && !"".equals(list)){
					for (Map<String, Object> map : list) {
						TableItem tableItem = new TableItem(table, SWT.NONE);
						tableItem.setText(new String[] {
								(String) map.get("LID"),
								(String) map.get("LSTART"),
								(String) map.get("LEND"),
								(String)  map.get("REASON"),
								(String) map.get("TYPE") });
					}
				}
				List<String> params1=new ArrayList<String>();
				String sql2 = "select count(*) from leave  where 1=1 ";
				
				if(type!=null && !"".equals(type)){
					sql2+=" and type= ? ";
					params1.add(type);
				}
				if(eid!=null && !"".equals(eid)){
					sql2+=" and eid=?";
					params1.add(eid);
				}
		
				int count = (int) db.doSelectFunction(sql2, params1);

				totalpages = count % pagesize == 0 ? count / pagesize : count
						/ pagesize + 1;
				label_3.setText("第" + page + "页/ 共" + totalpages + "页/ 共"
						+ count + "条数据");
				
			}
		});
		
		
		//确认提交
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String eid=Login.text.getText();
				String lstart=LayoutUtil.parseDateTime(dateTime);
				String lend=LayoutUtil.parseDateTime(dateTime_1);
				String reason=text_1.getText().trim();
				
				String sql="insert into leave values (seq_leave_lid.nextval,?,to_date(?,'yyyy-MM-dd'),to_date(?,'yyyy-MM-dd'),?,'待审核')";
				
				List<Object> params=new ArrayList<Object>();
				params.add(eid);
				params.add(lstart);
				params.add(lend);
				params.add(reason);
				
				
				try {
					int rs=db.update(sql, params);
					if(rs>0){
						button_2.notifyListeners(SWT.Selection, event);
						MessageDialog.openInformation(shell, "成功", "您的请假申请已成功提交！");
						text_1.setText("");
					}else{
						MessageDialog.openError(shell, "错误", "提交失败");
					}
				} catch (Exception e1) {
					e1.printStackTrace();
					MessageDialog.openError(shell, "错误", e1.getMessage());
				}

			}
		});
		
		
	}

	private void initDay() {
		String lid=text.getText().trim();
		String sql="select round(lend-lstart) as day  from leave where lid=?";
		
		List<Object>  params=new ArrayList<Object>();
		//params.add(lend);
		//params.add(lstart);
		params.add(lid);
		label_2.setText("");
		List<Map<String,Object>>  list=db.find(sql, params);
		if(list!=null && !"".equals(list)){
			for (Map<String, Object> map : list) {
				String day=(String) map.get("DAY");
				label_2.setText("共"+day+"天");
			}
		}
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
