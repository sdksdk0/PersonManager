package cn.pm.uiUser;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import cn.pm.dao.DBHelper;
import cn.pm.main.Login;
import cn.pm.utils.MD5;

import org.eclipse.wb.swt.SWTResourceManager;

public class UserSet extends Composite {
	private Text text;
	private Text text_1;
	private Text text_2;
	private Shell shell;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public UserSet(Composite parent, int style) {
		super(parent, style);
		setLayout(new FillLayout(SWT.HORIZONTAL));
		
		SashForm sashForm = new SashForm(this, SWT.NONE);
		
		Group group = new Group(sashForm, SWT.NONE);
		setSize(1414, 760);
		group.setBackgroundMode(SWT.INHERIT_DEFAULT);
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setText("当前是>用户系统>用户设置");
		
		Label label = new Label(group, SWT.NONE);
		label.setBounds(349, 80, 76, 20);
		label.setText("修改密码：");
		
		Label label_1 = new Label(group, SWT.NONE);
		label_1.setBounds(444, 155, 76, 20);
		label_1.setText("原密码：");
		
		text = new Text(group, SWT.BORDER | SWT.PASSWORD);
		text.setBounds(603, 152, 151, 26);
		
		Label label_2 = new Label(group, SWT.NONE);
		label_2.setBounds(444, 223, 76, 20);
		label_2.setText("新密码：");
		
		text_1 = new Text(group, SWT.BORDER | SWT.PASSWORD);
		text_1.setBounds(603, 220, 151, 26);
		
		Button button = new Button(group, SWT.NONE);
	
		button.setBounds(539, 454, 98, 30);
		button.setText("修改");
		
		Label label_3 = new Label(group, SWT.NONE);
		label_3.setBounds(444, 291, 76, 20);
		label_3.setText("确认密码：");
		
		text_2 = new Text(group, SWT.BORDER | SWT.PASSWORD);
		text_2.setBounds(603, 288, 151, 26);
		
		Button button_2 = new Button(group, SWT.NONE);
	
		button_2.setBounds(728, 454, 98, 30);
		button_2.setText("取消");
		
		Label c = new Label(group, SWT.NONE);
		c.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		c.setBounds(844, 291, 139, 20);
		
		Label b = new Label(group, SWT.NONE);
		b.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));

		b.setBounds(844, 223, 198, 20);
		sashForm.setWeights(new int[] {1});
		
	
		
		//修改密码
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String  eid =Login.text.getText().trim();
				String oldpwd=text.getText().trim();
				String newpwd=text_1.getText().trim();
				String newpwd2=text_2.getText().trim();
			
				if(newpwd==null || "".equals(newpwd) ||newpwd2==null || "".equals(newpwd2)){
					
					b.setText("密码不能为空");			
					c.setText("密码不能为空");
					return;
				}
				if(newpwd.equals(newpwd2) && newpwd!=null &&!"".equals(newpwd) && oldpwd!=null && !"".equals(oldpwd) ){
					String sql="update emp set pwd=?  where eid=? ";
					DBHelper db=new DBHelper();
					List<Object>  params=new ArrayList<Object>();
				    try {
						params.add(MD5.MD5Encode(newpwd));
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					params.add(eid);
					int rs=db.update(sql, params);
					
					if(rs>0){
						MessageDialog.openInformation(shell,"成功", "修改成功！");
						b.setText("");	
						c.setText("");	
						text.setText("");
						text_1.setText("");
						text_2.setText("");
						
						
					}else{
						MessageDialog.openError(shell,"失败", "修改失败，请重试!");
						return;
					}
				}	
			}
		});
		
		
		//取消
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				text.setText("");
				text_1.setText("");
				text_2.setText("");
				b.setText("");
				c.setText("");
			}
		});

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
