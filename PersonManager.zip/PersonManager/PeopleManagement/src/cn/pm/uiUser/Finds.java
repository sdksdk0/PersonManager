package cn.pm.uiUser;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import cn.pm.chart.AllSelect;
import cn.pm.chart.CheckChart;

import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;

public class Finds extends Composite {

	private CheckChart cc;
	private Text text;
	private AllSelect as;
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Finds(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_FORCE);
	
		setLayout(new FillLayout(SWT.HORIZONTAL));
		
		SashForm sashForm = new SashForm(this, SWT.NONE);
		sashForm.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setSize(1414, 760);
		Group group = new Group(sashForm, SWT.NONE);
		group.setText("当前是>用户系统>综合查询");
		group.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		Composite composite = new Composite(group, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		SashForm sashForm_1 = new SashForm(composite, SWT.NONE);
		
		Composite composite_1 = new Composite(sashForm_1, SWT.NONE);
		composite_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_1.setLayout(new FormLayout());
		
		Button button = new Button(composite_1, SWT.NONE);
		
		FormData fd_button = new FormData();
		fd_button.left = new FormAttachment(0, 45);
		fd_button.top = new FormAttachment(0, 50);
		button.setLayoutData(fd_button);
		button.setText("签到查询");
		
		Button button_4 = new Button(composite_1, SWT.NONE);

		FormData fd_button_4 = new FormData();
		fd_button_4.top = new FormAttachment(button, 35);
		fd_button_4.left = new FormAttachment(button, 0, SWT.LEFT);
		button_4.setLayoutData(fd_button_4);
		button_4.setText("综合查询");
		
		Composite composite_2 = new Composite(sashForm_1, SWT.NONE);
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		SashForm sashForm_2 = new SashForm(composite_2, SWT.VERTICAL);
		
		Composite composite_3 = new Composite(sashForm_2, SWT.NONE);
		StackLayout sl = new StackLayout();
		
		cc=new CheckChart(composite_3, SWT.None);
		composite_3.setLayout(sl);
		as=new AllSelect(composite_3, SWT.None);
		composite_3.setLayout(sl);
		
		
		Composite composite_4 = new Composite(sashForm_2, SWT.NONE);
		
		text = new Text(composite_4, SWT.BORDER);
		text.setEditable(false);
		text.setBounds(271, 10, 129, 84);
		
		Label label = new Label(composite_4, SWT.NONE);
		label.setBounds(39, 13, 95, 20);
		label.setText("二维码生成：");
		sashForm_2.setWeights(new int[] {390, 89});
		sashForm_1.setWeights(new int[] {179, 494});
		sashForm.setWeights(new int[] {1});
		
		//签到查询
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				sl.topControl = cc;
				composite_3.layout();
			}
		});
		//综合查询
		button_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				sl.topControl = as;
				composite_3.layout();
				
			}
		});

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
