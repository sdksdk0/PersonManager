package cn.pm.uiUser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.TouchListener;
import org.eclipse.swt.events.TouchEvent;

import cn.pm.dao.DBHelper;
import cn.pm.main.Login;

public class Check extends Composite {
	
	private Shell shell;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public Check(Composite parent, int style) {
		super(parent, style);
		setBackgroundMode(SWT.INHERIT_DEFAULT);
		setBackgroundImage(SWTResourceManager.getImage(Check.class, "/image/b12.jpg"));
		setLayout(new FillLayout(SWT.HORIZONTAL));
		setSize(1414, 760);
		SashForm sashForm = new SashForm(this, SWT.NONE);
		
		Group group = new Group(sashForm, SWT.NONE);
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setText("当前是>用户系统>签到");
		
		Label label = new Label(group, SWT.NONE);
		
		
		label.setLocation(394, 291);
		label.setSize(233, 239);
		label.setBackgroundImage(SWTResourceManager.getImage(Check.class, "/image/b1 (2).jpg"));
		
		Label label_1 = new Label(group, SWT.NONE);
		label_1.setLocation(797, 102);
		label_1.setSize(76, 20);
		label_1.setText("说明：");
		
		Label label_2 = new Label(group, SWT.NONE);
		label_2.setLocation(797, 158);
		label_2.setSize(562, 20);
		label_2.setText("双击手势按钮进行签到，正常工作时间是9：00-17：00");
		
		Label label_3 = new Label(group, SWT.NONE);
		label_3.setBounds(31, 254, 194, 20);
		sashForm.setWeights(new int[] {1});
		
	
		
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				label_3.setText("!!请双击进行签到");	
			}
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				String  eid =Login.text.getText();
		
				 String sql="insert into clock values (seq_clock_clid.nextval,?,sysdate)";
				DBHelper db=new DBHelper();
				List<Object>  params=new ArrayList<Object>();
			
				params.add(eid);
				int rs=db.update(sql, params);
				
				if(rs>0){
					MessageDialog.openInformation(shell,"成功", "签到成功！");
					label_3.setText("");	
				}else{
					MessageDialog.openError(shell,"失败", "签到失败，请重试!");
					return;
				}
				
			}
		});

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
