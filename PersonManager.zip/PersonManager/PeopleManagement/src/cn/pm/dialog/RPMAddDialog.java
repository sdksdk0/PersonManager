package cn.pm.dialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Button;

import cn.pm.dao.DBHelper;
import cn.pm.ui.RPManagement;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.wb.swt.SWTResourceManager;

public class RPMAddDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text_2;
	private Text text;

	/**
	 * Create the dialog.
	 * 
	 * @param parent
	 * @param style
	 */
	public RPMAddDialog(Shell parent, int style) {
		super(parent, style);
		setText("添加");
	}

	/**
	 * Open the dialog.
	 * 
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(597, 426);
		shell.setText(getText());
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));

		Composite composite = new Composite(shell, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group = new Group(composite, SWT.NONE);
		group.setBackgroundMode(SWT.INHERIT_FORCE);
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setText("添加数据");

		Label label = new Label(group, SWT.NONE);
		label.setText("奖惩号：");
		label.setBounds(55, 52, 61, 17);

		Label label_2 = new Label(group, SWT.NONE);
		label_2.setText("类型：");
		label_2.setBounds(103, 98, 61, 17);

		Combo combo = new Combo(group, SWT.NONE);
		combo.setItems(new String[] { "奖励", "处罚" });
		combo.setBounds(207, 95, 183, 28);
		combo.select(0);

		Label label_3 = new Label(group, SWT.NONE);
		label_3.setText("原因：");
		label_3.setBounds(111, 142, 53, 17);

		Label label_4 = new Label(group, SWT.NONE);
		label_4.setText("金额：");
		label_4.setBounds(114, 249, 61, 17);

		text_2 = new Text(group, SWT.BORDER);

		text_2.setBounds(209, 246, 181, 23);

		Label label_5 = new Label(group, SWT.NONE);
		label_5.setText("时间：");
		label_5.setBounds(122, 291, 53, 17);

		DateTime dateTime = new DateTime(group, SWT.BORDER);
		dateTime.setBounds(219, 291, 171, 24);

		Button button = new Button(group, SWT.NONE);
		button.setText("确定");
		button.setBounds(254, 354, 80, 27);

		Label label_1 = new Label(group, SWT.NONE);
		label_1.setBounds(136, 49, 98, 20);
		label_1.setText(RPManagement.text_1.getText().trim());

		Label label_6 = new Label(group, SWT.NONE);
		label_6.setBounds(314, 52, 76, 20);
		label_6.setText("员工名：");

		Label label_7 = new Label(group, SWT.BORDER);
		label_7.setBounds(424, 51, 98, 20);
		label_7.setText(RPManagement.combo_1.getText().trim());

		text = new Text(group, SWT.BORDER);
		text.setBounds(209, 139, 181, 86);

		text_2.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent e) {
				Pattern pattern = Pattern.compile("[0-9]\\d*");
				Matcher matcher = pattern.matcher(e.text);
				if (matcher.matches()) // 处理数字
					e.doit = true;
				else if (e.text.length() > 0) // 有字符情况,包含中文、空格
					e.doit = false;
				else
					// 控制键
					e.doit = true;

			}
		});

		// 添加
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String eid = label_7.getText().trim();
				String type = combo.getText().trim();
				String reason = text.getText().trim();
				String rmoney = text_2.getText().trim();
				String gaintime = LayoutUtil.parseDateTime(dateTime);

				if(eid==null && "".equals(eid)){
					MessageDialog.openError(shell,"错误","员工名不能为空！");
					return;
				}
				
				
				if (type != null
						&& !"".equals(type) && reason != null
						&& !"".equals(reason) && rmoney != null
						&& !"".equals(rmoney)) {

					String sql = "insert into rm values(seq_rm_rmid.nextval,?,?,?,?,to_date(?,'yyyy-MM-dd'))";
					List<Object> params = new ArrayList<Object>();
					params.add(eid);
					params.add(type);
					params.add(reason);
					params.add(rmoney);
					params.add(gaintime);

					DBHelper db=new DBHelper();
					int result = db.update(sql, params);
					if (result > 0) {
						MessageDialog.openInformation(shell, "温馨提示", "添加成功");
						RPManagement.selectbutton.notifyListeners(
								SWT.Selection, RPManagement.event);
						
						RPMAddDialog.this.shell.setVisible(false);
						
					} else {
						MessageDialog.openError(shell, "温馨提示", "添加失败");
					}
				}
			}
		});

	}
}
