package cn.pm.dialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Button;

import cn.pm.dao.DBHelper;
import cn.pm.ui.RPManagement;
import cn.pm.ui.TreatmentManagement;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.events.VerifyListener;
import org.eclipse.swt.events.VerifyEvent;
import org.eclipse.wb.swt.SWTResourceManager;

public class TTMAddDialog extends Dialog {

	protected Object result;
	protected Shell shell;
	private Text text_2;

	/**
	 * Create the dialog.
	 * 
	 * @param parent
	 * @param style
	 */
	public TTMAddDialog(Shell parent, int style) {
		super(parent, style);
		setText("SWT Dialog");
	}

	/**
	 * Open the dialog.
	 * 
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(597, 333);
		shell.setText("添加");
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));

		Composite composite = new Composite(shell, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group = new Group(composite, SWT.NONE);
		group.setBackgroundMode(SWT.INHERIT_FORCE);
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		group.setText("添加数据");

		Label label = new Label(group, SWT.NONE);
		label.setText("福利号：");
		label.setBounds(55, 52, 61, 17);

		Label label_2 = new Label(group, SWT.NONE);
		label_2.setText("类型：");
		label_2.setBounds(135, 112, 61, 17);

		Combo combo = new Combo(group, SWT.NONE);
		combo.setItems(new String[] {"五险一金", "四险一金", "三险一金"});
		combo.setBounds(222, 109, 183, 28);
		combo.select(0);

		Label label_4 = new Label(group, SWT.NONE);
		label_4.setText("金额：");
		label_4.setBounds(135, 171, 61, 17);

		text_2 = new Text(group, SWT.BORDER);

		text_2.setBounds(224, 168, 181, 23);

		Button button = new Button(group, SWT.NONE);
		button.setText("确定");
		button.setBounds(260, 246, 80, 27);

		Label label_1 = new Label(group, SWT.BORDER);
		label_1.setBounds(136, 49, 98, 20);
		label_1.setText(TreatmentManagement.text_1.getText().trim());

		Label label_6 = new Label(group, SWT.NONE);
		label_6.setBounds(329, 52, 76, 20);
		label_6.setText("员工名：");

		Label label_7 = new Label(group, SWT.BORDER);
		label_7.setBounds(421, 51, 76, 20);
		label_7.setText(TreatmentManagement.combo_1.getText().trim());

		text_2.addVerifyListener(new VerifyListener() {
			public void verifyText(VerifyEvent e) {
				Pattern pattern = Pattern.compile("[0-9]\\d*");
				Matcher matcher = pattern.matcher(e.text);
				if (matcher.matches()) // 处理数字
					e.doit = true;
				else if (e.text.length() > 0) // 有字符情况,包含中文、空格
					e.doit = false;
				else
					// 控制键
					e.doit = true;

			}
		});

		// 添加
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String eid= label_7.getText().trim();
				String type = combo.getText().trim();
				String wmoney = text_2.getText().trim();
				
				if(eid==null && "".equals(eid)){
					MessageDialog.openError(shell,"错误","员工名不能为空！");
					return;
				}
				if (type != null&& !"".equals(type)  
						&& wmoney != null && !"".equals(wmoney)) {

					String sql = "insert into welfare values(seq_welfare_wid.nextval,?,?,?) ";
					List<Object> params = new ArrayList<Object>();
					params.add(eid);
					params.add(type);
					params.add(wmoney);

					DBHelper db=new DBHelper();
					int result = db.update(sql, params);
					if (result > 0) {
						MessageDialog.openInformation(shell, "温馨提示", "添加成功");
						TreatmentManagement.selectbutton.notifyListeners(
								SWT.Selection, TreatmentManagement.event);
						
						TTMAddDialog.this.shell.setVisible(false);
						
					} else {
						MessageDialog.openError(shell, "温馨提示", "添加失败");
					}
				}
			}
		});

	}
}
