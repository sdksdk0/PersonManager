package cn.pm.chart;

import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import cn.pm.dao.DBHelper;
import cn.pm.main.Login;

public class AllSelect extends Composite {
	private Table table;

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public AllSelect(Composite parent, int style) {
		super(parent, style);
		setLayout(new FillLayout(SWT.HORIZONTAL));
		
		Composite composite_3 = new Composite(this, SWT.NONE);
		composite_3.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		SashForm sashForm = new SashForm(composite_3, SWT.VERTICAL);
		
		Composite composite = new Composite(sashForm, SWT.NONE);
		
		Button button = new Button(composite, SWT.NONE);
	
		button.setBounds(59, 47, 98, 30);
		button.setText("查询所有");
		
		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		table = new Table(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		TableColumn tableColumn = new TableColumn(table, SWT.NONE);
		tableColumn.setWidth(83);
		tableColumn.setText("员工号");
		
		TableColumn tableColumn_1 = new TableColumn(table, SWT.NONE);
		tableColumn_1.setWidth(89);
		tableColumn_1.setText("部门名");
		
		TableColumn tableColumn_3 = new TableColumn(table, SWT.NONE);
		tableColumn_3.setWidth(81);
		tableColumn_3.setText("职务名");
		
		TableColumn tableColumn_2 = new TableColumn(table, SWT.NONE);
		tableColumn_2.setWidth(73);
		tableColumn_2.setText("基本工资");
		
		TableColumn tableColumn_4 = new TableColumn(table, SWT.NONE);
		tableColumn_4.setWidth(100);
		tableColumn_4.setText("福利类型");
		
		TableColumn tableColumn_5 = new TableColumn(table, SWT.NONE);
		tableColumn_5.setWidth(100);
		tableColumn_5.setText("总福利金额");
		
		TableColumn tableColumn_9 = new TableColumn(table, SWT.NONE);
		tableColumn_9.setWidth(100);
		tableColumn_9.setText("业绩评分");
		
		TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("总工资");
		sashForm.setWeights(new int[] {86, 306});
		
		
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String eid=Login.text.getText().trim();
				String sql=" select e.eid, d.name dname, j.name jname, s.smoney, sc.score, w.type, w.wmoney ,s.smoney+w.wmoney+sc.score*0.85 as total  from emp e "
						+ " join dept d on e.did = d.did  join job j on e.jid = j.jid  "
						+ " join salary s on j.jid = s.jid   join sc on sc.eid = e.eid  and e.eid='"+eid+"' " 
						+ "  left join welfare w on e.eid = w.eid  "; 
				DBHelper db=new DBHelper();
				table.removeAll();
				List<Map<String,Object>> list=db.find(sql,null);
				if(list!=null && !"".equals(list)){
					for (Map<String, Object> map : list) {
						TableItem tableItem = new TableItem(table, SWT.NONE);
						String[] str = new String[] {
								(String) map.get("EID"),
								(String) map.get("DNAME"),
								(String) map.get("JNAME"),
								(String) map.get("SMONEY"),
								(String) map.get("TYPE"),
								(String) map.get("WMONEY"),
								(String) map.get("SCORE"),
								(String) map.get("TOTAL"),
								};
								tableItem.setText(str);	
					}
				}	
			}
		});
		

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
