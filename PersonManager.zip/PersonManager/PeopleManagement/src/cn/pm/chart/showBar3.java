
package cn.pm.chart;

import java.awt.Color;
import java.awt.Dimension;



import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.TableItem;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

import cn.pm.dao.DBHelper;


public class showBar3 extends JFrame {
	private String[]  dname =null;
	private static DBHelper db=new DBHelper();
	

    static {
        // set a theme using the new shadow generator feature available in
        // 1.0.14 - for backwards compatibility it is not enabled by default
        ChartFactory.setChartTheme(new StandardChartTheme("JFree/Shadow",
                true));
    }

    /**
     * Creates a new demo instance.
     *
     * @param title  the frame title.
     */
    public showBar3(String title) {
        super(title);
        setBackground(Color.WHITE);
        CategoryDataset dataset = createDataset();
        JFreeChart chart = createChart(dataset);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setBackground(Color.WHITE);
        chartPanel.setFillZoomRectangle(true);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setPreferredSize(new Dimension(1000, 500));
        setContentPane(chartPanel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
    }

    /**
     * Returns a sample dataset.
     *
     * @return The dataset.
     */
    private static CategoryDataset createDataset() {
    	
    	 DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    	
    	 String year=showBar.combo.getText().trim();
		 String month=showBar.combo_1.getText().trim();
			
    	 List<Object> params = new ArrayList<Object>();

    	 String sql = "select e.eid,e.name as ename,e.sex,d.name as dname,j.name as jname,s.smoney,w.wmoney,s.smoney+w.wmoney  as basemoney  ,"
					+ "extract(year from gaintime) year,  "
					+ "extract(month from gaintime) month  "
					+ "from emp e join  dept d on e.did=d.did  join  job j  on j.jid=e.jid  join salary s  on  s.jid=e.jid  join welfare w  on w.eid=e.eid "
					+ "left join rm   on  rm.eid=e.eid  "
					+ "group by  e.eid,e.name ,e.sex,d.name ,j.name ,s.smoney,w.wmoney, "
					+ "s.smoney+w.wmoney  ,extract(year from gaintime) ,extract(month from gaintime)   having  1=1 ";
    	 
			

			if(year.equals("全部")){
				sql+="  ";
			}else  if(year!=null && !"".equals(year)){
				sql+="   and extract(year from gaintime)=? ";
				params.add(year);
			}
			
			
			if(month.equals("全部")){
				sql+="  ";
			}else  if(month!=null && !"".equals(month)){
				sql+="   and extract(month from gaintime)=? ";
				params.add(month);
			}
			List<Map<String, Object>> list = db.find(sql.toString(), params);

			int summoney = 0; // 查询时工资条总工资数 ,个人奖励总额，个人处罚总额
			int tol = 0;
			String dname2=null;
			String ename2=null;
			String[] str = null;
			if (list != null && list.size() > 0) {
				for (Map<String, Object> data : list) {
				
					String eid2 = (String) data.get("EID");
					 ename2 = (String) data.get("ENAME");
					String sex2 = (String) data.get("SEX");
					 dname2 = (String) data.get("DNAME");
					String jname2 = (String) data.get("JNAME");
					String smoney2 = (String) data.get("SMONEY");
					String wmoney2 = (String) data.get("WMONEY");
					String month2 = (String) data.get("MONTH");

					String gaintime = (String) data.get("YEAR") + "年"
							+ data.get("MONTH") + "月";

					int rmoney = 0, rmoney1 = 0;
					
					String sql3 = " select type,rmoney from rm  where eid='"
							+ eid2 + "'"+ "  and extract(month from gaintime)='" +month2+"'" ;
					String type = null;

					List<Map<String, Object>> list3 = db.find(sql3, null);
					for (Map<String, Object> map : list3) {
						type = (String) map.get("TYPE");

						if (type.equals("奖励")) {
							rmoney += Integer.parseInt((String) map
									.get("RMONEY"));
						} else {
							rmoney1 -= Integer.parseInt((String) map
									.get("RMONEY"));
						}
					}

					tol = rmoney
							+ rmoney1
							+ Integer.parseInt((String) data
									.get("BASEMONEY"));
					
					summoney += tol;
					dataset.addValue(tol, dname2, ename2);
				}
				
			}
		
        return dataset;
    }

    /**
     * Creates a sample chart.
     *
     * @param dataset  the dataset.
     *
     * @return The chart.
     */
    private static JFreeChart createChart(CategoryDataset dataset) {
    	JFreeChart chart = ChartFactory.createBarChart(
                " ", null /* x-axis label*/, 
                    "总工资" /* y-axis label */, dataset);
          
        chart.setBackgroundPaint(Color.white);
        CategoryPlot plot = (CategoryPlot) chart.getPlot();
        CategoryAxis domainAxis = plot.getDomainAxis();
           
        Font font = new Font("宋体", Font.BOLD, 18);
        TextTitle title = new TextTitle("员工总薪资统计图", font);
        //副标题
        TextTitle subtitle = new TextTitle("员工薪资", new Font("黑体", Font.BOLD, 15));
        chart.addSubtitle(subtitle);
        chart.setTitle(title); //标题
        
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        
        //y轴乱码
        rangeAxis.setLabelFont(new Font("宋体", Font.PLAIN, 15));
        //x轴乱码
        domainAxis .setTickLabelFont(new Font("宋体", Font.PLAIN, 15));
            
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());   
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
   
       renderer.setDrawBarOutline(false);
        
      //底部图例乱码
        chart.getLegend().setItemFont(new Font("宋体", Font.PLAIN,15));//.setFrame(BlockBorder.NONE);;
        return chart;
    }
    public static void main(String string) {
        showBar3 demo = new showBar3("员工总工资图");
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
        
    }
}
