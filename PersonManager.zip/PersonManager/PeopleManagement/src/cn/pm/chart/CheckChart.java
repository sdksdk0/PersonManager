package cn.pm.chart;


import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.swtchart.Chart;
import org.swtchart.IAxis;

import org.swtchart.ILineSeries;

import org.swtchart.ISeries.SeriesType;
import org.eclipse.swt.SWT;


import com.ibm.icu.impl.DateNumberFormat;

public class CheckChart extends Composite {

	private Shell shell;
	private Display display;
	private static final int MARGIN = 30;

	   private static final double[] ySeries = { 0.0, 0.38, 0.71, 0.92, 1.0, 0.92,
           0.71, 0.38, 0.0, -0.38, -0.71, -0.92, -1.0, -0.92, -0.71, -0.38 };


	public CheckChart(Composite parent, int style) {
		super(parent, style);
		shell = parent.getShell();
		display = parent.getDisplay();
		// chart.setBounds(0, 0, 482, 353);

        Chart chart = new Chart(this, SWT.NONE);
        chart.setBounds(0, 0, 482, 353);
        chart.getTitle().setText("员工签到记录");

        // get Y axis
        final IAxis yAxis = chart.getAxisSet().getYAxis(0);

        // create line series
        ILineSeries series = (ILineSeries) chart.getSeriesSet().createSeries(
                SeriesType.LINE, "line series");
        series.setYSeries(ySeries);

        // adjust the axis range
        chart.getAxisSet().adjustRange();

        // add paint listener to draw threshold
        chart.getPlotArea().addPaintListener(new PaintListener() {
            public void paintControl(PaintEvent e) {
                int y = yAxis.getPixelCoordinate(0.65);
                e.gc.drawLine(0, y, e.width, y);
                e.gc.drawText("y=0.65", MARGIN, y + MARGIN);
            }
        });

		

	}

	    @Override
		protected void checkSubclass() {
			// Disable the check that prevents subclassing of SWT components
		}

}
