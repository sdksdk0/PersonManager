package cn.pm.chart;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.experimental.chart.swt.ChartComposite;
import org.jfree.ui.RefineryUtilities;

import cn.pm.dao.DBHelper;
import cn.pm.ui.IncomeAccount;

import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;

public class showBar {

	protected Shell shell;
	private static Table table;
	private static DBHelper db;
	// private static DefaultCategoryDataset dataset;
	private JFreeChart chart;
	private Composite composite_3;
	private SashForm sashForm;
	public int summoney=0,sum1=0,sum2=0;
	public static Combo combo;
	public static Combo combo_1;

	// private static Table table_1;
	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			showBar window = new showBar();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setText("部门总薪资图");
		shell.setSize(952, 133);

		ChartFactory
				.setChartTheme(new StandardChartTheme("JFree/Shadow", true));

		shell.setLayout(new FillLayout(SWT.HORIZONTAL));

		Composite composite = new Composite(shell, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(composite, SWT.VERTICAL);

		Composite composite_1 = new Composite(sashForm, SWT.NONE);

		Button button = new Button(composite_1, SWT.NONE);

		button.setBounds(649, 40, 80, 27);
		button.setText("查询");

		Label label = new Label(composite_1, SWT.NONE);
		label.setBounds(338, 40, 48, 20);
		label.setText("月：");

		Label label_1 = new Label(composite_1, SWT.NONE);
		label_1.setBounds(88, 40, 48, 20);
		label_1.setText("年：");
		
		 combo = new Combo(composite_1, SWT.NONE);
		combo.setItems(new String[] {"全部", "2016", "2015", "2014", "2013"});
		combo.select(0);
		combo.setBounds(142, 40, 92, 28);
		
		 combo_1 = new Combo(composite_1, SWT.READ_ONLY);
		combo_1.setItems(new String[] {"全部", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"});
		combo_1.select(0);
		combo_1.setBounds(392, 40, 92, 28);

		//查询图表功能
				button.addSelectionListener(new SelectionAdapter() {
					@Override
					public void widgetSelected(SelectionEvent e) {
						showBar3.main("员工薪资");
				}

			});
	
	}
}  