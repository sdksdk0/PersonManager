package cn.pm.biz;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import cn.pm.dao.DBHelper;

public class FileBiz {
	 DBHelper db = new DBHelper();

	@SuppressWarnings("resource")
	public int saveEMP(String eid, String ename, String did, String jid,
			String status, String sex, String tel, String address,
			String birthday, String photopath,String email) throws Exception {
		

		String sql1 = "insert into emp values(seq_emp_eid.nextval,?,?,?,'0cc175b9c0f1b6a831c399e269772661',?,?,?,?,to_date(?,'yyyy-MM-dd'),empty_blob(),? )";
		String sql2 = "select photo from emp where eid=? for update";
			
		// 只能用原生的jdbc操作
		Connection con = db.getConnection();
		PreparedStatement pstmt =null;
		ResultSet rs =null;
		try {
			con.setAutoCommit(false);

			pstmt = con.prepareStatement(sql1);
			pstmt.setString(1, ename);
			pstmt.setString(2, did);
			pstmt.setString(3, jid);
			pstmt.setString(4, status);
			pstmt.setString(5, sex);
			pstmt.setString(6, tel);
			pstmt.setString(7, address);
			pstmt.setString(8, birthday);
			pstmt.setString(9,email);

			pstmt.executeUpdate();

			if (photopath != null && !"".equals(photopath)) {

				pstmt = con.prepareStatement(sql2);
				pstmt.setString(1, eid + "");
				rs = pstmt.executeQuery();

				if (rs != null && rs.next()) {
					OutputStream oos = null; // 向数据库中输入图片
					InputStream iis = null; // 从本地读取文件

					oracle.sql.BLOB b = (oracle.sql.BLOB) rs.getBlob(1);
					oos = b.getBinaryOutputStream();

					iis = new BufferedInputStream(new FileInputStream(new File(
							photopath)));
					byte[] bs = new byte[1024];
					int length = -1;
					while ((length = iis.read(bs, 0, bs.length)) != -1) {
						oos.write(bs, 0, length);
						oos.flush();
					}
				}

			}
			con.commit();
			return 1;

		}catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				con.setAutoCommit(true);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			db.close();
		}
		return 0;
	}

	@SuppressWarnings("resource")
	public int updateEMP(String eid, String ename, String did, String jid,
			String status, String sex, String tel, String address,
			String birthday, String photopath, String email) throws Exception {

		Connection con = db.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "update emp set name=?,did=?,jid=?,status=? ,sex=?,tel=?,address=?,birthday=to_date(?,'yyyy-MM-dd'),email=?  where eid=?";
			String sql2 = "select photo  from emp where eid=? for update";
			con.setAutoCommit(false);

			 pstmt = con.prepareStatement(sql);
			pstmt.setString(1, ename);
			pstmt.setString(2, did);
			pstmt.setString(3, jid);
			pstmt.setString(4, status);
			pstmt.setString(5, sex);
			pstmt.setString(6, tel);
			pstmt.setString(7, address);
			pstmt.setString(8, birthday);
			pstmt.setString(9, email);
			pstmt.setString(10, eid);
			

			pstmt.executeUpdate();

			if (photopath != null && !"".equals(photopath)) {

				pstmt = con.prepareStatement(sql2);
				pstmt.setString(1, eid + "");
				rs = pstmt.executeQuery();

				if (rs != null && rs.next()) {
					OutputStream oos = null; // 向数据库中输入图片
					InputStream iis = null; // 从本地读取文件

					oracle.sql.BLOB b = (oracle.sql.BLOB) rs.getBlob(1);
					oos = b.getBinaryOutputStream();

					iis = new BufferedInputStream(new FileInputStream(new File(
							photopath)));
					byte[] bs = new byte[1024];
					int length = -1;
					while ((length = iis.read(bs, 0, bs.length)) != -1) {
						oos.write(bs, 0, length);
						oos.flush();
					}
				}

			}
			con.commit();
			return 1;

		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.setAutoCommit(true);
					//con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				db.close();
			}
		}
		return 0;
	}

	public ImageData findPic(String eid) {

		Connection con = null;

		String sql = " select photo from emp where eid=? ";
		ImageData imageData = null;

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = db.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, eid);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				oracle.sql.BLOB b = (oracle.sql.BLOB) rs.getBlob(1);
				try {
					InputStream iis = b.getBinaryStream();
					imageData = new ImageData(iis);
				} catch (Exception e) {
				}

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return imageData;
	}
}