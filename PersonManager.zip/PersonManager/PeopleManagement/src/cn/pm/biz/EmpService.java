package cn.pm.biz;

import java.io.File;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.widgets.TableItem;

import jxl.Sheet;
import jxl.Workbook;
import cn.pm.bean.EmpEntry;
import cn.pm.dao.DBHelper;
import cn.pm.utils.LayoutUtil;

public class EmpService {
	static DBHelper db = new DBHelper();

	public static List<EmpEntry> getAllByDb() {
		List<EmpEntry> list = new ArrayList<EmpEntry>();

		String sql = " select e.eid,e.name as ename ,d.name as dname ,j.name as jname, status,sex,tel,address,birthday,email   "
				+ " from emp e left join dept d on e.did=d.did   left join job j on e.jid=j.jid  ";

		List<Map<String, Object>> listmap = db.find(sql, null);

		if (listmap != null && listmap.size() > 0) {
			for (Map<String, Object> map : listmap) {
				String eid = (String) map.get("EID");
				String ename = (String) map.get("ENAME");
				String dname = (String) map.get("DNAME");
				String jname = (String) map.get("JNAME");
				String status = (String) map.get("STATUS");
				String sex = (String) map.get("SEX");
				String tel = (String) map.get("TEL");
				String address = (String) map.get("ADDRESS");
				String birthday = (String) map.get("BIRTHDAY");
				String email = (String) map.get("EMAIL");

				list.add(new EmpEntry(eid, ename, dname, jname, status, sex,
						tel, address, birthday, email));
			}

		}
		return list;
	}

	/**
	 * 查询指定目录中电子表格中所有的数据
	 * 
	 * @param file
	 *            文件完整路径
	 * @return
	 */
	public static List<EmpEntry> getAllByExcel(String file) {
		List<EmpEntry> list = new ArrayList<EmpEntry>();
		try {
			Workbook rwb = Workbook.getWorkbook(new File(file));
			Sheet rs = rwb.getSheet("Test Shee 1");// 或者rwb.getSheet(0)
			int clos = rs.getColumns();// 得到所有的列
			int rows = rs.getRows();// 得到所有的行

			System.out.println(clos + " rows:" + rows);
			for (int i = 1; i < rows; i++) {
				for (int j = 0; j < clos; j++) {
					// 第一个是列数，第二个是行数
					String eid = rs.getCell(j++, i).getContents();// 默认最左边编号也算一列
																	// 所以这里得j++
					String ename = rs.getCell(j++, i).getContents();
					String dname = rs.getCell(j++, i).getContents();
					String jname = rs.getCell(j++, i).getContents();
					String status = rs.getCell(j++, i).getContents();
					String sex = rs.getCell(j++, i).getContents();
					String tel = rs.getCell(j++, i).getContents();
					String address = rs.getCell(j++, i).getContents();
					String birthday = rs.getCell(j++, i).getContents();
					String email = rs.getCell(j++, i).getContents();

					list.add(new EmpEntry(eid, ename, dname, jname, status,
							sex, tel, address, birthday, email));
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;

	}

	/**
	 * 通过Id判断是否存在
	 * 
	 * @param eid
	 * @return
	 */
	public static boolean isExist(String eid) {
		Connection con = null;

		String sql = " select * from emp ";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = db.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public static void main(String[] args) {
		/*
		 * List<EmpEntry> all=getAllByDb(); for (EmpEntry stuEntity : all) {
		 * System.out.println(stuEntity.toString()); }
		 * 
		 * System.out.println(isExist(1));
		 */

	}
	// 增删修改
    public int AddU(String sql, String str[]) {
        int a = 0;
       Connection con=db.getConnection();
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            if (str != null) {
                for (int i = 0; i < str.length; i++) {
                    pst.setString(i + 1, str[i]);
                }
            }
            a = pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return a;
    }




}
