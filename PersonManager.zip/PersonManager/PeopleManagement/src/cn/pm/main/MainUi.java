package cn.pm.main;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.wb.swt.SWTResourceManager;

import cn.pm.chat.client.Chat;
import cn.pm.chat.client.OutIn;
import cn.pm.chat.server.ServerStart;
import cn.pm.dao.DBHelper;
import cn.pm.ui.AdjustSalary;
import cn.pm.ui.BasicManagement;
import cn.pm.ui.CheckManagement;
import cn.pm.ui.DepartmentManagement;
import cn.pm.ui.FileManagement;
import cn.pm.ui.IncomeAccount;
import cn.pm.ui.LeaveManagement;
import cn.pm.ui.NoticeManagement;
import cn.pm.ui.PostManagement;
import cn.pm.ui.DefaultIndex;
import cn.pm.ui.RPManagement;
import cn.pm.ui.SalayManagement;
import cn.pm.ui.ScoreManagement;
import cn.pm.ui.TrainManagemant;
import cn.pm.ui.TreatmentManagement;
import cn.pm.ui.TraineeManagement;
import cn.pm.utils.Common;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;





public class MainUi {

	public Shell shell;
	private Tree tree;
	private boolean flag = true;

	private RPManagement rpm; // 奖惩管理
	private SalayManagement slm; // 薪资报表
	private ScoreManagement scm; // 业绩评分
	private FileManagement flm; // 档案管理
	private DefaultIndex di; // 默认首页
	private TrainManagemant tam; // 培训管理
	private TreatmentManagement ttm; // 待遇管理：
	private CheckManagement cm;// 考勤报表：
	private LeaveManagement lm; // 请假申请批复：
	private BasicManagement bm;// 基本工资管理：
	private PostManagement pm; // 职务管理
	private DepartmentManagement dm; // 部门管理：
	private TraineeManagement tem; // 招聘管理：

	private NoticeManagement nm;// 发布公告：
	private AdjustSalary as;
	


	private Label label_2;
	private SimpleDateFormat sdf;
	private Date d;
	public static Label label_4;
	private Label lblNewLabel;
	
	
	
	private OutIn in;	
	private DataInputStream  din;
	private DataOutputStream dout;
	private String sex;
	private String localhost;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			MainUi window = new MainUi();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setImage(SWTResourceManager.getImage(MainUi.class, "/image/2.jpg"));
	

		shell.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent arg0) {
				flag = false;
				System.exit(0);
			}
		});

		shell.setBackground(SWTResourceManager.getColor(240, 248, 255));
		shell.setSize(1897, 1060);
		// 窗口最大化
		LayoutUtil.maxShell(shell.getDisplay(), shell);

		shell.setText("人事管理系统");
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(shell, SWT.VERTICAL);

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setBackgroundMode(SWT.INHERIT_FORCE);
		
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_2 = new SashForm(composite, SWT.VERTICAL);
		

		Composite composite_4 = new Composite(sashForm_2, SWT.NONE);
		composite_4.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_3 = new SashForm(composite_4, SWT.NONE);

		Composite composite_6 = new Composite(sashForm_3, SWT.NONE);
		composite_6.setBackgroundMode(SWT.INHERIT_FORCE);
		
		composite_6.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_4 = new SashForm(composite_6, SWT.VERTICAL);

		Composite composite_7 = new Composite(sashForm_4, SWT.NONE);
		composite_7.setLayout(null);

		Label label_1 = new Label(composite_7, SWT.NONE);
		label_1.setBounds(0, 0, 73, 29);
		label_1.setAlignment(SWT.RIGHT);
		label_1.setText("欢迎您：");

		label_2 = new Label(composite_7, SWT.NONE);
		label_2.setBounds(552, 0, 286, 21);
		label_2.setText("现在是：");

		Label label_3 = new Label(composite_7, SWT.NONE);
		label_3.setBounds(247, 0, 95, 21);
		label_3.setText("您的职务是：");

		Label lblNewLabel_1 = new Label(composite_7, SWT.NONE);
		lblNewLabel_1.setBounds(370, 0, 149, 29);
		lblNewLabel_1.setText(Login.combo.getText());

		lblNewLabel = new Label(composite_7, SWT.NONE);
		lblNewLabel.setLocation(79, 0);
		lblNewLabel.setSize(81, 20);
		lblNewLabel.setText(Login.text.getText());

		Button button = new Button(composite_7, SWT.NONE);

		button.setBounds(1771, -1, 98, 30);
		button.setText("退出系统");

		Composite composite_8 = new Composite(sashForm_4, SWT.NONE);

		Label label = new Label(composite_8, SWT.NONE);
		label.setBounds(10, 10, 45, 20);
		label.setText("公告：");

		label_4 = new Label(composite_8, SWT.NONE);
		label_4.setBounds(75, 10, 642, 24);
		sashForm_4.setWeights(new int[] {34, 36});

		sashForm_3.setWeights(new int[] { 1 });

		Composite composite_5 = new Composite(sashForm_2, SWT.BORDER);
		composite_5.setFont(SWTResourceManager.getFont("Microsoft YaHei UI",
				19, SWT.NORMAL));
		composite_5.setBackground(SWTResourceManager.getColor(240, 248, 255));
		composite_5.setLayout(new FillLayout(SWT.HORIZONTAL));

		Group group = new Group(composite_5, SWT.NONE);
		
		group.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		
		group.setLayout(null);
		
		Label label_5 = new Label(group, SWT.NONE);
		
		label_5.setBackgroundImage(SWTResourceManager.getImage(MainUi.class, "/image/1463027031.png"));
		label_5.setBounds(3, 0, 148, 149);

		Label lblRio = new Label(group, SWT.NONE);
		lblRio.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION));
		lblRio.setBounds(650, 27, 530, 50);
		lblRio.setFont(SWTResourceManager.getFont("华文行楷", 28, SWT.NORMAL));
		lblRio.setAlignment(SWT.CENTER);
		lblRio.setText("RIO人事管理系统");
		
		Label label_6 = new Label(group, SWT.NONE);

		label_6.setAlignment(SWT.CENTER);
		label_6.setBackgroundImage(SWTResourceManager.getImage(MainUi.class, "/image/e2.png"));
		label_6.setBounds(1705, 0, 160, 130);
		
		Label label_7 = new Label(group, SWT.NONE);
	
		label_7.setBackgroundImage(SWTResourceManager.getImage(MainUi.class, "/image/a1.jpg"));
		label_7.setBounds(157, 0, 178, 149);
		sashForm_2.setWeights(new int[] {66, 135});

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_1 = new SashForm(composite_1, SWT.NONE);

		Composite composite_2 = new Composite(sashForm_1, SWT.NONE);
		composite_2.setBackgroundMode(SWT.INHERIT_FORCE);
		
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));

		tree = new Tree(composite_2, SWT.BORDER | SWT.FULL_SELECTION);
		tree.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION));
		tree.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 14, SWT.NORMAL));
		tree.setLinesVisible(true);

		TreeItem treeItem7 = new TreeItem(tree, SWT.NONE);
		treeItem7.setFont(SWTResourceManager.getFont("华文隶书", 15, SWT.NORMAL));
		treeItem7.setText("首页");
		TreeItem treeItem = new TreeItem(tree, SWT.NONE);
		treeItem.setFont(SWTResourceManager.getFont("华文隶书", 15, SWT.NORMAL));
		treeItem.setText("员工管理");

		TreeItem treeItem_6 = new TreeItem(treeItem, SWT.NONE);
		treeItem_6.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_6.setText("档案管理");

		TreeItem treeItem_7 = new TreeItem(treeItem, SWT.NONE);
		treeItem_7.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_7.setText("奖惩管理");

		TreeItem treeItem_8 = new TreeItem(treeItem, SWT.NONE);
		treeItem_8.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_8.setText("培训管理");

		TreeItem treeItem_17 = new TreeItem(treeItem, 0);
		treeItem_17.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_17.setText("招聘管理");
		treeItem.setExpanded(true);

		TreeItem treeItem_2 = new TreeItem(tree, SWT.NONE);
		treeItem_2.setFont(SWTResourceManager.getFont("华文隶书", 15, SWT.NORMAL));
		treeItem_2.setText("考勤管理");

		TreeItem treeItem_9 = new TreeItem(treeItem_2, SWT.NONE);
		treeItem_9.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_9.setText("超级标签");

		TreeItem treeItem_10 = new TreeItem(treeItem_2, SWT.NONE);
		treeItem_10.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_10.setText("请假申请批复");

		TreeItem treeItem_11 = new TreeItem(treeItem_2, SWT.NONE);
		treeItem_11.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_11.setText("业绩评分");
		treeItem_2.setExpanded(true);

		TreeItem treeItem_1 = new TreeItem(tree, SWT.NONE);
		treeItem_1.setFont(SWTResourceManager.getFont("华文隶书", 15, SWT.NORMAL));
		treeItem_1.setText("薪资管理");

		TreeItem treeItem_12 = new TreeItem(treeItem_1, SWT.NONE);
		treeItem_12.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_12.setText("基本工资管理");

		TreeItem treeItem_13 = new TreeItem(treeItem_1, SWT.NONE);
		treeItem_13.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_13.setText("待遇管理");

		TreeItem treeItem_14 = new TreeItem(treeItem_1, SWT.NONE);
		treeItem_14.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_14.setText("薪资报表");
		treeItem_1.setExpanded(true);

		TreeItem treeItem_3 = new TreeItem(tree, SWT.NONE);
		treeItem_3.setFont(SWTResourceManager.getFont("华文隶书", 15, SWT.NORMAL));
		treeItem_3.setText("部门管理");

		TreeItem treeItem_15 = new TreeItem(treeItem_3, SWT.NONE);
		treeItem_15.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_15.setText("职务管理");

		TreeItem treeItem_16 = new TreeItem(treeItem_3, SWT.NONE);
		treeItem_16.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_16.setText("部门管理");
		
		TreeItem treeItem_5 = new TreeItem(treeItem_3, SWT.NONE);
		treeItem_5.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_5.setText("人事调动");
		treeItem_3.setExpanded(true);

		TreeItem treeItem_4 = new TreeItem(tree, SWT.NONE);
		treeItem_4.setFont(SWTResourceManager.getFont("华文隶书", 15, SWT.NORMAL));
		treeItem_4.setText("系统设置");

		TreeItem treeItem_19 = new TreeItem(treeItem_4, SWT.NONE);
		treeItem_19.setFont(SWTResourceManager.getFont("Microsoft YaHei UI", 12, SWT.NORMAL));
		treeItem_19.setText("发布公告");
		treeItem_4.setExpanded(true);

		Composite composite_3 = new Composite(sashForm_1, SWT.NONE);

		StackLayout sl = new StackLayout();

		di = new DefaultIndex(composite_3, SWT.None);
		flm = new FileManagement(composite_3, SWT.None);
		rpm = new RPManagement(composite_3, SWT.None);
		tam = new TrainManagemant(composite_3, SWT.None);
		cm = new CheckManagement(composite_3, SWT.None);
		lm = new LeaveManagement(composite_3, SWT.None);
		scm = new ScoreManagement(composite_3, SWT.None);
		slm = new SalayManagement(composite_3, SWT.None);
		bm = new BasicManagement(composite_3, SWT.None);
		ttm = new TreatmentManagement(composite_3, SWT.None);
		pm = new PostManagement(composite_3, SWT.None);
		dm = new DepartmentManagement(composite_3, SWT.None);
		tem = new TraineeManagement(composite_3, SWT.None);
		nm = new NoticeManagement(composite_3, SWT.None);
		as=new AdjustSalary(composite_3, SWT.None);

		composite_3.setLayout(sl);
		sl.topControl = di;
		sashForm_1.setWeights(new int[] { 148, 550 });


		
		initNotify();
		Common.bm = bm;
		Common.fm = flm;
		Common.rpm = rpm;
		Common.scm = scm;
		Common.tm = tam;
		Common.ttm = ttm;
		Common.cm=cm;
		Common.as=as;
		
		sashForm.setWeights(new int[] {227, 783});

		
		label_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
			
			    new ServerStart();
			}
		});
		//开启服务器
		label_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				new ServerStart();
			
			}
		});
		
		//聊天
		label_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {	
				String eid=lblNewLabel.getText().trim();
				
				String sql=" select name from emp where eid='"+eid+"'";
				DBHelper db = new DBHelper();
				String ename=null;
				List<Map<String, Object>> list = db.find(sql, null);
				if(list!=null && !"".equals(list)){
					for (Map<String, Object> map : list) {
						ename=(String) map.get("NAME");
					}
					
				}
				in = new OutIn(localhost,9999);
				dout = in.getOutStream();
				din = in.getInstream();
					try {
						dout.writeUTF("login,"+ename);

						String s1 = din.readUTF(); 
						if(s1.equals("成功登录")) {
							Chat chat=new Chat(ename, dout, din);
						}
					} catch (IOException e1) {
						e1.printStackTrace();
						
					}
			}
		});
		// 退出系统
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (MessageDialog.openQuestion(shell, "退出系统", "您确定要退出么!") == true) {
					System.exit(0);
				}
			}
		});

		// 切换面板
		tree.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TreeItem[] tis = tree.getSelection();
				if (tis == null || tis.length <= 0) {
					return;
				}
				TreeItem ti = tis[0];
				String choice = ti.getText();
				if ("首页".equals(choice)) {
					sl.topControl = di;
				} else if ("档案管理".equals(choice)) {
					sl.topControl = flm;
				} else if ("奖惩管理".equals(choice)) {
					sl.topControl = rpm;
				} else if ("培训管理".equals(choice)) {
					sl.topControl = tam;
				} else if ("超级标签".equals(choice)) {
					sl.topControl = cm;
				} else if ("请假申请批复".equals(choice)) {
					sl.topControl = lm;
				} else if ("业绩评分".equals(choice)) {
					sl.topControl = scm;
				} else if ("基本工资管理".equals(choice)) {
					sl.topControl = bm;
				} else if ("待遇管理".equals(choice)) {
					sl.topControl = ttm;
				} else if ("薪资报表".equals(choice)) {
					sl.topControl = slm;
				} else if ("职务管理".equals(choice)) {
					String jd = lblNewLabel_1.getText().toString().trim();
					if (jd.equals("人事部_经理")) {
						sl.topControl = pm;
					} else {
						MessageDialog.openError(shell, "无权限",
								"很抱歉，你没有权限操作，请联系系统管理员!");
					}
				} else if ("部门管理".equals(choice)) {
					String jd = lblNewLabel_1.getText().toString().trim();
					if (jd.equals("人事部_经理")) {
						sl.topControl = dm;
					} else {
						MessageDialog.openError(shell, "无权限",
								"很抱歉，你没有权限操作，请联系系统管理员!");
					}
				} else if ("招聘管理".equals(choice)) {
					sl.topControl = tem;
				} else if ("发布公告".equals(choice)) {
					String jd = lblNewLabel_1.getText().toString().trim();
					if (jd.equals("人事部_经理")) {
						sl.topControl = nm;
					} else {
						MessageDialog.openError(shell, "无权限",
								"很抱歉，你没有权限操作，请联系系统管理员!");
					}
				}else if ("人事调动".equals(choice)) {
					String jd = lblNewLabel_1.getText().toString().trim();
					if (jd.equals("人事部_经理")) {
						sl.topControl = as;
					} else {
						MessageDialog.openError(shell, "无权限",
								"很抱歉，你没有权限操作，请联系系统管理员!");
					}
				
				} 
				composite_3.layout();

			}
		});

		// 时间线程
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (flag) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					sdf = new SimpleDateFormat("yyyy年MM月dd日  HH:mm:ss");
					if (flag) {
						Display.getDefault().asyncExec(new Runnable() {
							public void run() {
								label_2.setText(sdf.format(new Date()));
							}
						});
					}
				}
			}
		}).start();
	}



	public void initNotify() {

		String sql = "select content from (select * from notify order by time desc) where rownum=1";

		DBHelper db = new DBHelper();
		List<Map<String, Object>> list = db.find(sql, null);
		if (list != null && list.size() > 0) {
			label_4.setText("");
			for (Map<String, Object> map : list) {
				String content = (String) map.get("CONTENT");
				label_4.setText(content);
			}
		}
	}
}
