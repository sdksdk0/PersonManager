package cn.pm.main;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeItem;
import org.eclipse.wb.swt.SWTResourceManager;

import cn.pm.chat.client.Chat;
import cn.pm.chat.client.OutIn;
import cn.pm.chat.server.ServerStart;
import cn.pm.dao.DBHelper;
import cn.pm.ui.DefaultIndex;
import cn.pm.uiUser.Application;
import cn.pm.uiUser.Check;
import cn.pm.uiUser.Finds;
import cn.pm.uiUser.UserSet;
import cn.pm.utils.LayoutUtil;

import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.events.DisposeEvent;

public class MainUiUser {

	protected Shell shell;
	private Tree tree;
	private boolean flag = true;
	private DefaultIndex di; // 默认首页
	private Application al; // 请假申请
	private Check ck; // 考勤
	private Finds fs; // 综合查询
	private UserSet us; // 用户设置

	private Label label_2;
	private SimpleDateFormat sdf;
	private Date d;
	public static Label label_4;

	private OutIn in;
	private DataInputStream din;
	private DataOutputStream dout;
	private String sex;
	private String localhost;

	/**
	 * Launch the application.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			MainUiUser window = new MainUiUser();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setImage(SWTResourceManager.getImage(MainUiUser.class,
				"/image/2.jpg"));
		shell.addDisposeListener(new DisposeListener() {
			public void widgetDisposed(DisposeEvent arg0) {
				System.exit(0);
			}
		});
		shell.setBackground(SWTResourceManager.getColor(240, 248, 255));
		shell.setSize(1897, 1060);
		// 窗口最大化
		LayoutUtil.maxShell(shell.getDisplay(), shell);

		shell.setText("人事管理系统");
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm = new SashForm(shell, SWT.VERTICAL);

		Composite composite = new Composite(sashForm, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_2 = new SashForm(composite, SWT.VERTICAL);

		Composite composite_4 = new Composite(sashForm_2, SWT.NONE);
		composite_4.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite_4.setBackgroundMode(SWT.INHERIT_DEFAULT);
		composite_4.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_3 = new SashForm(composite_4, SWT.NONE);

		Composite composite_6 = new Composite(sashForm_3, SWT.NONE);
		composite_6.setBackgroundMode(SWT.INHERIT_FORCE);

		composite_6.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_4 = new SashForm(composite_6, SWT.VERTICAL);

		Composite composite_7 = new Composite(sashForm_4, SWT.NONE);
		composite_7.setLayout(null);

		Label label_1 = new Label(composite_7, SWT.NONE);
		label_1.setBounds(0, 0, 73, 29);
		label_1.setAlignment(SWT.RIGHT);
		label_1.setText("欢迎您：");

		label_2 = new Label(composite_7, SWT.NONE);
		label_2.setBounds(476, 0, 218, 21);
		label_2.setText("现在是：");

		Label label_3 = new Label(composite_7, SWT.NONE);
		label_3.setBounds(210, 0, 95, 21);
		label_3.setText("您的职务是：");

		Label lblNewLabel_1 = new Label(composite_7, SWT.NONE);
		lblNewLabel_1.setBounds(311, 0, 116, 29);
		lblNewLabel_1.setText(Login.combo.getText());

		Label lblNewLabel = new Label(composite_7, SWT.NONE);
		lblNewLabel.setLocation(92, 0);
		lblNewLabel.setSize(81, 20);
		lblNewLabel.setText(Login.text.getText());

		Button button = new Button(composite_7, SWT.NONE);

		button.setBounds(1757, 8, 98, 21);
		button.setText("退出系统");

		Composite composite_8 = new Composite(sashForm_4, SWT.NONE);

		Label label = new Label(composite_8, SWT.NONE);
		label.setBounds(10, 10, 45, 20);
		label.setText("公告：");

		label_4 = new Label(composite_8, SWT.NONE);
		label_4.setBounds(75, 10, 642, 24);
		sashForm_4.setWeights(new int[] { 37, 33 });

		sashForm_3.setWeights(new int[] { 1 });

		Composite composite_5 = new Composite(sashForm_2, SWT.BORDER);
		composite_5.setFont(SWTResourceManager.getFont("Microsoft YaHei UI",
				19, SWT.NORMAL));
		composite_5.setBackground(SWTResourceManager.getColor(240, 248, 255));
		composite_5.setLayout(null);

		Label label_5 = new Label(composite_5, SWT.NONE);
		label_5.setBounds(0, 0, 145, 154);
		label_5.setBackgroundImage(SWTResourceManager.getImage(
				MainUiUser.class, "/image/1463027031.png"));

		Label lblRio = new Label(composite_5, SWT.NONE);
		lblRio.setBounds(590, 37, 614, 51);
		lblRio.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_CYAN));
		lblRio.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));

		lblRio.setFont(SWTResourceManager.getFont("华文行楷", 29, SWT.BOLD));
		lblRio.setAlignment(SWT.CENTER);
		lblRio.setText("RIO人事管理系统");

		Label label_6 = new Label(composite_5, SWT.NONE);

		label_6.setBackgroundImage(SWTResourceManager.getImage(
				MainUiUser.class, "/image/e2.png"));
		label_6.setBounds(1666, 0, 199, 154);

		Label label_7 = new Label(composite_5, SWT.NONE);
		label_7.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		label_7.setImage(SWTResourceManager.getImage(MainUiUser.class,
				"/image/a1.jpg"));
		label_7.setBounds(151, 0, 190, 144);
		sashForm_2.setWeights(new int[] { 73, 158 });

		Composite composite_1 = new Composite(sashForm, SWT.NONE);
		composite_1.setLayout(new FillLayout(SWT.HORIZONTAL));

		SashForm sashForm_1 = new SashForm(composite_1, SWT.NONE);

		Composite composite_2 = new Composite(sashForm_1, SWT.NONE);
		composite_2.setLayout(new FillLayout(SWT.HORIZONTAL));

		tree = new Tree(composite_2, SWT.BORDER);
		tree.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_CYAN));
		tree.setBackground(SWTResourceManager
				.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		tree.setToolTipText("");
		tree.setFont(SWTResourceManager.getFont("华文行楷", 17, SWT.NORMAL));
		tree.setLinesVisible(true);

		TreeItem treeItem7 = new TreeItem(tree, SWT.NONE);
		treeItem7.setText("首页");
		TreeItem treeItem = new TreeItem(tree, SWT.NONE);
		treeItem.setText("签到");
		treeItem.setExpanded(true);

		TreeItem treeItem_2 = new TreeItem(tree, SWT.NONE);
		treeItem_2.setText("请假申请");
		treeItem_2.setExpanded(true);

		TreeItem treeItem_1 = new TreeItem(tree, SWT.NONE);
		treeItem_1.setText("综合查询");
		treeItem_1.setExpanded(true);

		TreeItem treeItem_3 = new TreeItem(tree, SWT.NONE);
		treeItem_3.setText("用户设置");
		treeItem_3.setExpanded(true);

		Composite composite_3 = new Composite(sashForm_1, SWT.NONE);

		StackLayout sl = new StackLayout();

		di = new DefaultIndex(composite_3, SWT.None);
		di.setForeground(SWTResourceManager
				.getColor(SWT.COLOR_LIST_SELECTION_TEXT));
		ck = new Check(composite_3, SWT.None);
		al = new Application(composite_3, SWT.None);
		fs = new Finds(composite_3, SWT.None);
		us = new UserSet(composite_3, SWT.None);

		composite_3.setLayout(sl);
		sl.topControl = di;

		sashForm_1.setWeights(new int[] { 148, 550 });
		sashForm.setWeights(new int[] { 234, 776 });

		initNotify();
		
		
		label_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				new ServerStart();
			
			}
		});

		label_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				new ServerStart();
			}
		});

		// 聊天
		label_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
				String eid = lblNewLabel.getText().trim();

				String sql = " select name from emp where eid='" + eid + "'";
				DBHelper db = new DBHelper();
				String ename = null;
				List<Map<String, Object>> list = db.find(sql, null);
				if (list != null && !"".equals(list)) {
					for (Map<String, Object> map : list) {
						ename = (String) map.get("NAME");
					}
				}

				in = new OutIn(localhost, 9999);
				dout = in.getOutStream();
				din = in.getInstream();
				try {
					dout.writeUTF("login," + ename);

					String s1 = din.readUTF();
					if (s1.equals("成功登录")) {
						Chat chat = new Chat(ename, dout, din);
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				
				}
			}
		});

		// 退出系统
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (MessageDialog.openQuestion(shell, "退出系统", "您确定要退出么!") == true) {
					System.exit(0);
				}
			}
		});

		// 切换面板
		tree.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				TreeItem[] tis = tree.getSelection();
				if (tis == null || tis.length <= 0) {
					return;
				}
				TreeItem ti = tis[0];
				String choice = ti.getText();
				if ("首页".equals(choice)) {
					sl.topControl = di;
				} else if ("签到".equals(choice)) {
					sl.topControl = ck;
				} else if ("请假申请".equals(choice)) {
					sl.topControl = al;
				} else if ("综合查询".equals(choice)) {
					sl.topControl = fs;
				} else if ("用户设置".equals(choice)) {
					sl.topControl = us;
				}
				composite_3.layout();

			}
		});

		// 时间线程
		new Thread(new Runnable() {
			@Override
			public void run() {
				while (flag) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					sdf = new SimpleDateFormat("yyyy年MM月dd日  HH:mm:ss");
					if (flag) {
						Display.getDefault().asyncExec(new Runnable() {
							public void run() {
								label_2.setText(sdf.format(new Date()));
							}
						});
					}
				}
			}
		}).start();
	}

	public void initNotify() {

		String sql = "select content from (select * from notify order by time desc) where rownum=1";

		DBHelper db = new DBHelper();
		List<Map<String, Object>> list = db.find(sql, null);
		if (list != null && list.size() > 0) {
			label_4.setText("");
			for (Map<String, Object> map : list) {
				String content = (String) map.get("CONTENT");
				label_4.setText(content);
			}
		}
	}
}
