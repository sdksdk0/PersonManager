package cn.pm.main;

import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.prefs.BackingStoreException;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Combo;

import cn.pm.bean.Admin;
import cn.pm.dao.DBHelper;
import cn.pm.utils.Common;
import cn.pm.utils.DataDictory;
import cn.pm.utils.LayoutUtil;
import cn.pm.utils.MD5;
import cn.pm.utils.RegistrationUtils;

import org.eclipse.swt.widgets.Group;
import org.eclipse.wb.swt.SWTResourceManager;

import sun.misc.Perf.GetPerfAction;

public class Login {

	private Shell shell = null; // 用于保存按钮的形状,有助于侦听单击按钮事件
	public static Text text;
	private Text text_1;
	private Button c;
	DBHelper db = new DBHelper();
	public static Combo combo;

	public static void main(String[] args) {
		try {
			Login window = new Login();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	protected void createContents() {
		shell = new Shell();
		shell.setImage(SWTResourceManager.getImage(Login.class, "/image/2.jpg"));
		shell.setBackgroundMode(SWT.INHERIT_FORCE);
		shell.setBackgroundImage(SWTResourceManager.getImage(Login.class, "/image/c1.jpg"));
		shell.setSize(526, 394);
		// 窗口居中显示
		LayoutUtil.centerShell(shell.getDisplay(), shell);

		shell.setText("人事管理系统");

		Label label = new Label(shell, SWT.NONE);
		label.setBounds(81, 108, 67, 17);
		label.setText("员 工 号：");

		text = new Text(shell, SWT.BORDER);
		text.setBounds(191, 105, 155, 23);

		Label label_1 = new Label(shell, SWT.NONE);
		label_1.setBounds(81, 150, 59, 17);
		label_1.setText("密     码：");

		text_1 = new Text(shell, SWT.BORDER | SWT.PASSWORD);
		text_1.setBounds(191, 147, 155, 23);

		Label lblRilo = new Label(shell, SWT.NONE);
		lblRilo.setForeground(SWTResourceManager.getColor(SWT.COLOR_LIST_SELECTION));
		lblRilo.setAlignment(SWT.CENTER);
		lblRilo.setFont(SWTResourceManager.getFont("Segoe Script", 20,
				SWT.NORMAL));
		// label_2.setFont(SWTResourceManager.getFont("微软雅黑", 14, SWT.NORMAL));
		// label_2.setFont(SWTResourceManager.getFont("微软雅黑", 14, SWT.NORMAL));
		lblRilo.setBounds(92, 22, 321, 44);
		lblRilo.setText("RIO人事管理系统");

		Button btnNewButton = new Button(shell, SWT.NONE);

		btnNewButton.setBounds(106, 277, 80, 27);
		btnNewButton.setText("登   录");

		Button button = new Button(shell, SWT.NONE);

		button.setBounds(249, 277, 80, 27);
		button.setText("退   出");

		c = new Button(shell, SWT.CHECK);
		c.setBounds(125, 239, 94, 20);
		c.setText("记住密码");

		combo = new Combo(shell, SWT.NONE);
		combo.setBounds(191, 198, 155, 28);

		Label label_2 = new Label(shell, SWT.NONE);
		label_2.setBounds(81, 201, 76, 20);
		label_2.setText("类       型：");

		init();

		// 初始化下拉列表
		initCombo();

		// 登录
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String eid = text.getText().toString().trim();
				DataDictory.pwd = text_1.getText().trim();
				String type = combo.getText().trim();
				int index = type.indexOf("_");
				String dname = type.substring(0, 3);
				String jname = type.substring(index + 1, type.length());

				if (eid == null || "".equals(eid)) {
					MessageDialog.openConfirm(shell, "错误", "员工号不能为空！");
					return;
				}
				if (DataDictory.pwd  == null || "".equals(DataDictory.pwd )) {
					MessageDialog.openConfirm(shell, "错误", "密码不能为空！");
					return;
				}

				if (type.equals("人事部_经理") || type.equals("人事部_普通员工")) { // mainui2
					String sql = "select *from emp where eid=?  and pwd=?  and  status='在职'  and did=(select did from dept where name=? )"
							+ "  and jid=(select jid from job where name=? )  ";
					loginMethod1(eid, DataDictory.pwd , dname, jname, sql);

				} else {
					String sql = "select *from emp where eid=?  and pwd=?  and  status='在职'  and did=(select did from dept where name=? )"
							+ "  and jid=(select jid from job where name=? )  ";
					loginMethod2(eid, DataDictory.pwd , dname, jname, sql);
				}
			}
		});

		// 退出按钮
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if (MessageDialog.openQuestion(shell, "退出", "你确定要退出么！") == true) {
					System.exit(0);
				}

			}
		});

	}

	private void initCombo() {

		String sql = "select d.name as dname,j.name  as jname from emp e,dept d,job j  where e.did=d.did and e.jid=j.jid ";

		try {
			List<Map<String, Object>> list = db.find(sql, null);
			if (list != null && list.size() > 0) {
				for (Map<String, Object> map : list) {
					String tname = (String) map.get("DNAME") + "_"
							+ map.get("JNAME");
					combo.add(tname);
				}
				combo.select(0);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			MessageDialog.openError(shell, "错误", e.getMessage());
		}

	}

	// 读取注册表，看是否存了用户名和密码
	private void init() {
		Map<String, String> m = RegistrationUtils.findRegistration();
		if (m != null) {
			text.setText(m.get("name"));
			text_1.setText(m.get("pwd"));

			c.setSelection(true);
		}
	}

	private void loginMethod1(String eid, String password, String dname,
			String jname, String sql) {
		boolean flag = c.getSelection();
		List<Object> params = new ArrayList<Object>();
		params.add(eid);
		try {
			params.add(MD5.MD5Encode(password));
		} catch (Exception e) {
			e.printStackTrace();
		}
		params.add(dname);
		params.add(jname);

		DBHelper db = new DBHelper();
		try {
			List<Map<String, Object>> list = db.find(sql, params);

			if (list != null && list.size() > 0) {
				Common.loginAdmin = new Admin(0, eid, password);
				Map<String, String> map = new HashMap<String, String>();
				map.put("name", eid);
				map.put("pwd", password);

				if (flag) {
					try {
						RegistrationUtils.saveRegistration(map);
					} catch (BackingStoreException e1) {
						e1.printStackTrace();
					}
				} else {
					RegistrationUtils.delRegistration(map);
				}

				// MessageDialog.openConfirm(shell, "成功", "登录成功!"+name);
				Login.this.shell.setVisible(false);
				MainUi mu = new MainUi();
				mu.open();

			} else {
				MessageDialog.openError(shell, "失败", "账号或密码不正确!");
				return;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
			MessageDialog.openError(shell, "登录", e1.getMessage());
		}
	}

	private void loginMethod2(String eid, String password, String dname,
			String jname, String sql) {
		boolean flag = c.getSelection();
		List<Object> params = new ArrayList<Object>();
		params.add(eid);
		try {
			params.add(MD5.MD5Encode(password));
		} catch (Exception e) {
			e.printStackTrace();
		}
		params.add(dname);
		params.add(jname);

		DBHelper db = new DBHelper();
		try {
			List<Map<String, Object>> list = db.find(sql, params);

			if (list != null && list.size() > 0) {
				Common.loginAdmin = new Admin(0, eid, password);
				Map<String, String> map = new HashMap<String, String>();
				map.put("name", eid);
				map.put("pwd", password);

				if (flag) {
					try {
						RegistrationUtils.saveRegistration(map);
					} catch (BackingStoreException e1) {
						e1.printStackTrace();
					}
				} else {
					RegistrationUtils.delRegistration(map);
				}

				// MessageDialog.openConfirm(shell, "成功", "登录成功!"+name);
				Login.this.shell.setVisible(false);
				MainUiUser mu = new MainUiUser();
				mu.open();

			} else {
				MessageDialog.openError(shell, "失败", "账号或密码不正确!");
				return;
			}
		} catch (Exception e1) {
			e1.printStackTrace();
			MessageDialog.openError(shell, "登录", e1.getMessage());
		}
	}
}
